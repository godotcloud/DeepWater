#include <metal_stdlib>
using namespace metal;

#include "../Shared/ShaderTypes.h"

struct FishAnimVertexOut {
    float4 position [[position]];
    float3 worldPos;
    float3 worldNormal;
    float3 worldTangent;
    float3 worldBitangent;
    float2 uv;
    float ao;
    float partID;
    float dorsalFactor;
    float finRayCoord;
    float sssThickness;
    float3 dorsalTint;
    float3 ventralTint;
    float iridescenceStrength;
};

static inline float3x3 rotateY3x3(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return float3x3(
        float3( c, 0.0f, -s),
        float3(0.0f, 1.0f, 0.0f),
        float3( s, 0.0f,  c)
    );
}

static inline float3x3 rotateX3x3(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return float3x3(
        float3(1.0f, 0.0f, 0.0f),
        float3(0.0f,  c,    s),
        float3(0.0f, -s,    c)
    );
}

static inline float3x3 rotateZ3x3(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return float3x3(
        float3( c,  s, 0.0f),
        float3(-s,  c, 0.0f),
        float3(0.0f, 0.0f, 1.0f)
    );
}

vertex FishAnimVertexOut fishAnimatedVertexShader(
    uint vid [[vertex_id]],
    uint iid [[instance_id]],
    device const FishVertex* vertices        [[buffer(BufferIndexVertices)]],
    constant Uniforms& uniforms              [[buffer(BufferIndexUniforms)]],
    device const FishInstanceData* instances [[buffer(BufferIndexFishInstances)]],
    device SplashTriggerEvent* splashEvents  [[buffer(BufferIndexSplashEvents)]]
) {
    FishVertex v = vertices[vid];
    FishInstanceData inst = instances[iid];

    float3 localPos = v.position.xyz;
    float3 localN = v.normal.xyz;
    float3 localT = v.tangent.xyz;

    float spineT = v.uvAndWeights.z;
    float finWeight = v.uvAndWeights.w;
    float partID = round(v.anatomyMask.x);

    float swimPhase = inst.swimParams.x;
    float baseTailAmp = inst.swimParams.z;
    float bodyLen = max(inst.swimParams.w, 0.12f);

    float forwardSpeed = max(inst.biomechParams.x, 0.0f);
    float turnCurvature = clamp(inst.biomechParams.y, -1.0f, 1.0f);
    float gillBreathPhase = inst.biomechParams.z;
    int behaviorState = int(round(inst.biomechParams.w));

    float headShakePhase = inst.breachAndShakeParams.x;
    float headShakeIntensity = clamp(inst.breachAndShakeParams.y, 0.0f, 1.0f);
    float breachProgress = clamp(inst.breachAndShakeParams.z, 0.0f, 1.0f);
    float breachApex = max(inst.breachAndShakeParams.w, 0.0f);

    float speedScale = clamp(0.45f + forwardSpeed * 0.42f, 0.40f, 2.20f);
    float fightBoost = (behaviorState >= 1) ? 1.45f : 1.0f;
    float effAmp = baseTailAmp * speedScale * fightBoost;

    float waveNumber = 5.6f;
    float waveEnvelope = 0.035f + 0.18f * spineT + 0.785f * spineT * spineT;
    float waveArg = spineT * waveNumber - swimPhase;
    float lateralWave = sin(waveArg) * effAmp * waveEnvelope * bodyLen;

    float turnBend = turnCurvature * 0.24f * bodyLen * (spineT - 0.35f) * (spineT - 0.35f);

    float headShakeDisp = 0.0f;
    float headShakeRoll = 0.0f;
    if (headShakeIntensity > 0.005f || behaviorState == 2) {
        float shakeAmp = max(headShakeIntensity, (behaviorState == 2) ? 0.85f : 0.0f);
        float headEnvelope = exp(-spineT * 3.8f) - 0.35f * smoothstep(0.55f, 1.0f, spineT);
        headShakeDisp = sin(headShakePhase) * 0.14f * bodyLen * shakeAmp * headEnvelope;
        headShakeRoll = cos(headShakePhase) * 0.48f * shakeAmp * (1.0f - spineT * 0.5f);
    }

    if (abs(partID - 2.0f) < 0.5f) {
        float breathRateBoost = (behaviorState >= 1) ? 1.75f : 1.0f;
        float gillOpen = (0.5f + 0.5f * sin(gillBreathPhase * breathRateBoost)) * (0.011f * bodyLen);
        float sideSign = (localPos.x >= 0.0f) ? 1.0f : -1.0f;
        localPos.x += sideSign * gillOpen;
        localPos.z -= gillOpen * 0.35f;
    }

    float finExtraX = 0.0f;
    float finExtraY = 0.0f;
    float finExtraZ = 0.0f;
    if (abs(partID - 1.0f) < 0.5f && finWeight > 0.001f) {
        bool isPectoralRegion = (spineT > 0.16f && spineT < 0.35f && abs(localPos.x) > 0.01f);
        if (isPectoralRegion) {
            float sideSign = (localPos.x >= 0.0f) ? 1.0f : -1.0f;
            float scullPhase = swimPhase * 0.72f + sideSign * 1.5707963f - finWeight * 1.35f;
            float strokeAmp = (0.055f + 0.035f * clamp(1.0f - forwardSpeed * 0.4f, 0.0f, 1.0f)) * bodyLen;
            finExtraZ += sin(scullPhase) * strokeAmp * finWeight;
            finExtraY += cos(scullPhase) * strokeAmp * 0.55f * finWeight;
            finExtraX += sideSign * sin(scullPhase * 0.5f) * strokeAmp * 0.35f * finWeight;
        } else {
            finExtraX += sin(waveArg - finWeight * 1.55f) * effAmp * 0.38f * finWeight * bodyLen;
        }
    }

    float totalLateral = lateralWave + turnBend + headShakeDisp + finExtraX;
    localPos.x += totalLateral;
    localPos.y += finExtraY;
    localPos.z += finExtraZ;

    if (abs(headShakeRoll) > 0.0001f) {
        float3x3 rollM = rotateZ3x3(headShakeRoll);
        localPos = rollM * localPos;
        localN = rollM * localN;
        localT = rollM * localT;
    }

    float dLateralDz = cos(waveArg) * waveNumber * effAmp * waveEnvelope
                     + turnCurvature * 0.48f * (spineT - 0.35f);
    float invNorm = rsqrt(1.0f + dLateralDz * dLateralDz);
    float cosYaw = invNorm;
    float sinYaw = dLateralDz * invNorm;

    float3 bentN = normalize(float3(
        localN.x * cosYaw - localN.z * sinYaw,
        localN.y,
        localN.x * sinYaw + localN.z * cosYaw
    ));
    float3 bentT = normalize(float3(
        localT.x * cosYaw - localT.z * sinYaw,
        localT.y,
        localT.x * sinYaw + localT.z * cosYaw
    ));

    float3 breachOffset = float3(0.0f);
    float3x3 breachRot = float3x3(
        float3(1.0f, 0.0f, 0.0f),
        float3(0.0f, 1.0f, 0.0f),
        float3(0.0f, 0.0f, 1.0f)
    );

    if (behaviorState == 3 && breachApex > 0.01f) {
        float p = breachProgress;
        float arcY = 4.0f * breachApex * p * (1.0f - p);
        float pitchAngle = (0.5f - p) * 1.48f;
        float airThrash = sin(p * 18.0f + headShakePhase) * 0.35f * sin(p * 3.14159265f);
        float airRoll = sin(p * 6.2831853f) * 0.55f;

        breachRot = rotateZ3x3(airRoll) * rotateX3x3(pitchAngle) * rotateY3x3(airThrash);
        localPos = breachRot * localPos;
        bentN = normalize(breachRot * bentN);
        bentT = normalize(breachRot * bentT);
        breachOffset.y = arcY;
    }

    float4 worldPos4 = inst.modelMatrix * float4(localPos, 1.0f);
    worldPos4.xyz += breachOffset;

    float3x3 model3x3 = float3x3(
        inst.modelMatrix.columns[0].xyz,
        inst.modelMatrix.columns[1].xyz,
        inst.modelMatrix.columns[2].xyz
    );
    float3 wN = normalize(model3x3 * bentN);
    float3 wT = normalize(model3x3 * bentT);
    wT = normalize(wT - wN * dot(wN, wT));
    float3 wB = cross(wN, wT) * v.tangent.w;

    if (vid == 0) {
        float surfaceY = uniforms.water.deepColorAndSurfaceY.w;
        bool isReEntering = (behaviorState == 3) && (breachProgress > 0.84f && breachProgress < 0.99f);
        bool isEmerging = (behaviorState == 3) && (breachProgress > 0.02f && breachProgress < 0.16f);

        if (isReEntering || isEmerging) {
            float impactVel = sqrt(max(2.0f * 9.81f * breachApex, 0.5f));
            float splashIntensity = clamp(impactVel * 0.22f * (isReEntering ? 1.0f : 0.65f), 0.15f, 1.0f);
            float3 centerWorld = (inst.modelMatrix * float4(0.0f, 0.0f, 0.0f, 1.0f)).xyz;
            splashEvents[iid].worldPositionAndRadius = float4(centerWorld.x, surfaceY, centerWorld.z, bodyLen * 1.65f);
            splashEvents[iid].intensityAndFlags = float4(splashIntensity, impactVel, uniforms.viewportAndTime.z, 1.0f);
        } else {
            splashEvents[iid].intensityAndFlags.w = 0.0f;
        }
    }

    FishAnimVertexOut out;
    out.position = uniforms.camera.viewProjectionMatrix * worldPos4;
    out.worldPos = worldPos4.xyz;
    out.worldNormal = wN;
    out.worldTangent = wT;
    out.worldBitangent = wB;
    out.uv = v.uvAndWeights.xy;
    out.ao = v.normal.w;
    out.partID = v.anatomyMask.x;
    out.dorsalFactor = v.anatomyMask.y;
    out.finRayCoord = v.anatomyMask.z;
    out.sssThickness = v.anatomyMask.w;
    out.dorsalTint = inst.dorsalColorAndSpecies.xyz;
    out.ventralTint = inst.ventralColorAndIridescence.xyz;
    out.iridescenceStrength = inst.ventralColorAndIridescence.w;
    return out;
}
