#include <metal_stdlib>
using namespace metal;

#include "../Shared/ShaderTypes.h"

static inline float ctHash21(float2 p) {
    p = fract(p * float2(127.1f, 311.7f));
    p += dot(p, p + 34.23f);
    return fract(p.x * p.y);
}

static inline float2 ctHash22(float2 p) {
    float3 p3 = fract(float3(p.xyx) * float3(0.1031f, 0.1030f, 0.0973f));
    p3 += dot(p3, p3.yzx + 33.33f);
    return fract((p3.xx + p3.yz) * p3.zy);
}

static inline float ctValueNoise(float2 p) {
    float2 i = floor(p);
    float2 f = fract(p);
    float2 u = f * f * (3.0f - 2.0f * f);

    float a = ctHash21(i);
    float b = ctHash21(i + float2(1.0f, 0.0f));
    float c = ctHash21(i + float2(0.0f, 1.0f));
    float d = ctHash21(i + float2(1.0f, 1.0f));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

static inline float ctFbm(float2 p, int octaves) {
    float sum = 0.0f;
    float amp = 0.5f;
    float norm = 0.0f;
    for (int i = 0; i < octaves; ++i) {
        sum += amp * ctValueNoise(p);
        norm += amp;
        p = p * 2.03f + float2(17.3f, 9.1f);
        amp *= 0.5f;
    }
    return sum / max(norm, 0.0001f);
}

static inline float2 ctVoronoi(float2 p) {
    float2 g = floor(p);
    float2 f = fract(p);
    float d1 = 8.0f;
    float d2 = 8.0f;
    for (int y = -1; y <= 1; ++y) {
        for (int x = -1; x <= 1; ++x) {
            float2 cell = float2(float(x), float(y));
            float2 rnd = ctHash22(g + cell);
            float dist = length(cell + rnd - f);
            if (dist < d1) {
                d2 = d1;
                d1 = dist;
            } else if (dist < d2) {
                d2 = dist;
            }
        }
    }
    return float2(d1, d2 - d1);
}

static inline float evalFishScaleHeight(float2 uv, float scaleFreq, thread float& outEdgeMask, thread float& outLateralMask) {
    float2 grid = float2(uv.x * scaleFreq, uv.y * scaleFreq * 0.72f);

    float maxH = 0.0f;
    float rim = 0.0f;

    for (int layer = 0; layer < 2; ++layer) {
        float2 offset = (layer == 1) ? float2(0.5f, 0.5f) : float2(0.0f, 0.0f);
        float2 p = grid + offset;
        float2 cell = floor(p);
        float2 local = fract(p) - 0.5f;

        float2 jitter = (ctHash22(cell + float2(float(layer) * 19.0f, 7.0f)) - 0.5f) * 0.08f;
        local += jitter;

        float2 q = float2(local.x * 1.15f, local.y * 1.38f);
        float diamond = abs(q.x) * 0.55f + abs(q.y) * 0.65f;
        float circle = length(q);
        float shape = mix(circle, diamond, 0.42f);

        float scaleBody = 1.0f - smoothstep(0.32f, 0.54f, shape);
        float slopeTilt = clamp(0.5f - local.x * 0.85f, 0.0f, 1.0f);
        float circuli = sin(shape * 42.0f) * 0.035f;
        float h = scaleBody * (0.45f + 0.48f * slopeTilt + circuli);

        float edgeHighlight = smoothstep(0.36f, 0.48f, shape) * (1.0f - smoothstep(0.48f, 0.55f, shape));
        if (h > maxH) {
            maxH = h;
            rim = edgeHighlight;
        }
    }

    float lateralY = 0.52f + 0.05f * sin(uv.x * 3.14159265f * 1.15f);
    float distToLateral = abs(uv.y - lateralY);
    float lateralBand = 1.0f - smoothstep(0.004f, 0.016f, distToLateral);
    float poreWave = pow(max(0.0f, sin(uv.x * scaleFreq * 3.14159265f)), 4.0f);
    float lateralIndentation = lateralBand * (0.18f + 0.22f * poreWave);

    outEdgeMask = rim;
    outLateralMask = lateralBand;
    return clamp(maxH - lateralIndentation, 0.0f, 1.0f);
}

kernel void bakeFishTexturesKernel(
    texture2d<float, access::write> outAlbedo        [[texture(0)]],
    texture2d<float, access::write> outNormal        [[texture(1)]],
    texture2d<float, access::write> outRoughnessMeta [[texture(2)]],
    texture2d<float, access::write> outIridescence   [[texture(3)]],
    constant TextureBakeParams& params               [[buffer(BufferIndexBakeParams)]],
    uint2 gid                                        [[thread_position_in_grid]]
) {
    uint width = outAlbedo.get_width();
    uint height = outAlbedo.get_height();
    if (gid.x >= width || gid.y >= height) { return; }

    float2 uv = (float2(gid) + 0.5f) / float2(float(width), float(height));
    float scaleFreq = params.primaryColorAndFreq.w;
    float relief = params.sizeAndSeed.w;

    float edgeMask = 0.0f;
    float lateralMask = 0.0f;
    float hC = evalFishScaleHeight(uv, scaleFreq, edgeMask, lateralMask);

    float2 eps = float2(1.0f / float(width), 1.0f / float(height));
    float tmpE = 0.0f;
    float tmpL = 0.0f;
    float hR = evalFishScaleHeight(uv + float2(eps.x, 0.0f), scaleFreq, tmpE, tmpL);
    float hL = evalFishScaleHeight(uv - float2(eps.x, 0.0f), scaleFreq, tmpE, tmpL);
    float hU = evalFishScaleHeight(uv + float2(0.0f, eps.y), scaleFreq, tmpE, tmpL);
    float hD = evalFishScaleHeight(uv - float2(0.0f, eps.y), scaleFreq, tmpE, tmpL);

    float dx = (hR - hL) * relief * 18.0f;
    float dy = (hU - hD) * relief * 18.0f;
    float3 tangentNormal = normalize(float3(-dx, -dy, 1.0f));

    float dorsalFactor = smoothstep(0.22f, 0.82f, uv.y);
    float flankBand = exp(-pow((uv.y - 0.52f) / 0.16f, 2.0f));

    float organicMottle = ctFbm(uv * float2(11.0f, 7.0f) + params.sizeAndSeed.z, 4);
    float verticalBars = smoothstep(0.35f, 0.78f, sin(uv.x * 36.0f + organicMottle * 3.8f) * 0.5f + 0.5f);
    float speckles = smoothstep(0.68f, 0.86f, ctFbm(uv * 38.0f, 3));

    float3 dorsalCol = params.primaryColorAndFreq.xyz;
    float3 ventralCol = params.secondaryColorAndRough.xyz;
    float3 lateralCol = params.accentColorAndMode.xyz;

    float3 albedo = mix(ventralCol, dorsalCol, dorsalFactor);
    albedo = mix(albedo, dorsalCol * 0.58f, verticalBars * dorsalFactor * 0.42f);
    albedo = mix(albedo, lateralCol, flankBand * (0.48f + 0.25f * organicMottle));
    albedo = mix(albedo, dorsalCol * 0.35f, speckles * smoothstep(0.45f, 0.85f, uv.y) * 0.35f);
    albedo *= (0.86f + 0.22f * hC);
    albedo = mix(albedo, albedo * 0.72f, lateralMask * 0.5f);

    float baseRough = params.secondaryColorAndRough.w;
    float roughness = clamp(baseRough + edgeMask * 0.16f - flankBand * 0.08f, 0.08f, 0.65f);
    float metallic = clamp(0.18f + (1.0f - dorsalFactor) * 0.42f + flankBand * 0.25f, 0.05f, 0.82f);
    float ao = clamp(0.65f + 0.35f * hC, 0.4f, 1.0f);
    float mucusCoat = clamp(0.82f + 0.18f * hC - lateralMask * 0.2f, 0.5f, 1.0f);

    float filmNoise = ctFbm(uv * float2(18.0f, 14.0f) + float2(3.1f, 8.7f), 3);
    float filmThickness = clamp(0.35f + 0.38f * filmNoise + 0.22f * hC, 0.1f, 0.98f);
    float iridMask = clamp((flankBand * 0.78f + (1.0f - dorsalFactor) * 0.35f) * (0.65f + 0.35f * hC), 0.0f, 1.0f);

    outAlbedo.write(float4(clamp(albedo, 0.0f, 1.0f), 1.0f), gid);
    outNormal.write(float4(tangentNormal * 0.5f + 0.5f, 1.0f), gid);
    outRoughnessMeta.write(float4(roughness, metallic, ao, mucusCoat), gid);
    outIridescence.write(float4(filmThickness, iridMask, lateralMask, edgeMask), gid);
}

static inline float evalCarbonTwillHeight(float2 uv, float freq, thread float& outOrientation) {
    float2 p = uv * freq;
    float2 cell = floor(p);
    float2 f = fract(p);

    int phase = int(fmod(cell.x + cell.y, 4.0f));
    bool isWarp = (phase == 0 || phase == 1);
    outOrientation = isWarp ? 1.0f : 0.0f;

    float strand = isWarp ? sin(f.y * 3.14159265f) : sin(f.x * 3.14159265f);
    float crossGap = isWarp ? sin(f.x * 3.14159265f) : sin(f.y * 3.14159265f);
    float microFibers = sin((isWarp ? f.y : f.x) * 3.14159265f * 14.0f) * 0.04f;
    return clamp(pow(max(strand, 0.0f), 0.55f) * (0.72f + 0.28f * crossGap) + microFibers, 0.0f, 1.0f);
}

kernel void bakeTackleTexturesKernel(
    texture2d<float, access::write> outAlbedo        [[texture(0)]],
    texture2d<float, access::write> outNormal        [[texture(1)]],
    texture2d<float, access::write> outRoughnessMeta [[texture(2)]],
    constant TextureBakeParams& params               [[buffer(BufferIndexBakeParams)]],
    uint2 gid                                        [[thread_position_in_grid]]
) {
    uint width = outAlbedo.get_width();
    uint height = outAlbedo.get_height();
    if (gid.x >= width || gid.y >= height) { return; }

    float2 uv = (float2(gid) + 0.5f) / float2(float(width), float(height));
    float2 eps = float2(1.0f / float(width), 1.0f / float(height));
    int mode = int(round(params.accentColorAndMode.w));

    float3 albedo = float3(0.15f);
    float3 normal = float3(0.0f, 0.0f, 1.0f);
    float roughness = 0.4f;
    float metallic = 0.0f;
    float ao = 1.0f;
    float clearcoat = 0.0f;

    if (mode == 0) {
        float freq = params.primaryColorAndFreq.w;
        float orient = 0.0f;
        float hC = evalCarbonTwillHeight(uv, freq, orient);
        float tmp = 0.0f;
        float hR = evalCarbonTwillHeight(uv + float2(eps.x, 0.0f), freq, tmp);
        float hL = evalCarbonTwillHeight(uv - float2(eps.x, 0.0f), freq, tmp);
        float hU = evalCarbonTwillHeight(uv + float2(0.0f, eps.y), freq, tmp);
        float hD = evalCarbonTwillHeight(uv - float2(0.0f, eps.y), freq, tmp);

        normal = normalize(float3(-(hR - hL) * 14.0f, -(hU - hD) * 14.0f, 1.0f));
        float3 darkFiber = params.primaryColorAndFreq.xyz;
        float3 sheenFiber = params.secondaryColorAndRough.xyz;
        albedo = mix(darkFiber, sheenFiber, orient * 0.55f + hC * 0.45f);
        roughness = mix(0.18f, 0.34f, orient);
        metallic = 0.35f;
        ao = 0.65f + 0.35f * hC;
        clearcoat = 0.92f;
    } else if (mode == 1) {
        float scratch1 = ctValueNoise(float2(uv.x * 16.0f, uv.y * 260.0f));
        float scratch2 = ctValueNoise(float2(uv.x * 48.0f + 7.2f, uv.y * 520.0f));
        float streak = scratch1 * 0.65f + scratch2 * 0.35f;

        float sU = ctValueNoise(float2(uv.x * 16.0f, (uv.y + eps.y) * 260.0f)) * 0.65f +
                   ctValueNoise(float2(uv.x * 48.0f + 7.2f, (uv.y + eps.y) * 520.0f)) * 0.35f;
        float sD = ctValueNoise(float2(uv.x * 16.0f, (uv.y - eps.y) * 260.0f)) * 0.65f +
                   ctValueNoise(float2(uv.x * 48.0f + 7.2f, (uv.y - eps.y) * 520.0f)) * 0.35f;

        normal = normalize(float3(0.0f, -(sU - sD) * 6.5f, 1.0f));
        albedo = mix(params.primaryColorAndFreq.xyz, params.secondaryColorAndRough.xyz, streak);
        roughness = clamp(params.secondaryColorAndRough.w + (streak - 0.5f) * 0.14f, 0.12f, 0.45f);
        metallic = 0.94f;
        ao = 0.90f + 0.10f * streak;
        clearcoat = 0.25f;
    } else {
        float baseGrain = ctFbm(uv * float2(18.0f, 34.0f), 4);
        float2 vor = ctVoronoi(uv * float2(26.0f, 14.0f));
        float poreMask = smoothstep(0.04f, 0.16f, vor.y) * smoothstep(0.28f, 0.62f, ctFbm(uv * 22.0f + 4.3f, 3));
        float cavity = 1.0f - poreMask * 0.75f;

        float hC = baseGrain * 0.35f + cavity * 0.65f;
        float hR = ctFbm((uv + float2(eps.x, 0.0f)) * float2(18.0f, 34.0f), 3) * 0.35f +
                   (1.0f - smoothstep(0.04f, 0.16f, ctVoronoi((uv + float2(eps.x, 0.0f)) * float2(26.0f, 14.0f)).y) * 0.75f) * 0.65f;
        float hU = ctFbm((uv + float2(0.0f, eps.y)) * float2(18.0f, 34.0f), 3) * 0.35f +
                   (1.0f - smoothstep(0.04f, 0.16f, ctVoronoi((uv + float2(0.0f, eps.y)) * float2(26.0f, 14.0f)).y) * 0.75f) * 0.65f;

        normal = normalize(float3(-(hR - hC) * 18.0f, -(hU - hC) * 18.0f, 1.0f));
        float3 lightCork = params.primaryColorAndFreq.xyz;
        float3 darkPore = params.secondaryColorAndRough.xyz;
        albedo = mix(darkPore, lightCork, clamp(cavity * (0.75f + 0.35f * baseGrain), 0.0f, 1.0f));
        roughness = clamp(0.76f + (1.0f - cavity) * 0.20f, 0.65f, 0.96f);
        metallic = 0.0f;
        ao = clamp(0.45f + 0.55f * cavity, 0.35f, 1.0f);
        clearcoat = 0.0f;
    }

    outAlbedo.write(float4(clamp(albedo, 0.0f, 1.0f), 1.0f), gid);
    outNormal.write(float4(normal * 0.5f + 0.5f, 1.0f), gid);
    outRoughnessMeta.write(float4(roughness, metallic, ao, clearcoat), gid);
}

static inline float evalSeabedHeight(float2 uv, thread float& outPebble, thread float& outMoss) {
    float strata = ctFbm(float2(uv.x * 6.0f, uv.y * 14.0f), 5);
    float2 pebbleVor = ctVoronoi(uv * 22.0f);
    float pebble = smoothstep(0.06f, 0.45f, pebbleVor.y) * (1.0f - pebbleVor.x * 0.55f);
    float fineSand = ctFbm(uv * 44.0f + 9.4f, 3);

    float mossNoise = ctFbm(uv * 9.5f + float2(4.2f, 11.7f), 4);
    outMoss = smoothstep(0.52f, 0.74f, mossNoise) * smoothstep(0.15f, 0.55f, strata);
    outPebble = pebble;

    return clamp(strata * 0.45f + pebble * 0.40f + fineSand * 0.15f, 0.0f, 1.0f);
}

kernel void bakeSeabedTexturesKernel(
    texture2d<float, access::write> outAlbedo        [[texture(0)]],
    texture2d<float, access::write> outNormal        [[texture(1)]],
    texture2d<float, access::write> outRoughnessMeta [[texture(2)]],
    constant TextureBakeParams& params               [[buffer(BufferIndexBakeParams)]],
    uint2 gid                                        [[thread_position_in_grid]]
) {
    uint width = outAlbedo.get_width();
    uint height = outAlbedo.get_height();
    if (gid.x >= width || gid.y >= height) { return; }

    float2 uv = (float2(gid) + 0.5f) / float2(float(width), float(height));
    float2 eps = float2(1.0f / float(width), 1.0f / float(height));

    float pebble = 0.0f;
    float moss = 0.0f;
    float hC = evalSeabedHeight(uv, pebble, moss);

    float tmpP = 0.0f;
    float tmpM = 0.0f;
    float hR = evalSeabedHeight(uv + float2(eps.x, 0.0f), tmpP, tmpM);
    float hL = evalSeabedHeight(uv - float2(eps.x, 0.0f), tmpP, tmpM);
    float hU = evalSeabedHeight(uv + float2(0.0f, eps.y), tmpP, tmpM);
    float hD = evalSeabedHeight(uv - float2(0.0f, eps.y), tmpP, tmpM);

    float relief = params.sizeAndSeed.w;
    float3 normal = normalize(float3(-(hR - hL) * relief * 20.0f, -(hU - hD) * relief * 20.0f, 1.0f));

    float3 sedimentCol = params.primaryColorAndFreq.xyz;
    float3 rockCol = params.secondaryColorAndRough.xyz;
    float3 mossCol = params.accentColorAndMode.xyz;

    float3 albedo = mix(sedimentCol, rockCol, smoothstep(0.22f, 0.72f, pebble));
    albedo = mix(albedo, mossCol, moss * 0.78f);
    albedo *= (0.78f + 0.34f * hC);

    float roughness = clamp(mix(0.84f, 0.58f, pebble) + moss * 0.14f, 0.42f, 0.96f);
    float metallic = 0.02f;
    float ao = clamp(0.45f + 0.55f * hC, 0.35f, 1.0f);

    outAlbedo.write(float4(clamp(albedo, 0.0f, 1.0f), 1.0f), gid);
    outNormal.write(float4(normal * 0.5f + 0.5f, 1.0f), gid);
    outRoughnessMeta.write(float4(roughness, metallic, ao, moss), gid);
}
