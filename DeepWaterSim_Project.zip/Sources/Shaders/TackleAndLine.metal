#include <metal_stdlib>
using namespace metal;

#include "../Shared/ShaderTypes.h"

struct TackleVertexOut {
    float4 position [[position]];
    float3 worldPos;
    float3 worldNormal;
    float2 uv;
    float materialID;
    float roughness;
    float3 tint;
};

vertex TackleVertexOut tackleVertexShader(
    uint vid [[vertex_id]],
    device const Vertex* vertices       [[buffer(BufferIndexVertices)]],
    constant Uniforms& uniforms         [[buffer(BufferIndexUniforms)]],
    constant TackleUniforms& tackle     [[buffer(BufferIndexTackleUniforms)]]
) {
    Vertex v = vertices[vid];
    float4 worldPos = tackle.modelMatrix * float4(v.position.xyz, 1.0f);
    float3x3 rotMat = float3x3(
        tackle.modelMatrix.columns[0].xyz,
        tackle.modelMatrix.columns[1].xyz,
        tackle.modelMatrix.columns[2].xyz
    );

    TackleVertexOut out;
    out.position = uniforms.camera.viewProjectionMatrix * worldPos;
    out.worldPos = worldPos.xyz;
    out.worldNormal = normalize(rotMat * v.normal.xyz);
    out.uv = v.uvAndMaterial.xy;
    out.materialID = v.uvAndMaterial.z;
    out.roughness = v.uvAndMaterial.w;
    out.tint = tackle.tintAndParams.xyz;
    return out;
}

fragment float4 tackleFragmentShader(
    TackleVertexOut in [[stage_in]],
    constant Uniforms& uniforms                      [[buffer(BufferIndexUniforms)]],
    texture2d<float, access::sample> carbonAlbedo    [[texture(TextureIndexCarbonAlbedo)]],
    texture2d<float, access::sample> aluminumAlbedo  [[texture(TextureIndexAluminumAlbedo)]],
    texture2d<float, access::sample> corkAlbedo      [[texture(TextureIndexCorkAlbedo)]]
) {
    constexpr sampler matSampler(coord::normalized, address::repeat, filter::linear, mip_filter::linear);

    float3 N = normalize(in.worldNormal);
    float3 camPos = uniforms.camera.positionAndFov.xyz;
    float3 toCam = camPos - in.worldPos;
    float dist = length(toCam);
    float3 V = toCam / max(dist, 0.0001f);

    float3 sunDir = normalize(uniforms.atmosphere.sunDirectionAndElevation.xyz);
    float3 sunRad = uniforms.atmosphere.sunColorAndIntensity.xyz * uniforms.atmosphere.sunColorAndIntensity.w;
    float sunDay = smoothstep(-0.10f, 0.20f, sunDir.y);

    int mat = int(round(in.materialID));
    float3 albedo = float3(0.15f);
    float metallic = 0.25f;
    float roughness = clamp(in.roughness, 0.06f, 0.92f);

    if (mat == 0) {
        // Sample GPU-baked 512x512 2x2 Twill Carbon Fiber texture
        albedo = carbonAlbedo.sample(matSampler, in.uv * float2(3.0f, 22.0f)).rgb * 1.45f;
        metallic = 0.45f;
        roughness = 0.20f;
    } else if (mat == 1) {
        // Sample GPU-baked 512x512 Brushed Anodized Aluminum texture
        albedo = aluminumAlbedo.sample(matSampler, in.uv * float2(2.0f, 4.0f)).rgb;
        metallic = 0.92f;
        roughness = 0.20f;
    } else if (mat == 2) {
        // Sample GPU-baked 512x512 Natural Cork Grip texture
        albedo = corkAlbedo.sample(matSampler, in.uv * float2(2.0f, 4.0f)).rgb;
        metallic = 0.0f;
        roughness = 0.82f;
    } else if (mat == 3) {
        // SiC Ceramic Guide Ring / Diving Lip
        albedo = float3(0.10f, 0.11f, 0.13f);
        metallic = 0.35f;
        roughness = 0.06f;
    } else if (mat == 4) {
        // Gloss Lure Paint / Chrome Metal Spoon / Treble Hooks
        albedo = mix(float3(0.86f, 0.90f, 0.94f), in.tint, 0.65f);
        metallic = 0.88f;
        roughness = 0.10f;
    } else {
        // Soft Plastic Elastomer Worm
        albedo = in.tint;
        metallic = 0.05f;
        roughness = 0.30f;
    }

    float3 H = normalize(sunDir + V);
    float NdotL = max(dot(N, sunDir), 0.0f);
    float NdotH = max(dot(N, H), 0.0f);

    float3 F0 = mix(float3(0.04f), albedo, metallic);
    float3 F = F0 + (1.0f - F0) * pow(1.0f - max(dot(H, V), 0.0f), 5.0f);
    float a = max(roughness * roughness, 0.003f);
    float a2 = a * a;
    float denom = (NdotH * NdotH) * (a2 - 1.0f) + 1.0f;
    float D = a2 / (3.14159265f * denom * denom + 0.0001f);

    float3 diffuse = (1.0f - F) * (1.0f - metallic) * albedo / 3.14159265f;
    float3 spec = D * F * 0.25f;

    float3 ambient = mix(float3(0.08f, 0.14f, 0.20f), uniforms.atmosphere.ambientColorAndExposure.xyz * 1.45f, N.y * 0.5f + 0.5f);
    float3 color = (diffuse + spec) * sunRad * NdotL * (0.28f + 0.72f * sunDay) + albedo * ambient * 0.85f;

    float surfaceY = uniforms.water.deepColorAndSurfaceY.w;
    float underwaterCam = uniforms.camera.upAndUnderwater.w;
    if (underwaterCam > 0.01f && in.worldPos.y < surfaceY + 0.2f) {
        float3 trans = exp(-uniforms.water.absorptionAndClarity.xyz * dist * 0.60f);
        float3 fog = uniforms.water.deepColorAndSurfaceY.xyz * (0.35f + 0.65f * sunDay);
        color = mix(color, mix(fog, color, trans), underwaterCam);
    }

    return float4(color, 1.0f);
}

// MARK: - 32-Node XPBD Fishing Line Ribbon Shader

struct LineVertexOut {
    float4 position [[position]];
    float tension;
};

vertex LineVertexOut lineVertexShader(
    uint vid [[vertex_id]],
    device const Vertex* vertices   [[buffer(BufferIndexVertices)]],
    constant Uniforms& uniforms     [[buffer(BufferIndexUniforms)]],
    constant TackleUniforms& tackle [[buffer(BufferIndexTackleUniforms)]]
) {
    Vertex v = vertices[vid];
    LineVertexOut out;
    out.position = uniforms.camera.viewProjectionMatrix * float4(v.position.xyz, 1.0f);
    out.tension = tackle.tintAndParams.w;
    return out;
}

fragment float4 lineFragmentShader(LineVertexOut in [[stage_in]]) {
    float3 slackCol = float3(0.62f, 0.92f, 0.98f);
    float3 tautCol  = float3(1.00f, 0.42f, 0.18f);
    float3 col = mix(slackCol, tautCol, clamp(in.tension, 0.0f, 1.0f));
    return float4(col, 0.88f);
}

// MARK: - 3D Water Splash & Breaching Spray Particles

struct SplashVertexOut {
    float4 position [[position]];
    float2 localUV;
    float3 color;
    float alpha;
};

vertex SplashVertexOut splashVertexShader(
    uint vid [[vertex_id]],
    uint iid [[instance_id]],
    constant Uniforms& uniforms                    [[buffer(BufferIndexUniforms)]],
    device const SplashParticleData* particles     [[buffer(BufferIndexSplashParticles)]]
) {
    SplashParticleData p = particles[iid];
    float2 corners[4] = {
        float2(-1.0f, -1.0f),
        float2( 1.0f, -1.0f),
        float2(-1.0f,  1.0f),
        float2( 1.0f,  1.0f)
    };
    float2 c = corners[vid & 3u];
    float size = p.positionAndSize.w;

    float3 camRight = uniforms.camera.rightAndFar.xyz;
    float3 camUp = uniforms.camera.upAndUnderwater.xyz;
    float3 worldPos = p.positionAndSize.xyz + (camRight * c.x + camUp * c.y) * size;

    SplashVertexOut out;
    out.position = uniforms.camera.viewProjectionMatrix * float4(worldPos, 1.0f);
    out.localUV = c;
    out.color = p.colorAndAlpha.xyz;
    out.alpha = p.colorAndAlpha.w;
    return out;
}

fragment float4 splashFragmentShader(SplashVertexOut in [[stage_in]]) {
    float r = length(in.localUV);
    float softDisc = pow(max(0.0f, 1.0f - r), 1.8f);
    float a = softDisc * in.alpha;
    if (a < 0.01f) { discard_fragment(); }
    return float4(in.color, a);
}
