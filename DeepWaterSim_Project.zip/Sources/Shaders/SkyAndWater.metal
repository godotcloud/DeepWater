#include <metal_stdlib>
using namespace metal;

#include "../Shared/ShaderTypes.h"

static inline float hash21(float2 p) {
    p = fract(p * float2(123.34f, 456.21f));
    p += dot(p, p + 45.32f);
    return fract(p.x * p.y);
}

static inline float valueNoise2D(float2 p) {
    float2 i = floor(p);
    float2 f = fract(p);
    float2 u = f * f * (3.0f - 2.0f * f);

    float a = hash21(i);
    float b = hash21(i + float2(1.0f, 0.0f));
    float c = hash21(i + float2(0.0f, 1.0f));
    float d = hash21(i + float2(1.0f, 1.0f));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

static inline float fastCausticPattern(float2 p, float time) {
    float2 p1 = p * 2.1f + float2(time * 0.55f, -time * 0.42f);
    float2 p2 = p * 2.9f + float2(-time * 0.48f, time * 0.62f);
    float w1 = sin(p1.x + sin(p1.y * 1.15f + time)) * cos(p1.y + cos(p1.x * 1.12f - time));
    float w2 = sin(p2.x - cos(p2.y * 1.25f - time * 0.8f)) * cos(p2.y + sin(p2.x * 0.95f + time * 1.1f));
    float ridge = 1.0f - abs(w1 * 0.55f + w2 * 0.45f);
    return pow(clamp(ridge, 0.0f, 1.0f), 4.0f);
}

static inline float3 evaluateCausticsRGB(float2 xz, float time, float scale, float speed) {
    float2 p = xz * scale;
    float t = time * speed;
    float cR = fastCausticPattern(p + float2(0.04f, -0.02f), t);
    float cG = fastCausticPattern(p, t);
    float cB = fastCausticPattern(p - float2(0.04f, -0.02f), t);
    return float3(cR, cG, cB);
}

static inline float3 evaluateSkyRadiance(float3 rayDir, constant AtmosphereParams& atmo) {
    float3 dir = normalize(rayDir);
    float3 sunDir = normalize(atmo.sunDirectionAndElevation.xyz);
    float sunElev = sunDir.y;

    float cosTheta = clamp(dot(dir, sunDir), -1.0f, 1.0f);
    float upY = max(dir.y, 0.001f);

    float viewOpticalDepth = 1.0f / (upY + 0.14f * pow(max(upY + 0.12f, 0.001f), -1.25f));
    float sunZenithClamped = max(sunElev + 0.15f, 0.03f);
    float sunOpticalDepth = 1.0f / (sunZenithClamped + 0.16f);

    float3 betaR = atmo.rayleighCoeffAndScale.xyz * 62.0f;
    float3 betaM = atmo.mieCoeffAndG.xyz * 22.0f;
    float g = atmo.mieCoeffAndG.w;

    float phaseR = 0.0596831f * (1.0f + cosTheta * cosTheta);
    float g2 = g * g;
    float denom = max(1.0f + g2 - 2.0f * g * cosTheta, 0.001f);
    float phaseM = 0.0795775f * ((1.0f - g2) / pow(denom, 1.5f));

    float3 extinction = exp(-(betaR * 0.18f + betaM * 0.25f) * (viewOpticalDepth * 0.42f + sunOpticalDepth * 0.28f));
    float3 inScatter = (betaR * phaseR + betaM * phaseM) * (1.0f - exp(-viewOpticalDepth * 0.38f));

    float dayWeight = smoothstep(-0.14f, 0.25f, sunElev);
    float3 sunRadiance = atmo.sunColorAndIntensity.xyz * atmo.sunColorAndIntensity.w;

    float3 skyColor = inScatter * extinction * sunRadiance * (0.18f + 0.82f * dayWeight);

    float horizonBlend = pow(1.0f - clamp(dir.y, 0.0f, 1.0f), 3.6f);
    float3 baseDome = mix(atmo.skyZenithColorAndTime.xyz, atmo.skyHorizonColorAndFog.xyz, horizonBlend);
    skyColor = skyColor * 0.65f + baseDome * (0.45f + 0.55f * dayWeight);

    float sunDisk = smoothstep(0.99935f, 0.99985f, cosTheta);
    float sunHalo = pow(max(cosTheta, 0.0f), 96.0f) * 0.45f;
    float aboveHorizon = smoothstep(-0.04f, 0.03f, dir.y) * smoothstep(-0.08f, 0.04f, sunElev);
    skyColor += sunRadiance * (sunDisk * 18.0f + sunHalo) * aboveHorizon;

    float nightWeight = 1.0f - smoothstep(-0.18f, 0.02f, sunElev);
    if (nightWeight > 0.01f && dir.y > 0.02f) {
        float2 starUV = dir.xz / (dir.y + 0.15f) * 140.0f;
        float starCell = hash21(floor(starUV));
        float starSpark = smoothstep(0.994f, 0.9995f, starCell);
        skyColor += float3(0.75f, 0.85f, 1.0f) * starSpark * nightWeight * smoothstep(0.02f, 0.25f, dir.y) * 1.4f;
    }

    if (dir.y < 0.0f) {
        skyColor = mix(atmo.skyHorizonColorAndFog.xyz * 0.55f, atmo.skyZenithColorAndTime.xyz * 0.15f, clamp(-dir.y * 2.5f, 0.0f, 1.0f));
    }

    return max(skyColor, float3(0.0f));
}

struct SkyVertexOut {
    float4 position [[position]];
    float2 ndc;
};

vertex SkyVertexOut skyVertexShader(uint vid [[vertex_id]]) {
    float2 pos[3] = {
        float2(-1.0f, -1.0f),
        float2( 3.0f, -1.0f),
        float2(-1.0f,  3.0f)
    };
    SkyVertexOut out;
    out.position = float4(pos[vid], 0.9999f, 1.0f);
    out.ndc = pos[vid];
    return out;
}

fragment float4 skyFragmentShader(
    SkyVertexOut in [[stage_in]],
    constant Uniforms& uniforms [[buffer(BufferIndexUniforms)]]
) {
    float4 farClip = float4(in.ndc, 1.0f, 1.0f);
    float4 worldPos = uniforms.camera.invViewProjectionMatrix * farClip;
    float3 rayDir = normalize(worldPos.xyz / worldPos.w - uniforms.camera.positionAndFov.xyz);

    float3 sky = evaluateSkyRadiance(rayDir, uniforms.atmosphere);

    float underwater = uniforms.camera.upAndUnderwater.w;
    if (underwater > 0.001f) {
        float sunFactor = clamp(uniforms.atmosphere.sunDirectionAndElevation.y * 1.4f + 0.35f, 0.12f, 1.0f);
        float3 abyssTop = uniforms.water.shallowColorAndFoam.xyz * 0.85f * sunFactor;
        float3 abyssBot = uniforms.water.deepColorAndSurfaceY.xyz * 0.45f * sunFactor;
        float3 underwaterBg = mix(abyssBot, abyssTop, smoothstep(-0.45f, 0.35f, rayDir.y));
        sky = mix(sky, underwaterBg, underwater);
    }

    return float4(sky, 1.0f);
}

struct WaterVertexOut {
    float4 position [[position]];
    float3 worldPos;
    float3 normal;
    float foamCrest;
};

vertex WaterVertexOut waterVertexShader(
    uint vid [[vertex_id]],
    device const Vertex* vertices [[buffer(BufferIndexVertices)]],
    constant Uniforms& uniforms [[buffer(BufferIndexUniforms)]]
) {
    float3 basePos = vertices[vid].position.xyz;
    float time = uniforms.water.gridParams.z;
    float windSpeed = uniforms.water.godRayParams.z;

    float3 displaced = basePos;
    float3 tangent = float3(1.0f, 0.0f, 0.0f);
    float3 binormal = float3(0.0f, 0.0f, 1.0f);
    float crestAccum = 0.0f;

    float distFromOrigin = length(basePos.xz);
    float distAtten = 1.0f - smoothstep(65.0f, 108.0f, distFromOrigin);

    for (int i = 0; i < 8; ++i) {
        float4 w = uniforms.water.gerstnerWaves[i];
        float2 d = normalize(w.xy);
        float steepness = w.z * distAtten;
        float wavelength = max(w.w, 0.5f);

        float k = 6.2831853f / wavelength;
        float c = sqrt(9.81f / k) * windSpeed;
        float f = k * (dot(d, basePos.xz) - c * time);
        float a = steepness / k;

        float cosF = cos(f);
        float sinF = sin(f);

        displaced.x += d.x * (a * cosF);
        displaced.y += a * sinF;
        displaced.z += d.y * (a * cosF);

        tangent += float3(
            -d.x * d.x * (steepness * sinF),
            d.x * (steepness * cosF),
            -d.x * d.y * (steepness * sinF)
        );
        binormal += float3(
            -d.x * d.y * (steepness * sinF),
            d.y * (steepness * cosF),
            -d.y * d.y * (steepness * sinF)
        );

        crestAccum += max(0.0f, sinF) * steepness;
    }

    float3 normal = normalize(cross(binormal, tangent));

    WaterVertexOut out;
    out.worldPos = displaced;
    out.normal = normal;
    out.foamCrest = clamp(crestAccum * 1.4f, 0.0f, 1.0f);
    out.position = uniforms.camera.viewProjectionMatrix * float4(displaced, 1.0f);
    return out;
}

static inline float3 computeCapillaryNormal(float2 worldXZ, float time, float strength) {
    float2 uv1 = worldXZ * 2.1f + float2(time * 0.48f, time * 0.30f);
    float2 uv2 = worldXZ * 5.2f + float2(-time * 0.62f, time * 0.41f);
    float dx = cos(uv1.x) * sin(uv1.y) * 0.6f + cos(uv2.x) * sin(uv2.y) * 0.4f;
    float dz = sin(uv1.x) * cos(uv1.y) * 0.6f + sin(uv2.x) * cos(uv2.y) * 0.4f;
    return normalize(float3(-dx * strength, 1.0f, -dz * strength));
}

fragment float4 waterFragmentShader(
    WaterVertexOut in [[stage_in]],
    constant Uniforms& uniforms [[buffer(BufferIndexUniforms)]],
    texture2d<float, access::sample> terrainHeightTex [[texture(TextureIndexTerrainHeight)]]
) {
    constexpr sampler heightSampler(coord::normalized, address::clamp_to_edge, filter::linear);

    float3 camPos = uniforms.camera.positionAndFov.xyz;
    float3 toCam = camPos - in.worldPos;
    float dist = length(toCam);
    float3 V = toCam / max(dist, 0.0001f);

    float time = uniforms.water.gridParams.z;
    float terrainHalf = uniforms.water.gridParams.y;
    float2 heightUV = (in.worldPos.xz / (terrainHalf * 2.0f)) + 0.5f;
    float bedY = terrainHeightTex.sample(heightSampler, heightUV).r;
    float waterDepth = in.worldPos.y - bedY;

    // Smooth shoreline discard to eliminate harsh rectangular foam strips on dry bank
    if (waterDepth <= 0.01f) {
        discard_fragment();
    }

    float capFade = 1.0f - smoothstep(14.0f, 75.0f, dist);
    float3 capN = computeCapillaryNormal(in.worldPos.xz, time, uniforms.water.godRayParams.w * capFade);
    float3 N = normalize(float3(
        in.normal.x + capN.x * 0.34f,
        in.normal.y,
        in.normal.z + capN.z * 0.34f
    ));

    float3 sunDir = normalize(uniforms.atmosphere.sunDirectionAndElevation.xyz);
    float3 sunRadiance = uniforms.atmosphere.sunColorAndIntensity.xyz * uniforms.atmosphere.sunColorAndIntensity.w;
    float sunDay = smoothstep(-0.10f, 0.20f, sunDir.y);

    bool viewingFromUnderwater = (camPos.y < in.worldPos.y);

    if (viewingFromUnderwater) {
        float3 Nw = -N;
        float3 I = -V;
        float cosI = clamp(dot(-I, Nw), 0.0f, 1.0f);

        float eta = 1.333f;
        float sin2T = eta * eta * max(0.0f, 1.0f - cosI * cosI);
        float k = 1.0f - sin2T;

        float snellMask = smoothstep(-0.04f, 0.14f, k);

        float3 refractedDir = normalize(eta * I + (eta * cosI - sqrt(max(k, 0.0f))) * Nw);
        refractedDir.y = abs(refractedDir.y);

        float3 skyThroughWindow = evaluateSkyRadiance(refractedDir, uniforms.atmosphere) * 1.15f;

        float f0 = 0.02f;
        float fresnelUnder = f0 + (1.0f - f0) * pow(1.0f - cosI, 5.0f);

        float3 tirColor = mix(
            uniforms.water.deepColorAndSurfaceY.xyz * 0.45f,
            uniforms.water.shallowColorAndFoam.xyz * 0.55f,
            clamp(sunDay * 0.7f, 0.15f, 1.0f)
        );
        float rippleShimmer = pow(max(dot(reflect(I, Nw), -sunDir), 0.0f), 24.0f) * 0.25f * sunDay;
        tirColor += uniforms.water.shallowColorAndFoam.xyz * rippleShimmer;

        float3 surfaceColor = mix(tirColor, skyThroughWindow, snellMask * (1.0f - fresnelUnder * 0.65f));

        float3 transmittance = exp(-uniforms.water.absorptionAndClarity.xyz * dist * 0.55f);
        float3 fogColor = uniforms.water.deepColorAndSurfaceY.xyz * (0.28f + 0.72f * sunDay);
        float3 finalColor = mix(fogColor, surfaceColor, transmittance);

        return float4(finalColor, 0.94f);
    }

    float NdotV = max(dot(N, V), 0.001f);
    float f0 = 0.02f;
    float fresnel = f0 + (1.0f - f0) * pow(1.0f - NdotV, 5.0f);

    float3 reflDir = reflect(-V, N);
    reflDir.y = max(reflDir.y, 0.015f);
    float3 skyReflection = evaluateSkyRadiance(reflDir, uniforms.atmosphere);

    float3 H = normalize(sunDir + V);
    float NdotH = max(dot(N, H), 0.0f);
    float roughness = mix(0.035f, 0.11f, smoothstep(10.0f, 75.0f, dist));
    float alpha = roughness * roughness;
    float alpha2 = alpha * alpha;
    float denomGGX = (NdotH * NdotH) * (alpha2 - 1.0f) + 1.0f;
    float D = alpha2 / (3.14159265f * denomGGX * denomGGX + 0.0001f);
    float3 specular = sunRadiance * D * fresnel * 0.22f * sunDay * smoothstep(0.0f, 0.12f, sunDir.y);

    float opticalPath = waterDepth / max(NdotV, 0.22f);
    float3 transmittance = exp(-uniforms.water.absorptionAndClarity.xyz * opticalPath);

    float3 deepScatter = uniforms.water.deepColorAndSurfaceY.xyz * (0.25f + 0.75f * sunDay);
    float3 shallowScatter = uniforms.water.shallowColorAndFoam.xyz * (0.30f + 0.70f * sunDay);

    float sss = pow(max(dot(V, -sunDir + N * 0.55f), 0.0f), 4.0f) * (0.35f + 0.65f * in.foamCrest) * sunDay;
    float3 waterVolume = mix(deepScatter, shallowScatter, transmittance.g) +
                         float3(0.04f, 0.26f, 0.24f) * sss * 0.45f;

    float3 caustics = evaluateCausticsRGB(
        in.worldPos.xz,
        time,
        uniforms.water.causticParams.y,
        uniforms.water.causticParams.z
    );
    float causticVis = exp(-waterDepth * 0.22f) * sunDay * uniforms.water.causticParams.x * 0.35f;
    float3 seabedTint = float3(0.28f, 0.25f, 0.19f) * (0.35f + 0.65f * sunDay) + caustics * sunRadiance * causticVis;

    float3 refractedBody = mix(waterVolume, seabedTint, transmittance);
    float3 waterColor = mix(refractedBody, skyReflection, clamp(fresnel * 1.08f, 0.02f, 0.98f)) + specular;

    // Organic feathered shoreline foam (no hard linear band!)
    float foamNoise = valueNoise2D(in.worldPos.xz * 2.8f + float2(time * 0.42f, -time * 0.28f)) * 0.65f +
                      valueNoise2D(in.worldPos.xz * 6.4f - float2(time * 0.35f, time * 0.45f)) * 0.35f;
    float shoreBand = smoothstep(0.02f, 0.14f, waterDepth) * (1.0f - smoothstep(0.14f, 0.48f, waterDepth + foamNoise * 0.20f));
    float shoreFoam = shoreBand * smoothstep(0.42f, 0.78f, foamNoise) * 0.55f;
    float crestFoam = smoothstep(0.72f, 0.98f, in.foamCrest * 0.75f + foamNoise * 0.40f) * 0.28f;
    float foamMask = clamp(shoreFoam + crestFoam, 0.0f, 1.0f);
    float3 foamColor = (uniforms.atmosphere.ambientColorAndExposure.xyz * 1.35f + sunRadiance * 0.20f * sunDay);
    waterColor = mix(waterColor, foamColor, foamMask);

    float fogFactor = 1.0f - exp(-dist * uniforms.atmosphere.skyHorizonColorAndFog.w);
    float3 fogHorizon = evaluateSkyRadiance(normalize(float3(-V.x, max(-V.y, 0.02f), -V.z)), uniforms.atmosphere);
    waterColor = mix(waterColor, fogHorizon, clamp(fogFactor, 0.0f, 0.95f));

    // Silky alpha feathering right at the waterline + clear shallow visibility
    float shoreFeather = smoothstep(0.02f, 0.45f, waterDepth);
    float depthOpacity = smoothstep(0.0f, 5.5f, waterDepth) * 0.68f + 0.16f;
    float finalAlpha = clamp(max(depthOpacity, fresnel * 0.88f + foamMask) * shoreFeather, 0.0f, 0.94f);

    return float4(waterColor, finalAlpha);
}

struct PostVertexOut {
    float4 position [[position]];
    float2 uv;
};

vertex PostVertexOut postProcessVertexShader(uint vid [[vertex_id]]) {
    float2 pos[3] = {
        float2(-1.0f, -1.0f),
        float2( 3.0f, -1.0f),
        float2(-1.0f,  3.0f)
    };
    float2 uv[3] = {
        float2(0.0f, 1.0f),
        float2(2.0f, 1.0f),
        float2(0.0f, -1.0f)
    };
    PostVertexOut out;
    out.position = float4(pos[vid], 0.0f, 1.0f);
    out.uv = uv[vid];
    return out;
}

static inline float3 acesFilmicToneMap(float3 x) {
    const float a = 2.51f;
    const float b = 0.03f;
    const float c = 2.43f;
    const float d = 0.59f;
    const float e = 0.14f;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0f, 1.0f);
}

fragment float4 postProcessFragmentShader(
    PostVertexOut in [[stage_in]],
    constant Uniforms& uniforms [[buffer(BufferIndexUniforms)]],
    texture2d<float, access::sample> hdrColorTex [[texture(TextureIndexHdrColor)]]
) {
    constexpr sampler linearSampler(coord::normalized, address::clamp_to_edge, filter::linear);

    float underwater = uniforms.camera.upAndUnderwater.w;
    float2 uv = in.uv;

    if (underwater > 0.01f) {
        float t = uniforms.viewportAndTime.z;
        float2 wobble = float2(
            sin(uv.y * 14.0f + t * 2.1f),
            cos(uv.x * 11.0f + t * 1.7f)
        ) * 0.0018f * underwater;
        uv = clamp(uv + wobble, float2(0.001f), float2(0.999f));
    }

    float3 hdr = hdrColorTex.sample(linearSampler, uv).rgb;
    float exposure = uniforms.atmosphere.ambientColorAndExposure.w;
    float3 mapped = acesFilmicToneMap(hdr * exposure);

    float2 centered = in.uv - 0.5f;
    float vignette = 1.0f - dot(centered, centered) * (0.28f + 0.42f * underwater);
    mapped *= clamp(vignette, 0.55f, 1.0f);

    return float4(mapped, 1.0f);
}
