#include <metal_stdlib>
using namespace metal;

#include "../Shared/ShaderTypes.h"

constant uint kSpatialHashTableSize = 4096u;
constant uint kSpatialHashMaxPerCell = 16u;

static inline uint spatialHashCoord(int3 cell) {
    uint hx = uint(cell.x) * 73856093u;
    uint hy = uint(cell.y) * 19349663u;
    uint hz = uint(cell.z) * 83492791u;
    return (hx ^ hy ^ hz) & (kSpatialHashTableSize - 1u);
}

static inline int3 worldToHashCell(float3 pos, float cellSize) {
    float invCell = 1.0f / max(cellSize, 0.25f);
    return int3(floor(pos * invCell));
}

kernel void clearSpatialHashKernel(
    device atomic_uint* hashCounts [[buffer(BufferIndexHashCounts)]],
    uint gid                       [[thread_position_in_grid]]
) {
    if (gid >= kSpatialHashTableSize) { return; }
    atomic_store_explicit(&hashCounts[gid], 0u, memory_order_relaxed);
}

kernel void buildSpatialHashKernel(
    device const BoidAgent* boidsIn  [[buffer(BufferIndexBoidsIn)]],
    constant BoidsSimParams& params  [[buffer(BufferIndexBoidsParams)]],
    device atomic_uint* hashCounts   [[buffer(BufferIndexHashCounts)]],
    device uint* hashIndices         [[buffer(BufferIndexHashIndices)]],
    uint gid                         [[thread_position_in_grid]]
) {
    uint boidCount = uint(params.timeAndCounts.z);
    if (gid >= boidCount) { return; }

    float3 pos = boidsIn[gid].positionAndPhase.xyz;
    int3 cell = worldToHashCell(pos, params.weightsAndCell.w);
    uint bucket = spatialHashCoord(cell);

    uint slot = atomic_fetch_add_explicit(&hashCounts[bucket], 1u, memory_order_relaxed);
    if (slot < kSpatialHashMaxPerCell) {
        hashIndices[bucket * kSpatialHashMaxPerCell + slot] = gid;
    }
}

static inline float4x4 buildFishModelMatrix(float3 pos, float3 forward, float scale, float bankRoll) {
    float3 f = normalize(forward);
    float3 worldUp = float3(0.0f, 1.0f, 0.0f);
    float3 r = cross(worldUp, f);
    if (length_squared(r) < 1e-6f) {
        r = float3(1.0f, 0.0f, 0.0f);
    } else {
        r = normalize(r);
    }
    float3 u = cross(f, r);

    float cr = cos(bankRoll);
    float sr = sin(bankRoll);
    float3 rBank = r * cr + u * sr;
    float3 uBank = -r * sr + u * cr;

    return float4x4(
        float4(rBank * scale, 0.0f),
        float4(uBank * scale, 0.0f),
        float4(f * scale,     0.0f),
        float4(pos,           1.0f)
    );
}

kernel void stepBoidsKernel(
    device const BoidAgent* boidsIn           [[buffer(BufferIndexBoidsIn)]],
    device BoidAgent* boidsOut                [[buffer(BufferIndexBoidsOut)]],
    device FishInstanceData* instanceOut      [[buffer(BufferIndexFishInstances)]],
    constant BoidsSimParams& params           [[buffer(BufferIndexBoidsParams)]],
    device const uint* hashCounts             [[buffer(BufferIndexHashCounts)]],
    device const uint* hashIndices            [[buffer(BufferIndexHashIndices)]],
    device const PredatorThreat* predators    [[buffer(BufferIndexPredators)]],
    texture2d<float, access::sample> terrainHeightTex [[texture(TextureIndexTerrainHeight)]],
    uint gid                                  [[thread_position_in_grid]]
) {
    uint boidCount = uint(params.timeAndCounts.z);
    if (gid >= boidCount) { return; }

    constexpr sampler heightSampler(coord::normalized, address::clamp_to_edge, filter::linear);

    float dt = clamp(params.timeAndCounts.x, 0.001f, 0.05f);
    float elapsed = params.timeAndCounts.y;
    uint threatCount = uint(params.timeAndCounts.w);

    BoidAgent agent = boidsIn[gid];
    float3 pos = agent.positionAndPhase.xyz;
    float swimPhase = agent.positionAndPhase.w;
    float3 vel = agent.velocityAndSpeed.xyz;
    float cruiseSpeed = max(agent.velocityAndSpeed.w, 0.5f);
    float3 homeAnchor = agent.homeAndFear.xyz;
    float fear = agent.homeAndFear.w;

    float cellSize = params.weightsAndCell.w;
    float neighborRadius = params.radiiAndTerrain.x;
    float sepRadius = params.radiiAndTerrain.y;
    float neighborRadiusSq = neighborRadius * neighborRadius;
    float sepRadiusSq = sepRadius * sepRadius;

    int3 centerCell = worldToHashCell(pos, cellSize);
    float3 sepForce = float3(0.0f);
    float3 alignSum = float3(0.0f);
    float3 cohSum = float3(0.0f);
    uint neighborCount = 0u;

    for (int dz = -1; dz <= 1; ++dz) {
        for (int dy = -1; dy <= 1; ++dy) {
            for (int dx = -1; dx <= 1; ++dx) {
                uint bucket = spatialHashCoord(centerCell + int3(dx, dy, dz));
                uint count = min(hashCounts[bucket], kSpatialHashMaxPerCell);
                uint baseOffset = bucket * kSpatialHashMaxPerCell;

                for (uint s = 0u; s < count; ++s) {
                    uint otherIdx = hashIndices[baseOffset + s];
                    if (otherIdx == gid) { continue; }

                    BoidAgent other = boidsIn[otherIdx];
                    float3 diff = pos - other.positionAndPhase.xyz;
                    float distSq = dot(diff, diff);

                    if (distSq > 0.0001f && distSq < neighborRadiusSq) {
                        neighborCount += 1u;
                        alignSum += other.velocityAndSpeed.xyz;
                        cohSum += other.positionAndPhase.xyz;

                        if (distSq < sepRadiusSq) {
                            float invDist = rsqrt(distSq);
                            sepForce += diff * (invDist * invDist);
                        }
                    }
                }
            }
        }
    }

    float3 accel = float3(0.0f);
    if (neighborCount > 0u) {
        float invN = 1.0f / float(neighborCount);
        float3 avgVel = alignSum * invN;
        float3 centerOfMass = cohSum * invN;

        accel += sepForce * params.weightsAndCell.x;
        accel += (avgVel - vel) * params.weightsAndCell.y;
        accel += (centerOfMass - pos) * params.weightsAndCell.z;
    }

    float3 foodAnchor = mix(homeAnchor, params.attractorAndClarity.xyz, 0.65f);
    float3 toAnchor = foodAnchor - pos;
    float anchorDist = length(toAnchor);
    if (anchorDist > 2.5f) {
        accel += (toAnchor / anchorDist) * min(2.4f, (anchorDist - 2.5f) * 0.22f);
    }

    float wanderArg = elapsed * 0.85f + float(gid) * 0.37f;
    accel += float3(sin(wanderArg), cos(wanderArg * 0.7f) * 0.35f, cos(wanderArg * 0.9f)) * 0.55f;

    float3 current = params.currentAndSurface.xyz;
    accel += (current - vel * 0.25f) * 0.35f;

    float maxPanic = 0.0f;
    float3 fleeForce = float3(0.0f);
    for (uint t = 0u; t < threatCount; ++t) {
        float3 threatPos = predators[t].positionAndRadius.xyz;
        float threatRad = max(predators[t].positionAndRadius.w, 0.5f);
        float threatPower = predators[t].velocityAndIntensity.w;

        float3 away = pos - threatPos;
        float dSq = dot(away, away);
        if (dSq < threatRad * threatRad && threatPower > 0.05f) {
            float d = sqrt(max(dSq, 0.001f));
            float proximity = 1.0f - (d / threatRad);
            float3 radialDir = away / d;
            float3 scatterDir = normalize(radialDir + float3(sin(float(gid) * 1.7f), 0.15f, cos(float(gid) * 2.3f)) * 0.35f);
            fleeForce += scatterDir * (proximity * proximity * 26.0f * threatPower);
            maxPanic = max(maxPanic, proximity * threatPower);
        }
    }

    fear = max(maxPanic, fear * exp(-dt * 1.45f));
    accel += fleeForce;

    float terrainHalf = max(params.radiiAndTerrain.z, 10.0f);
    float2 heightUV = (pos.xz / (terrainHalf * 2.0f)) + 0.5f;
    float bedY = terrainHeightTex.sample(heightSampler, clamp(heightUV, float2(0.01f), float2(0.99f))).r;

    float surfaceY = params.currentAndSurface.w;
    float minClearance = bedY + 0.65f;
    float maxCeil = surfaceY - 0.35f;

    if (pos.y < minClearance) {
        accel.y += (minClearance - pos.y) * 18.0f;
    }
    if (pos.y > maxCeil) {
        accel.y -= (pos.y - maxCeil) * 16.0f;
    }

    float boundR = params.radiiAndTerrain.w;
    float horizDist = length(pos.xz);
    if (horizDist > boundR) {
        accel.xz -= (pos.xz / horizDist) * (horizDist - boundR) * 1.8f;
    }
    if (pos.z > 16.0f) {
        accel.z -= (pos.z - 16.0f) * 3.2f;
    }

    float3 prevDir = (length_squared(vel) > 0.0001f) ? normalize(vel) : float3(0.0f, 0.0f, -1.0f);
    vel += accel * dt;

    float maxAllowedSpeed = cruiseSpeed * (1.0f + fear * 2.6f);
    float minAllowedSpeed = cruiseSpeed * 0.45f;
    float speed = length(vel);
    if (speed > maxAllowedSpeed) {
        vel = (vel / speed) * maxAllowedSpeed;
        speed = maxAllowedSpeed;
    } else if (speed < minAllowedSpeed) {
        vel = (speed > 0.001f ? (vel / speed) : prevDir) * minAllowedSpeed;
        speed = minAllowedSpeed;
    }

    pos += vel * dt;
    pos.y = clamp(pos.y, bedY + 0.25f, surfaceY - 0.18f);

    float3 newDir = normalize(vel);
    float crossY = prevDir.x * newDir.z - prevDir.z * newDir.x;
    float targetCurv = clamp(crossY * 14.0f, -1.0f, 1.0f);
    float smoothCurv = mix(agent.metaParams.z, targetCurv, clamp(dt * 8.0f, 0.0f, 1.0f));

    float tailFreq = 6.5f + speed * 5.8f + fear * 8.0f;
    swimPhase = fmod(swimPhase + dt * tailFreq, 628.31853f);

    BoidAgent nextState = agent;
    nextState.positionAndPhase = float4(pos, swimPhase);
    nextState.velocityAndSpeed = float4(vel, cruiseSpeed);
    nextState.homeAndFear = float4(homeAnchor, fear);
    nextState.metaParams.z = smoothCurv;
    boidsOut[gid] = nextState;

    float bodyScale = agent.metaParams.x;
    float4x4 modelMat = buildFishModelMatrix(pos, newDir, bodyScale, smoothCurv * 0.32f);

    FishInstanceData inst;
    inst.modelMatrix = modelMat;
    inst.swimParams = float4(swimPhase, tailFreq, 0.11f + fear * 0.08f, 0.14f * bodyScale);
    inst.dorsalColorAndSpecies = float4(params.dorsalAndIridescence.xyz, agent.metaParams.y);
    inst.ventralColorAndIridescence = float4(0.88f, 0.92f, 0.96f, params.dorsalAndIridescence.w);
    inst.biomechParams = float4(speed, smoothCurv, elapsed * 3.5f + float(gid), 0.0f);
    inst.breachAndShakeParams = float4(0.0f, 0.0f, 0.0f, 0.0f);
    instanceOut[gid] = inst;
}
