#include <metal_stdlib>
using namespace metal;

#include "../Shared/ShaderTypes.h"

struct FishVertexOut {
    float4 position [[position]];
    float3 worldPos;
    float3 worldNormal;
    float3 worldTangent;
    float3 worldBitangent;
    float2 uv;
    float ao;
    float partID;
    float dorsalFactor;
    float finRayCoord;
    float sssThickness;
    float3 dorsalTint;
    float3 ventralTint;
    float iridescenceStrength;
};

vertex FishVertexOut fishVertexShader(
    uint vid [[vertex_id]],
    uint iid [[instance_id]],
    device const FishVertex* vertices        [[buffer(BufferIndexVertices)]],
    constant Uniforms& uniforms              [[buffer(BufferIndexUniforms)]],
    device const FishInstanceData* instances [[buffer(BufferIndexFishInstances)]]
) {
    FishVertex v = vertices[vid];
    FishInstanceData inst = instances[iid];

    float3 localPos = v.position.xyz;
    float3 localN = v.normal.xyz;
    float3 localT = v.tangent.xyz;

    float spineT = v.uvAndWeights.z;
    float finWeight = v.uvAndWeights.w;

    float swimPhase = inst.swimParams.x;
    float tailAmp = inst.swimParams.z;
    float bodyLen = max(inst.swimParams.w, 0.1f);

    float waveEnvelope = 0.05f + 0.95f * spineT * spineT;
    float waveArg = spineT * 5.4f - swimPhase;
    float lateralDisp = sin(waveArg) * tailAmp * waveEnvelope * bodyLen;

    float finFlutter = sin(waveArg - finWeight * 1.45f) * tailAmp * 0.35f * finWeight * bodyLen;
    localPos.x += lateralDisp + finFlutter;

    float dWaveDz = cos(waveArg) * 5.4f * tailAmp * waveEnvelope;
    float cosYaw = rsqrt(1.0f + dWaveDz * dWaveDz);
    float sinYaw = dWaveDz * cosYaw;

    float3 bentN = normalize(float3(
        localN.x * cosYaw - localN.z * sinYaw,
        localN.y,
        localN.x * sinYaw + localN.z * cosYaw
    ));
    float3 bentT = normalize(float3(
        localT.x * cosYaw - localT.z * sinYaw,
        localT.y,
        localT.x * sinYaw + localT.z * cosYaw
    ));

    float4 worldPos4 = inst.modelMatrix * float4(localPos, 1.0f);
    float3x3 normalMat = float3x3(
        inst.modelMatrix.columns[0].xyz,
        inst.modelMatrix.columns[1].xyz,
        inst.modelMatrix.columns[2].xyz
    );

    float3 wN = normalize(normalMat * bentN);
    float3 wT = normalize(normalMat * bentT);
    wT = normalize(wT - wN * dot(wN, wT));
    float3 wB = cross(wN, wT) * v.tangent.w;

    FishVertexOut out;
    out.position = uniforms.camera.viewProjectionMatrix * worldPos4;
    out.worldPos = worldPos4.xyz;
    out.worldNormal = wN;
    out.worldTangent = wT;
    out.worldBitangent = wB;
    out.uv = v.uvAndWeights.xy;
    out.ao = v.normal.w;
    out.partID = v.anatomyMask.x;
    out.dorsalFactor = v.anatomyMask.y;
    out.finRayCoord = v.anatomyMask.z;
    out.sssThickness = v.anatomyMask.w;
    out.dorsalTint = inst.dorsalColorAndSpecies.xyz;
    out.ventralTint = inst.ventralColorAndIridescence.xyz;
    out.iridescenceStrength = inst.ventralColorAndIridescence.w;
    return out;
}

static inline float distributionGGX(float NdotH, float roughness) {
    float a = max(roughness * roughness, 0.002f);
    float a2 = a * a;
    float denom = (NdotH * NdotH) * (a2 - 1.0f) + 1.0f;
    return a2 / (3.14159265f * denom * denom + 0.0001f);
}

static inline float geometrySchlickGGX(float NdotX, float roughness) {
    float r = roughness + 1.0f;
    float k = (r * r) * 0.125f;
    return NdotX / (NdotX * (1.0f - k) + k + 0.0001f);
}

static inline float geometrySmith(float NdotV, float NdotL, float roughness) {
    return geometrySchlickGGX(NdotV, roughness) * geometrySchlickGGX(NdotL, roughness);
}

static inline float3 fresnelSchlick(float cosTheta, float3 F0) {
    return F0 + (1.0f - F0) * pow(clamp(1.0f - cosTheta, 0.0f, 1.0f), 5.0f);
}

static inline float3 evaluateThinFilmIridescence(float cosThetaV, float filmThicknessNorm) {
    float dNm = mix(280.0f, 760.0f, filmThicknessNorm);
    float nFilm = 1.83f;
    float sin2T = (1.0f - cosThetaV * cosThetaV) / (nFilm * nFilm);
    float cosT = sqrt(max(1.0f - sin2T, 0.01f));
    float opd = 2.0f * nFilm * dNm * cosT;

    float3 lambda = float3(650.0f, 532.0f, 460.0f);
    float3 phase = (6.2831853f * opd) / lambda;
    return 0.5f + 0.5f * cos(phase);
}

fragment float4 fishFragmentShader(
    FishVertexOut in [[stage_in]],
    constant Uniforms& uniforms                        [[buffer(BufferIndexUniforms)]],
    texture2d<float, access::sample> albedoTex         [[texture(TextureIndexAlbedo)]],
    texture2d<float, access::sample> normalTex         [[texture(TextureIndexNormal)]],
    texture2d<float, access::sample> roughnessMetaTex  [[texture(TextureIndexRoughnessMeta)]],
    texture2d<float, access::sample> iridescenceTex    [[texture(TextureIndexIridescence)]]
) {
    constexpr sampler pbrSampler(coord::normalized, address::repeat, filter::linear, mip_filter::linear);

    float3 camPos = uniforms.camera.positionAndFov.xyz;
    float3 toCam = camPos - in.worldPos;
    float dist = length(toCam);
    float3 V = toCam / max(dist, 0.0001f);

    float3 sunDir = normalize(uniforms.atmosphere.sunDirectionAndElevation.xyz);
    float3 sunRadiance = uniforms.atmosphere.sunColorAndIntensity.xyz * uniforms.atmosphere.sunColorAndIntensity.w;
    float sunDay = smoothstep(-0.10f, 0.22f, sunDir.y);

    float3 geomN = normalize(in.worldNormal);
    float3 T = normalize(in.worldTangent);
    float3 B = normalize(in.worldBitangent);
    float3x3 TBN = float3x3(T, B, geomN);

    float part = round(in.partID);

    float3 texAlbedo = albedoTex.sample(pbrSampler, in.uv).rgb;
    float3 mapN = normalTex.sample(pbrSampler, in.uv).xyz * 2.0f - 1.0f;
    float4 roughMeta = roughnessMetaTex.sample(pbrSampler, in.uv);
    float4 iridData = iridescenceTex.sample(pbrSampler, in.uv);

    float3 N = geomN;
    float3 baseColor = texAlbedo;
    float roughness = roughMeta.r;
    float metallic = roughMeta.g;
    float ao = in.ao * roughMeta.b;
    float clearcoatWeight = roughMeta.a;
    float alpha = 1.0f;
    float3 sssContribution = float3(0.0f);

    if (part < 0.5f || abs(part - 2.0f) < 0.5f) {
        N = normalize(TBN * mapN);
        float3 speciesGrad = mix(in.ventralTint, in.dorsalTint, in.dorsalFactor);
        baseColor = mix(texAlbedo, speciesGrad * (0.65f + 0.65f * texAlbedo), 0.72f);
        if (abs(part - 2.0f) < 0.5f) {
            roughness = max(0.14f, roughness * 0.78f);
            metallic = min(0.85f, metallic + 0.15f);
        }
    } else if (abs(part - 1.0f) < 0.5f) {
        float rayStripe = 0.5f + 0.5f * sin(in.finRayCoord * 6.2831853f);
        float3 finTint = mix(in.dorsalTint * 1.15f, in.ventralTint * 0.85f, 1.0f - in.sssThickness);
        baseColor = finTint * (0.72f + 0.35f * rayStripe);
        roughness = 0.28f;
        metallic = 0.08f;
        clearcoatWeight = 0.65f;
        alpha = clamp(0.42f + 0.52f * in.sssThickness + 0.18f * rayStripe, 0.35f, 0.96f);

        float3 sssDir = normalize(-sunDir + N * 0.38f);
        float sssGlow = pow(clamp(dot(V, sssDir), 0.0f, 1.0f), 3.0f);
        float edgeThinness = 1.0f - in.sssThickness;
        float3 sssColor = mix(float3(0.85f, 0.52f, 0.32f), in.dorsalTint * 1.6f, 0.45f);
        sssContribution = sssColor * sunRadiance * sssGlow * edgeThinness * 0.65f * sunDay;
    } else if (abs(part - 3.0f) < 0.5f) {
        float rEye = length(in.uv - float2(0.5f));
        float pupilMask = 1.0f - smoothstep(0.17f, 0.21f, rEye);
        float irisRing = smoothstep(0.20f, 0.26f, rEye) * (1.0f - smoothstep(0.42f, 0.49f, rEye));
        float3 irisCol = mix(float3(0.76f, 0.58f, 0.20f), float3(0.22f, 0.16f, 0.08f), smoothstep(0.24f, 0.46f, rEye));
        baseColor = mix(float3(0.08f, 0.09f, 0.09f), irisCol, irisRing);
        baseColor = mix(baseColor, float3(0.01f, 0.01f, 0.015f), pupilMask);
        roughness = 0.18f;
        metallic = 0.20f;
        clearcoatWeight = 0.40f;
    } else {
        float NdotVCornea = max(dot(N, V), 0.001f);
        float fresnelCornea = 0.04f + 0.96f * pow(1.0f - NdotVCornea, 5.0f);
        float3 Hc = normalize(sunDir + V);
        float specCornea = distributionGGX(max(dot(N, Hc), 0.0f), 0.035f) * fresnelCornea * 0.35f;
        float3 corneaColor = uniforms.atmosphere.skyHorizonColorAndFog.xyz * fresnelCornea * 0.65f +
                             sunRadiance * specCornea * sunDay;
        return float4(corneaColor, clamp(fresnelCornea * 0.72f + 0.12f, 0.12f, 0.88f));
    }

    float3 L = sunDir;
    float3 H = normalize(V + L);
    float NdotV = max(dot(N, V), 0.001f);
    float NdotL = max(dot(N, L), 0.0f);
    float NdotH = max(dot(N, H), 0.0f);
    float HdotV = max(dot(H, V), 0.0f);

    float3 F0 = mix(float3(0.04f), baseColor, metallic);

    float iridFactor = iridData.g * in.iridescenceStrength * (part < 0.5f ? 1.0f : 0.25f);
    float3 thinFilm = evaluateThinFilmIridescence(NdotV, iridData.r);
    F0 = mix(F0, F0 * (0.55f + 0.95f * thinFilm), iridFactor);

    float D = distributionGGX(NdotH, roughness);
    float G = geometrySmith(NdotV, NdotL, roughness);
    float3 F = fresnelSchlick(HdotV, F0);

    float3 kS = F;
    float3 kD = (1.0f - kS) * (1.0f - metallic);
    float3 diffuse = kD * baseColor / 3.14159265f;
    float3 specular = (D * G * F) / (4.0f * NdotV * NdotL + 0.0001f);

    float coatRoughness = 0.045f;
    float Dcoat = distributionGGX(NdotH, coatRoughness);
    float Gcoat = geometrySmith(NdotV, NdotL, coatRoughness);
    float Fcoat = (0.03f + 0.97f * pow(1.0f - HdotV, 5.0f)) * clearcoatWeight;
    float3 coatSpec = float3((Dcoat * Gcoat * Fcoat) / (4.0f * NdotV * NdotL + 0.0001f));

    float surfaceY = uniforms.water.deepColorAndSurfaceY.w;
    float subDepth = max(0.0f, surfaceY - in.worldPos.y);
    float3 lightTrans = (in.worldPos.y < surfaceY)
        ? exp(-uniforms.water.absorptionAndClarity.xyz * subDepth * 0.60f)
        : float3(1.0f);

    float3 directRadiance = sunRadiance * lightTrans * sunDay * 0.42f;
    float3 color = ((diffuse + specular) * (1.0f - Fcoat * 0.75f) + coatSpec) * directRadiance * NdotL;

    float3 hemiTop = mix(uniforms.atmosphere.ambientColorAndExposure.xyz, uniforms.water.shallowColorAndFoam.xyz * 0.75f, smoothstep(0.0f, 1.5f, subDepth));
    float3 hemiBot = uniforms.water.deepColorAndSurfaceY.xyz * 0.55f;
    float3 ambientLight = mix(hemiBot, hemiTop, N.y * 0.5f + 0.5f);
    float rimIrid = pow(1.0f - NdotV, 3.2f) * iridFactor * 0.35f;

    color += baseColor * ambientLight * ao + thinFilm * hemiTop * rimIrid + sssContribution * lightTrans;

    float underwaterCam = uniforms.camera.upAndUnderwater.w;
    if (underwaterCam > 0.01f && in.worldPos.y < surfaceY + 0.25f) {
        float3 waterTrans = exp(-uniforms.water.absorptionAndClarity.xyz * dist * 0.62f);
        float3 waterFog = mix(
            uniforms.water.deepColorAndSurfaceY.xyz * 0.55f,
            uniforms.water.shallowColorAndFoam.xyz * 0.65f,
            exp(-subDepth * 0.15f)
        ) * (0.25f + 0.75f * sunDay);
        color = mix(color, mix(waterFog, color, waterTrans), underwaterCam);
    }

    return float4(color, alpha);
}
