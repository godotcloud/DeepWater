#include <metal_stdlib>
using namespace metal;

#include "../Shared/ShaderTypes.h"

struct TerrainVertexOut {
    float4 position [[position]];
    float3 worldPos;
    float3 normal;
    float ao;
    float materialBlend;
    float roughness;
};

static inline float terrainHash21(float2 p) {
    p = fract(p * float2(127.1f, 311.7f));
    p += dot(p, p + 34.53f);
    return fract(p.x * p.y);
}

static inline float2 terrainHash22(float2 p) {
    float3 p3 = fract(float3(p.xyx) * float3(0.1031f, 0.1030f, 0.0973f));
    p3 += dot(p3, p3.yzx + 33.33f);
    return fract((p3.xx + p3.yz) * p3.zy);
}

static inline float terrainNoise2D(float2 p) {
    float2 i = floor(p);
    float2 f = fract(p);
    float2 u = f * f * (3.0f - 2.0f * f);

    float a = terrainHash21(i);
    float b = terrainHash21(i + float2(1.0f, 0.0f));
    float c = terrainHash21(i + float2(0.0f, 1.0f));
    float d = terrainHash21(i + float2(1.0f, 1.0f));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

static inline float terrainVoronoiCell(float2 uv, float time) {
    float2 g = floor(uv);
    float2 f = fract(uv);
    float d1 = 8.0f;
    float d2 = 8.0f;

    for (int y = -1; y <= 1; ++y) {
        for (int x = -1; x <= 1; ++x) {
            float2 cell = float2(float(x), float(y));
            float2 rnd = terrainHash22(g + cell);
            float2 pt = 0.5f + 0.42f * sin(time + 6.2831853f * rnd);
            float dist = length(cell + pt - f);
            if (dist < d1) {
                d2 = d1;
                d1 = dist;
            } else if (dist < d2) {
                d2 = dist;
            }
        }
    }
    float edge = clamp(d2 - d1, 0.0f, 1.0f);
    return pow(1.0f - smoothstep(0.0f, 0.26f, edge), 2.5f);
}

static inline float3 evaluateTerrainCaustics(float3 worldPos, float3 sunDir, constant WaterParams& water) {
    float time = water.gridParams.z;
    float scale = water.causticParams.y;
    float speed = water.causticParams.z;
    float surfaceY = water.deepColorAndSurfaceY.w;

    float depth = max(0.0f, surfaceY - worldPos.y);
    float3 refractedSun = normalize(float3(sunDir.x * 0.75f, max(sunDir.y, 0.25f), sunDir.z * 0.75f));
    float2 projectedXZ = worldPos.xz + refractedSun.xz * (depth / max(refractedSun.y, 0.25f));

    float2 p1 = projectedXZ * scale + float2(time * speed * 0.24f, -time * speed * 0.17f);
    float2 p2 = projectedXZ * (scale * 1.47f) + float2(-time * speed * 0.20f, time * speed * 0.29f);
    float2 chroma = float2(0.04f, -0.025f);

    float r = terrainVoronoiCell(p1 + chroma, time * speed) * 0.65f +
              terrainVoronoiCell(p2 - chroma, time * speed * 1.12f) * 0.65f;
    float g = terrainVoronoiCell(p1, time * speed) * 0.65f +
              terrainVoronoiCell(p2, time * speed * 1.12f) * 0.65f;
    float b = terrainVoronoiCell(p1 - chroma, time * speed) * 0.65f +
              terrainVoronoiCell(p2 + chroma, time * speed * 1.12f) * 0.65f;

    float depthFade = exp(-depth * 0.14f) * smoothstep(0.0f, 0.25f, depth);
    return float3(r, g, b) * depthFade * water.causticParams.x;
}

static inline float3 evaluateVolumetricGodRays(
    float3 camPos,
    float3 worldPos,
    float3 sunDir,
    constant Uniforms& uniforms
) {
    float underwater = uniforms.camera.upAndUnderwater.w;
    float sunDay = smoothstep(0.02f, 0.28f, sunDir.y);
    if (underwater < 0.02f || sunDay < 0.01f) {
        return float3(0.0f);
    }

    float surfaceY = uniforms.water.deepColorAndSurfaceY.w;
    float3 rayVec = worldPos - camPos;
    float rayLen = min(length(rayVec), 34.0f);
    float3 rayDir = rayVec / max(length(rayVec), 0.0001f);

    float cosTheta = clamp(dot(rayDir, sunDir), -1.0f, 1.0f);
    float g = 0.68f;
    float g2 = g * g;
    float phase = (1.0f - g2) / (4.0f * 3.14159265f * pow(max(1.0f + g2 - 2.0f * g * cosTheta, 0.02f), 1.5f));

    float time = uniforms.water.gridParams.z;
    float3 refractedSun = normalize(float3(sunDir.x * 0.75f, max(sunDir.y, 0.28f), sunDir.z * 0.75f));

    const int steps = 8;
    float stepLen = rayLen / float(steps);
    float jitter = terrainHash21(worldPos.xz * 7.3f + float2(time * 0.3f, 0.17f));

    float accum = 0.0f;
    for (int i = 0; i < steps; ++i) {
        float t = (float(i) + jitter) * stepLen;
        float3 samplePos = camPos + rayDir * t;
        if (samplePos.y < surfaceY) {
            float depth = surfaceY - samplePos.y;
            float2 surfaceHit = samplePos.xz + refractedSun.xz * (depth / max(refractedSun.y, 0.25f));
            float waveBeam1 = terrainNoise2D(surfaceHit * 0.34f + float2(time * 0.22f, -time * 0.14f));
            float waveBeam2 = terrainNoise2D(surfaceHit * 0.72f + float2(-time * 0.18f, time * 0.25f));
            float shaft = smoothstep(0.42f, 0.88f, waveBeam1 * 0.6f + waveBeam2 * 0.4f);
            float atten = exp(-depth * uniforms.water.godRayParams.y) * exp(-t * 0.045f);
            accum += shaft * atten * stepLen;
        }
    }

    float3 beamColor = mix(uniforms.water.shallowColorAndFoam.xyz, uniforms.atmosphere.sunColorAndIntensity.xyz, 0.45f);
    return beamColor * accum * (0.35f + phase * 1.4f) * uniforms.water.godRayParams.x * underwater * sunDay * 0.16f;
}

vertex TerrainVertexOut terrainVertexShader(
    uint vid [[vertex_id]],
    device const Vertex* vertices [[buffer(BufferIndexVertices)]],
    constant Uniforms& uniforms [[buffer(BufferIndexUniforms)]]
) {
    Vertex v = vertices[vid];

    TerrainVertexOut out;
    out.worldPos = v.position.xyz;
    out.normal = normalize(v.normal.xyz);
    out.ao = v.normal.w;
    out.materialBlend = v.uvAndMaterial.z;
    out.roughness = v.uvAndMaterial.w;
    out.position = uniforms.camera.viewProjectionMatrix * float4(v.position.xyz, 1.0f);
    return out;
}

fragment float4 terrainFragmentShader(
    TerrainVertexOut in [[stage_in]],
    constant Uniforms& uniforms [[buffer(BufferIndexUniforms)]]
) {
    float3 N = normalize(in.normal);
    float3 camPos = uniforms.camera.positionAndFov.xyz;
    float3 toCam = camPos - in.worldPos;
    float dist = length(toCam);
    float3 V = toCam / max(dist, 0.0001f);

    float3 sunDir = normalize(uniforms.atmosphere.sunDirectionAndElevation.xyz);
    float3 sunRadiance = uniforms.atmosphere.sunColorAndIntensity.xyz * uniforms.atmosphere.sunColorAndIntensity.w;
    float sunDay = smoothstep(-0.10f, 0.22f, sunDir.y);

    float nFine = terrainNoise2D(in.worldPos.xz * 2.4f);
    float nMicro = terrainNoise2D(in.worldPos.xz * 11.5f);
    float rippleSand = sin(in.worldPos.x * 3.8f + nFine * 4.5f) * 0.5f + 0.5f;

    float3 sandAlbedo = mix(float3(0.46f, 0.41f, 0.31f), float3(0.58f, 0.52f, 0.40f), rippleSand * 0.5f + nMicro * 0.5f);
    float3 gravelAlbedo = mix(float3(0.24f, 0.23f, 0.20f), float3(0.36f, 0.34f, 0.29f), nMicro);
    float3 rockAlbedo = mix(float3(0.11f, 0.12f, 0.13f), float3(0.22f, 0.23f, 0.21f), nFine * 0.6f + nMicro * 0.4f);

    float surfaceY = uniforms.water.deepColorAndSurfaceY.w;
    float subDepth = max(0.0f, surfaceY - in.worldPos.y);
    float algaeMask = smoothstep(0.3f, 1.5f, subDepth) * (1.0f - smoothstep(4.5f, 9.5f, subDepth)) * in.materialBlend;
    rockAlbedo = mix(rockAlbedo, float3(0.10f, 0.19f, 0.11f), algaeMask * 0.45f);

    float3 albedo = mix(sandAlbedo, gravelAlbedo, smoothstep(0.15f, 0.55f, in.materialBlend));
    albedo = mix(albedo, rockAlbedo, smoothstep(0.50f, 0.88f, in.materialBlend));

    float wetBand = 1.0f - smoothstep(-0.1f, 0.65f, in.worldPos.y - surfaceY);
    albedo *= mix(1.0f, 0.62f, wetBand);

    float NdotL = max(dot(N, sunDir), 0.0f);
    float3 directLight = sunRadiance * NdotL * 0.36f * sunDay;
    float3 ambient = uniforms.atmosphere.ambientColorAndExposure.xyz * (0.45f + 0.55f * (N.y * 0.5f + 0.5f));

    float3 causticLight = float3(0.0f);
    if (in.worldPos.y < surfaceY) {
        float3 downTrans = exp(-uniforms.water.absorptionAndClarity.xyz * subDepth * 0.65f);
        directLight *= downTrans;
        causticLight = evaluateTerrainCaustics(in.worldPos, sunDir, uniforms.water) *
                       sunRadiance * max(N.y, 0.15f) * sunDay * 0.28f;
    }

    float3 color = albedo * (directLight + ambient * in.ao + causticLight);

    float3 H = normalize(sunDir + V);
    float specPow = mix(12.0f, 48.0f, wetBand);
    float spec = pow(max(dot(N, H), 0.0f), specPow) * (0.04f + 0.14f * wetBand) * sunDay;
    color += sunRadiance * spec * 0.18f;

    float underwaterCam = uniforms.camera.upAndUnderwater.w;
    if (underwaterCam > 0.01f && in.worldPos.y < surfaceY + 0.5f) {
        float3 waterTrans = exp(-uniforms.water.absorptionAndClarity.xyz * dist * 0.62f);
        float3 waterFog = mix(
            uniforms.water.deepColorAndSurfaceY.xyz * 0.55f,
            uniforms.water.shallowColorAndFoam.xyz * 0.65f,
            exp(-subDepth * 0.15f)
        ) * (0.25f + 0.75f * sunDay);

        float3 underwaterColor = mix(waterFog, color, waterTrans);
        underwaterColor += evaluateVolumetricGodRays(camPos, in.worldPos, sunDir, uniforms);
        color = mix(color, underwaterColor, underwaterCam);
    } else {
        float fogFactor = 1.0f - exp(-dist * uniforms.atmosphere.skyHorizonColorAndFog.w);
        color = mix(color, uniforms.atmosphere.skyHorizonColorAndFog.xyz * (0.35f + 0.65f * sunDay), clamp(fogFactor, 0.0f, 0.92f));
    }

    return float4(color, 1.0f);
}
