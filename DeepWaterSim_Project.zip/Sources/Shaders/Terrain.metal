#include <metal_stdlib>
using namespace metal;

#include "../Shared/ShaderTypes.h"

struct TerrainVertexOut {
    float4 position [[position]];
    float3 worldPos;
    float3 normal;
    float ao;
    float materialBlend;
    float roughness;
};

static inline float terrainHash21(float2 p) {
    p = fract(p * float2(127.1f, 311.7f));
    p += dot(p, p + 34.53f);
    return fract(p.x * p.y);
}

static inline float terrainFastCaustic(float2 p, float time) {
    float2 p1 = p * 2.1f + float2(time * 0.55f, -time * 0.42f);
    float2 p2 = p * 2.9f + float2(-time * 0.48f, time * 0.62f);
    float w1 = sin(p1.x + sin(p1.y * 1.15f + time)) * cos(p1.y + cos(p1.x * 1.12f - time));
    float w2 = sin(p2.x - cos(p2.y * 1.25f - time * 0.8f)) * cos(p2.y + sin(p2.x * 0.95f + time * 1.1f));
    float ridge = 1.0f - abs(w1 * 0.55f + w2 * 0.45f);
    return pow(clamp(ridge, 0.0f, 1.0f), 4.0f);
}

static inline float3 evaluateTerrainCaustics(float3 worldPos, float3 sunDir, constant WaterParams& water) {
    float time = water.gridParams.z;
    float scale = water.causticParams.y;
    float speed = water.causticParams.z;
    float surfaceY = water.deepColorAndSurfaceY.w;

    float depth = max(0.0f, surfaceY - worldPos.y);
    float3 refractedSun = normalize(float3(sunDir.x * 0.75f, max(sunDir.y, 0.25f), sunDir.z * 0.75f));
    float2 projectedXZ = (worldPos.xz + refractedSun.xz * (depth / max(refractedSun.y, 0.25f))) * scale;
    float t = time * speed;

    float r = terrainFastCaustic(projectedXZ + float2(0.04f, -0.02f), t);
    float g = terrainFastCaustic(projectedXZ, t);
    float b = terrainFastCaustic(projectedXZ - float2(0.04f, -0.02f), t);

    float depthFade = exp(-depth * 0.14f) * smoothstep(0.0f, 0.25f, depth);
    return float3(r, g, b) * depthFade * water.causticParams.x;
}

static inline float3 evaluateVolumetricGodRays(
    float3 camPos,
    float3 worldPos,
    float3 sunDir,
    constant Uniforms& uniforms
) {
    float underwater = uniforms.camera.upAndUnderwater.w;
    float sunDay = smoothstep(0.02f, 0.28f, sunDir.y);
    if (underwater < 0.02f || sunDay < 0.01f) {
        return float3(0.0f);
    }

    float surfaceY = uniforms.water.deepColorAndSurfaceY.w;
    float3 rayVec = worldPos - camPos;
    float rayLen = min(length(rayVec), 28.0f);
    float3 rayDir = rayVec / max(length(rayVec), 0.0001f);

    float cosTheta = clamp(dot(rayDir, sunDir), -1.0f, 1.0f);
    float g = 0.68f;
    float g2 = g * g;
    float phase = (1.0f - g2) / (4.0f * 3.14159265f * pow(max(1.0f + g2 - 2.0f * g * cosTheta, 0.02f), 1.5f));

    float time = uniforms.water.gridParams.z;
    float3 refractedSun = normalize(float3(sunDir.x * 0.75f, max(sunDir.y, 0.28f), sunDir.z * 0.75f));

    const int steps = 4;
    float stepLen = rayLen / float(steps);
    float jitter = terrainHash21(worldPos.xz * 7.3f + float2(time * 0.3f, 0.17f));

    float accum = 0.0f;
    for (int i = 0; i < steps; ++i) {
        float t = (float(i) + jitter) * stepLen;
        float3 samplePos = camPos + rayDir * t;
        if (samplePos.y < surfaceY) {
            float depth = surfaceY - samplePos.y;
            float2 surfaceHit = samplePos.xz + refractedSun.xz * (depth / max(refractedSun.y, 0.25f));
            float waveBeam = 0.5f + 0.5f * sin(surfaceHit.x * 0.55f + time * 0.6f) * cos(surfaceHit.y * 0.55f - time * 0.45f);
            float shaft = smoothstep(0.45f, 0.90f, waveBeam);
            float atten = exp(-depth * uniforms.water.godRayParams.y) * exp(-t * 0.045f);
            accum += shaft * atten * stepLen;
        }
    }

    float3 beamColor = mix(uniforms.water.shallowColorAndFoam.xyz, uniforms.atmosphere.sunColorAndIntensity.xyz, 0.45f);
    return beamColor * accum * (0.35f + phase * 1.4f) * uniforms.water.godRayParams.x * underwater * sunDay * 0.18f;
}

vertex TerrainVertexOut terrainVertexShader(
    uint vid [[vertex_id]],
    device const Vertex* vertices [[buffer(BufferIndexVertices)]],
    constant Uniforms& uniforms [[buffer(BufferIndexUniforms)]]
) {
    Vertex v = vertices[vid];

    TerrainVertexOut out;
    out.worldPos = v.position.xyz;
    out.normal = normalize(v.normal.xyz);
    out.ao = v.normal.w;
    out.materialBlend = v.uvAndMaterial.z;
    out.roughness = v.uvAndMaterial.w;
    out.position = uniforms.camera.viewProjectionMatrix * float4(v.position.xyz, 1.0f);
    return out;
}

fragment float4 terrainFragmentShader(
    TerrainVertexOut in [[stage_in]],
    constant Uniforms& uniforms                        [[buffer(BufferIndexUniforms)]],
    texture2d<float, access::sample> seabedAlbedoTex   [[texture(TextureIndexAlbedo)]],
    texture2d<float, access::sample> seabedNormalTex   [[texture(TextureIndexNormal)]],
    texture2d<float, access::sample> seabedRoughTex    [[texture(TextureIndexRoughnessMeta)]]
) {
    constexpr sampler tileSampler(coord::normalized, address::repeat, filter::linear, mip_filter::linear);

    // Dual-octave rotated sampling breaks up repeating Voronoi pebble tiling into natural fine river sand & gravel
    float2 uvA = in.worldPos.xz * 0.34f;
    float2 rotXZ = float2(in.worldPos.x * 0.7986f - in.worldPos.z * 0.6018f,
                          in.worldPos.x * 0.6018f + in.worldPos.z * 0.7986f);
    float2 uvB = rotXZ * 0.78f + float2(3.7f, 1.9f);

    float3 bakedAlbedo = seabedAlbedoTex.sample(tileSampler, uvA).rgb * 0.55f +
                         seabedAlbedoTex.sample(tileSampler, uvB).rgb * 0.45f;
    float3 bakedNormal = (seabedNormalTex.sample(tileSampler, uvA).xyz * 2.0f - 1.0f) * 0.55f +
                         (seabedNormalTex.sample(tileSampler, uvB).xyz * 2.0f - 1.0f) * 0.45f;
    float4 bakedRough = seabedRoughTex.sample(tileSampler, uvA);

    float3 geomN = normalize(in.normal);
    float3 T = normalize(cross(geomN, float3(0.0f, 0.0f, 1.0f) + float3(0.001f, 0.0f, 0.0f)));
    float3 B = cross(geomN, T);
    float3 N = normalize(T * bakedNormal.x * 0.36f + B * bakedNormal.y * 0.36f + geomN);

    float3 camPos = uniforms.camera.positionAndFov.xyz;
    float3 toCam = camPos - in.worldPos;
    float dist = length(toCam);
    float3 V = toCam / max(dist, 0.0001f);

    float3 sunDir = normalize(uniforms.atmosphere.sunDirectionAndElevation.xyz);
    float3 sunRadiance = uniforms.atmosphere.sunColorAndIntensity.xyz * uniforms.atmosphere.sunColorAndIntensity.w;
    float sunDay = smoothstep(-0.10f, 0.22f, sunDir.y);

    // Subtle organic river-sand ripple modulation
    float sandRipple = 0.5f + 0.5f * sin(in.worldPos.x * 4.2f + sin(in.worldPos.z * 1.4f) * 1.8f);
    float3 sandTint = mix(float3(0.42f, 0.37f, 0.28f), float3(0.52f, 0.46f, 0.35f), sandRipple);
    float3 rockTint = float3(0.15f, 0.16f, 0.15f);
    float3 macroTint = mix(sandTint, rockTint, smoothstep(0.32f, 0.82f, in.materialBlend));
    float3 albedo = mix(macroTint, bakedAlbedo * 1.05f, 0.46f);

    float surfaceY = uniforms.water.deepColorAndSurfaceY.w;
    float subDepth = max(0.0f, surfaceY - in.worldPos.y);
    float wetBand = 1.0f - smoothstep(-0.1f, 0.65f, in.worldPos.y - surfaceY);
    albedo *= mix(1.0f, 0.66f, wetBand);

    float NdotL = max(dot(N, sunDir), 0.0f);
    float3 directLight = sunRadiance * NdotL * 0.36f * sunDay;
    float3 ambient = uniforms.atmosphere.ambientColorAndExposure.xyz * (0.45f + 0.55f * (N.y * 0.5f + 0.5f));

    float3 causticLight = float3(0.0f);
    if (in.worldPos.y < surfaceY) {
        float3 downTrans = exp(-uniforms.water.absorptionAndClarity.xyz * subDepth * 0.65f);
        directLight *= downTrans;
        causticLight = evaluateTerrainCaustics(in.worldPos, sunDir, uniforms.water) *
                       sunRadiance * max(N.y, 0.15f) * sunDay * 0.28f;
    }

    float3 color = albedo * (directLight + ambient * in.ao * (0.75f + 0.25f * bakedRough.b) + causticLight);

    float3 H = normalize(sunDir + V);
    float specPow = mix(12.0f, 48.0f, wetBand);
    float spec = pow(max(dot(N, H), 0.0f), specPow) * (0.04f + 0.14f * wetBand) * sunDay;
    color += sunRadiance * spec * 0.18f;

    float underwaterCam = uniforms.camera.upAndUnderwater.w;
    if (underwaterCam > 0.01f && in.worldPos.y < surfaceY + 0.5f) {
        float3 waterTrans = exp(-uniforms.water.absorptionAndClarity.xyz * dist * 0.62f);
        float3 waterFog = mix(
            uniforms.water.deepColorAndSurfaceY.xyz * 0.55f,
            uniforms.water.shallowColorAndFoam.xyz * 0.65f,
            exp(-subDepth * 0.15f)
        ) * (0.25f + 0.75f * sunDay);

        float3 underwaterColor = mix(waterFog, color, waterTrans);
        underwaterColor += evaluateVolumetricGodRays(camPos, in.worldPos, sunDir, uniforms);
        color = mix(color, underwaterColor, underwaterCam);
    } else {
        float fogFactor = 1.0f - exp(-dist * uniforms.atmosphere.skyHorizonColorAndFog.w);
        color = mix(color, uniforms.atmosphere.skyHorizonColorAndFog.xyz * (0.35f + 0.65f * sunDay), clamp(fogFactor, 0.0f, 0.92f));
    }

    return float4(color, 1.0f);
}

// MARK: - Instanced Swaying Underwater Aquatic Weeds

struct WeedVertexOut {
    float4 position [[position]];
    float3 worldPos;
    float3 worldNormal;
    float heightT;
    float tintFactor;
};

vertex WeedVertexOut weedVertexShader(
    uint vid [[vertex_id]],
    uint iid [[instance_id]],
    device const Vertex* vertices            [[buffer(BufferIndexVertices)]],
    constant Uniforms& uniforms              [[buffer(BufferIndexUniforms)]],
    device const WeedInstanceData* instances [[buffer(BufferIndexWeedInstances)]]
) {
    Vertex v = vertices[vid];
    WeedInstanceData inst = instances[iid];

    float scale = inst.positionAndScale.w;
    float yaw = inst.swayPhaseAndTint.y;
    float phase = inst.swayPhaseAndTint.x;
    float flex = inst.swayPhaseAndTint.w;
    float heightT = clamp(v.uvAndMaterial.y, 0.0f, 1.0f);

    float time = uniforms.water.gridParams.z;
    float sway = sin(time * 1.65f + phase + heightT * 2.1f) * 0.22f * heightT * heightT * flex;
    float crossSway = cos(time * 1.15f + phase * 1.3f) * 0.10f * heightT * heightT * flex;

    float cy = cos(yaw), sy = sin(yaw);
    float3 lp = v.position.xyz * scale;
    float3 rotP = float3(lp.x * cy - lp.z * sy, lp.y, lp.x * sy + lp.z * cy);
    rotP.x += sway;
    rotP.z += crossSway;

    float3 worldPos = inst.positionAndScale.xyz + rotP;
    // Hard clamp weed vertices below water surface so blades never poke into air
    worldPos.y = min(worldPos.y, uniforms.water.deepColorAndSurfaceY.w - 0.42f);

    float3 ln = v.normal.xyz;
    float3 worldN = normalize(float3(ln.x * cy - ln.z * sy, ln.y, ln.x * sy + ln.z * cy));

    WeedVertexOut out;
    out.position = uniforms.camera.viewProjectionMatrix * float4(worldPos, 1.0f);
    out.worldPos = worldPos;
    out.worldNormal = worldN;
    out.heightT = heightT;
    out.tintFactor = inst.swayPhaseAndTint.z;
    return out;
}

fragment float4 weedFragmentShader(
    WeedVertexOut in [[stage_in]],
    constant Uniforms& uniforms [[buffer(BufferIndexUniforms)]]
) {
    float3 camPos = uniforms.camera.positionAndFov.xyz;
    float dist = length(camPos - in.worldPos);
    float3 sunDir = normalize(uniforms.atmosphere.sunDirectionAndElevation.xyz);
    float3 sunRad = uniforms.atmosphere.sunColorAndIntensity.xyz * uniforms.atmosphere.sunColorAndIntensity.w;
    float sunDay = smoothstep(-0.10f, 0.22f, sunDir.y);

    float3 baseCol = mix(float3(0.05f, 0.14f, 0.06f), float3(0.14f, 0.30f, 0.11f), in.tintFactor);
    float3 tipCol = mix(float3(0.16f, 0.38f, 0.14f), float3(0.28f, 0.48f, 0.16f), in.tintFactor);
    float3 albedo = mix(baseCol, tipCol, in.heightT);

    float surfaceY = uniforms.water.deepColorAndSurfaceY.w;
    float subDepth = max(0.0f, surfaceY - in.worldPos.y);
    float3 lightTrans = exp(-uniforms.water.absorptionAndClarity.xyz * subDepth * 0.62f);

    float NdotL = abs(dot(normalize(in.worldNormal), sunDir));
    float3 color = albedo * (uniforms.atmosphere.ambientColorAndExposure.xyz * 0.75f + sunRad * (0.28f + 0.45f * NdotL) * lightTrans * sunDay * 0.32f);

    float underwaterCam = uniforms.camera.upAndUnderwater.w;
    if (underwaterCam > 0.01f) {
        float3 waterTrans = exp(-uniforms.water.absorptionAndClarity.xyz * dist * 0.62f);
        float3 waterFog = uniforms.water.deepColorAndSurfaceY.xyz * (0.30f + 0.70f * sunDay);
        color = mix(color, mix(waterFog, color, waterTrans), underwaterCam);
    }

    return float4(color, 1.0f);
}
