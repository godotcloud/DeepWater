import Foundation
import AVFoundation
import CoreHaptics
import os

private final class ProceduralAudioDSPState: @unchecked Sendable {
    struct Snapshot {
        var windIntensity: Float = 0.35
        var waveIntensity: Float = 0.45
        var dragClickRateHz: Float = 0.0
        var castWhooshTrigger: UInt32 = 0
        var castWhooshEnergy: Float = 0.0
        var splashTrigger: UInt32 = 0
        var splashEnergy: Float = 0.0
    }

    private let lock = OSAllocatedUnfairLock(initialState: Snapshot())

    func updateContinuous(wind: Float, waves: Float, dragClickRateHz: Float) {
        lock.withLock { state in
            state.windIntensity = max(0.0, min(1.0, wind))
            state.waveIntensity = max(0.0, min(1.0, waves))
            state.dragClickRateHz = max(0.0, min(80.0, dragClickRateHz))
        }
    }

    func triggerCastWhoosh(energy: Float) {
        lock.withLock { state in
            state.castWhooshTrigger &+= 1
            state.castWhooshEnergy = max(0.2, min(1.0, energy))
        }
    }

    func triggerSplash(energy: Float) {
        lock.withLock { state in
            state.splashTrigger &+= 1
            state.splashEnergy = max(0.15, min(1.0, energy))
        }
    }

    func readSnapshot() -> Snapshot {
        lock.withLock { $0 }
    }
}

@MainActor
public final class HapticAndAudioEngine {
    private var hapticEngine: CHHapticEngine?
    private var continuousTensionPlayer: CHHapticAdvancedPatternPlayer?
    private var isContinuousHapticPlaying: Bool = false
    private var supportsHaptics: Bool = false
    private var dragClickHapticAccum: Float = 0.0

    private let audioEngine = AVAudioEngine()
    private var sourceNode: AVAudioSourceNode?
    private let dspState = ProceduralAudioDSPState()
    private var isAudioRunning: Bool = false

    public init() {
        setupHaptics()
        setupProceduralAudio()
    }

    public func start() {
        startHapticsIfNeeded()
        startAudioIfNeeded()
    }

    public func stop() {
        if isContinuousHapticPlaying {
            try? continuousTensionPlayer?.stop(atTime: CHHapticTimeImmediate)
            isContinuousHapticPlaying = false
        }
        hapticEngine?.stop(completionHandler: nil)
        if isAudioRunning {
            audioEngine.pause()
            isAudioRunning = false
        }
    }

    public func playNibbleHaptic() {
        guard supportsHaptics, let engine = hapticEngine else { return }
        startHapticsIfNeeded()
        let events: [CHHapticEvent] = [
            CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.34),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.88)
                ],
                relativeTime: 0.0
            ),
            CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.28),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.92)
                ],
                relativeTime: 0.068
            )
        ]
        playOneShotPattern(engine: engine, events: events)
    }

    public func playStrikeHaptic(intensity: Float = 0.95) {
        guard supportsHaptics, let engine = hapticEngine else { return }
        startHapticsIfNeeded()
        let clamped = max(0.35, min(1.0, intensity))
        let events: [CHHapticEvent] = [
            CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: clamped),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.24)
                ],
                relativeTime: 0.0
            ),
            CHHapticEvent(
                eventType: .hapticContinuous,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: clamped * 0.72),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.65)
                ],
                relativeTime: 0.02,
                duration: 0.14
            )
        ]
        playOneShotPattern(engine: engine, events: events)
    }

    public func updateFightFeedback(
        deltaTime: Float,
        normalizedTension: Float,
        headShakeIntensity: Float,
        dragClickRateHz: Float,
        windLevel: Float = 0.35,
        waveLevel: Float = 0.45
    ) {
        dspState.updateContinuous(wind: windLevel, waves: waveLevel, dragClickRateHz: dragClickRateHz)

        guard supportsHaptics else { return }

        let activeTension = max(0.0, min(1.0, normalizedTension))
        if activeTension > 0.12 {
            startHapticsIfNeeded()
            if !isContinuousHapticPlaying {
                try? continuousTensionPlayer?.start(atTime: CHHapticTimeImmediate)
                isContinuousHapticPlaying = true
            }
            let modulatedIntensity = min(1.0, activeTension * 0.75 + headShakeIntensity * 0.35)
            let modulatedSharpness = min(1.0, 0.22 + activeTension * 0.45 + headShakeIntensity * 0.30)
            let intensityParam = CHHapticDynamicParameter(
                parameterID: .hapticIntensityControl,
                value: modulatedIntensity,
                relativeTime: 0
            )
            let sharpnessParam = CHHapticDynamicParameter(
                parameterID: .hapticSharpnessControl,
                value: modulatedSharpness,
                relativeTime: 0
            )
            try? continuousTensionPlayer?.sendParameters([intensityParam, sharpnessParam], atTime: CHHapticTimeImmediate)
        } else if isContinuousHapticPlaying {
            try? continuousTensionPlayer?.stop(atTime: CHHapticTimeImmediate)
            isContinuousHapticPlaying = false
        }

        if dragClickRateHz > 1.0 {
            dragClickHapticAccum += deltaTime * dragClickRateHz
            if dragClickHapticAccum >= 1.0 {
                dragClickHapticAccum = fmod(dragClickHapticAccum, 1.0)
                playDragClickHaptic(intensity: min(0.85, 0.35 + dragClickRateHz * 0.01))
            }
        } else {
            dragClickHapticAccum = 0.0
        }
    }

    public func playDragClickHaptic(intensity: Float = 0.55) {
        guard supportsHaptics, let engine = hapticEngine else { return }
        let event = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: max(0.2, min(1.0, intensity))),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.96)
            ],
            relativeTime: 0.0
        )
        playOneShotPattern(engine: engine, events: [event])
    }

    public func playCastWhooshSound(power: Float) {
        dspState.triggerCastWhoosh(energy: power)
    }

    public func playLureSplashSound(impactSpeed: Float) {
        let normEnergy = max(0.18, min(1.0, impactSpeed / 14.0))
        dspState.triggerSplash(energy: normEnergy)
    }

    private func setupHaptics() {
        supportsHaptics = CHHapticEngine.capabilitiesForHardware().supportsHaptics
        guard supportsHaptics else { return }

        do {
            let engine = try CHHapticEngine()
            engine.isAutoShutdownEnabled = true
            engine.resetHandler = { [weak self] in
                Task { @MainActor [weak self] in
                    self?.isContinuousHapticPlaying = false
                    try? self?.hapticEngine?.start()
                    self?.prepareContinuousTensionPlayer()
                }
            }
            self.hapticEngine = engine
            try engine.start()
            prepareContinuousTensionPlayer()
        } catch {
            supportsHaptics = false
        }
    }

    private func prepareContinuousTensionPlayer() {
        guard let engine = hapticEngine else { return }
        let event = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.4),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.35)
            ],
            relativeTime: 0.0,
            duration: 60.0
        )
        if let pattern = try? CHHapticPattern(events: [event], parameters: []) {
            continuousTensionPlayer = try? engine.makeAdvancedPlayer(with: pattern)
            continuousTensionPlayer?.loopEnabled = true
        }
    }

    private func startHapticsIfNeeded() {
        guard supportsHaptics else { return }
        try? hapticEngine?.start()
    }

    private func playOneShotPattern(engine: CHHapticEngine, events: [CHHapticEvent]) {
        guard let pattern = try? CHHapticPattern(events: events, parameters: []),
              let player = try? engine.makePlayer(with: pattern) else { return }
        try? player.start(atTime: CHHapticTimeImmediate)
    }

    private func setupProceduralAudio() {
        #if os(iOS)
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.ambient, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)
        #endif

        let sampleRate: Double = 48_000.0
        guard let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 2) else { return }

        var rngState: UInt32 = 0x1234_5678
        var pinkB0: Float = 0, pinkB1: Float = 0, pinkB2: Float = 0
        var windLP: Float = 0, windBP: Float = 0
        var waveLP: Float = 0
        var wavePhase: Float = 0
        var windLfoPhase: Float = 0

        var lastCastTrigger: UInt32 = 0
        var castEnv: Float = 0
        var castEnergy: Float = 0
        var castBP1: Float = 0, castBP2: Float = 0

        var lastSplashTrigger: UInt32 = 0
        var splashEnv: Float = 0
        var splashEnergy: Float = 0
        var splashChirpPhase: Float = 0
        var splashNoiseLP: Float = 0

        var dragPhase: Float = 0
        var ratchetEnv: Float = 0
        var ratchetOsc1: Float = 0
        var ratchetOsc2: Float = 0
        var ratchetOsc3: Float = 0

        let invSR = Float(1.0 / sampleRate)
        let stateBridge = dspState

        let node = AVAudioSourceNode(format: format) { _, _, frameCount, audioBufferList -> OSStatus in
            let snap = stateBridge.readSnapshot()

            if snap.castWhooshTrigger != lastCastTrigger {
                lastCastTrigger = snap.castWhooshTrigger
                castEnv = 1.0
                castEnergy = snap.castWhooshEnergy
            }
            if snap.splashTrigger != lastSplashTrigger {
                lastSplashTrigger = snap.splashTrigger
                splashEnv = 1.0
                splashEnergy = snap.splashEnergy
                splashChirpPhase = 0.0
            }

            let abl = UnsafeMutableAudioBufferListPointer(audioBufferList)
            guard let leftBuf = abl[0].mData?.assumingMemoryBound(to: Float.self) else {
                return noErr
            }
            let rightBuf: UnsafeMutablePointer<Float>? = (abl.count > 1)
                ? abl[1].mData?.assumingMemoryBound(to: Float.self)
                : nil

            for frame in 0..<Int(frameCount) {
                rngState ^= rngState << 13
                rngState ^= rngState >> 17
                rngState ^= rngState << 5
                let white = (Float(rngState & 0x00FF_FFFF) / Float(0x007F_FFFF)) - 1.0

                pinkB0 = 0.997 * pinkB0 + white * 0.029
                pinkB1 = 0.985 * pinkB1 + white * 0.032
                pinkB2 = 0.950 * pinkB2 + white * 0.048
                let pink = (pinkB0 + pinkB1 + pinkB2 + white * 0.04) * 0.65

                windLfoPhase += 0.11 * 6.2831853 * invSR
                if windLfoPhase > 6.2831853 { windLfoPhase -= 6.2831853 }
                let windCutoff = 0.015 + 0.012 * (0.5 + 0.5 * sin(windLfoPhase))
                windLP += windCutoff * (pink - windLP)
                windBP += 0.08 * ((pink - windLP) - windBP)
                let windSample = windBP * snap.windIntensity * 0.24

                wavePhase += 0.14 * 6.2831853 * invSR
                if wavePhase > 6.2831853 { wavePhase -= 6.2831853 }
                let swell = 0.35 + 0.65 * pow(0.5 + 0.5 * sin(wavePhase), 2.2)
                waveLP += (0.018 + 0.035 * swell) * (pink - waveLP)
                let foamHiss = white * pow(swell, 4.0) * 0.022
                let waveSample = (waveLP * swell * 0.38 + foamHiss) * snap.waveIntensity

                var castSample: Float = 0.0
                if castEnv > 0.001 {
                    let sweepFreq = 260.0 + sin(castEnv * 3.14159265) * 1150.0 * castEnergy
                    let f = min(0.35, 6.2831853 * sweepFreq * invSR)
                    castBP1 += f * (white - castBP2 - 0.35 * castBP1)
                    castBP2 += f * castBP1
                    castSample = castBP1 * castEnv * castEnergy * 0.42
                    castEnv *= 0.99982
                }

                var splashSample: Float = 0.0
                if splashEnv > 0.001 {
                    let bubbleFreq = 135.0 + (1.0 - splashEnv) * 340.0
                    splashChirpPhase += bubbleFreq * 6.2831853 * invSR
                    let plopTone = sin(splashChirpPhase) * pow(splashEnv, 2.2) * 0.36
                    splashNoiseLP += 0.14 * (white - splashNoiseLP)
                    let burst = splashNoiseLP * splashEnv * 0.32
                    splashSample = (plopTone + burst) * splashEnergy
                    splashEnv *= 0.99976
                }

                var dragSample: Float = 0.0
                if snap.dragClickRateHz > 0.5 {
                    dragPhase += snap.dragClickRateHz * invSR
                    if dragPhase >= 1.0 {
                        dragPhase -= 1.0
                        ratchetEnv = 1.0
                    }
                }
                if ratchetEnv > 0.001 {
                    ratchetOsc1 += 2650.0 * 6.2831853 * invSR
                    ratchetOsc2 += 4210.0 * 6.2831853 * invSR
                    ratchetOsc3 += 6890.0 * 6.2831853 * invSR
                    if ratchetOsc1 > 6.2831853 { ratchetOsc1 -= 6.2831853 }
                    if ratchetOsc2 > 6.2831853 { ratchetOsc2 -= 6.2831853 }
                    if ratchetOsc3 > 6.2831853 { ratchetOsc3 -= 6.2831853 }
                    let metallic = (sin(ratchetOsc1) * 0.5 + sin(ratchetOsc2) * 0.32 + sin(ratchetOsc3) * 0.18)
                    dragSample = metallic * ratchetEnv * 0.28
                    ratchetEnv *= 0.9962
                }

                let mixL = tanh(windSample + waveSample + castSample + splashSample + dragSample)
                let mixR = tanh(windSample * 0.94 + waveSample * 1.04 + castSample + splashSample + dragSample)

                leftBuf[frame] = mixL
                rightBuf?[frame] = mixR
            }

            return noErr
        }

        self.sourceNode = node
        audioEngine.attach(node)
        audioEngine.connect(node, to: audioEngine.mainMixerNode, format: format)
        audioEngine.mainMixerNode.outputVolume = 0.85
    }

    private func startAudioIfNeeded() {
        guard !isAudioRunning else { return }
        do {
            try audioEngine.start()
            isAudioRunning = true
        } catch {
            isAudioRunning = false
        }
    }
}
