import Foundation
import Metal
import MetalKit
import QuartzCore
import simd

@MainActor
public final class SimulationState: ObservableObject {
    @Published public var fps: Int = 60
    @Published public var waterDepthMeters: Float = 0.0
    @Published public var cameraElevationMeters: Float = 2.35
    @Published public var timeOfDayHours: Float = 9.5
    @Published public var cameraMode: CameraMode = .firstPersonAboveWater
    @Published public var isUnderwater: Bool = false

    public var timeOfDayLabel: String {
        let h = Int(timeOfDayHours) % 24
        let m = Int((timeOfDayHours - floor(timeOfDayHours)) * 60.0)
        let phase: String
        switch timeOfDayHours {
        case 5.0..<8.5:
            phase = "晨"
        case 8.5..<16.5:
            phase = "午"
        case 16.5..<19.8:
            phase = "暮"
        default:
            phase = "夜"
        }
        return String(format: "%02d:%02d %@", h, m, phase)
    }

    public init() {}
}

@MainActor
public final class MetalRenderer: NSObject, MTKViewDelegate {
    public let device: MTLDevice
    public let cameraController = CameraController()
    public let state: SimulationState

    private let commandQueue: MTLCommandQueue
    private let inFlightSemaphore = DispatchSemaphore(value: 3)
    private let maxBuffersInFlight = 3
    private var uniformBuffers: [MTLBuffer] = []
    private var uniformBufferIndex: Int = 0

    private var skyPipelineState: MTLRenderPipelineState?
    private var terrainPipelineState: MTLRenderPipelineState?
    private var waterPipelineState: MTLRenderPipelineState?
    private var postProcessPipelineState: MTLRenderPipelineState?

    private var skyDepthState: MTLDepthStencilState?
    private var opaqueDepthState: MTLDepthStencilState?
    private var waterDepthState: MTLDepthStencilState?

    private let msaaSampleCount: Int = 4
    private var hdrMSAATexture: MTLTexture?
    private var hdrResolveTexture: MTLTexture?
    private var msaaDepthTexture: MTLTexture?
    private var currentRenderSize: CGSize = .zero

    private var terrainMesh: TerrainMesh?
    private var waterVertexBuffer: MTLBuffer?
    private var waterIndexBuffer: MTLBuffer?
    private var waterIndexCount: Int = 0
    private let waterHalfExtent: Float = 110.0
    private let waterSurfaceY: Float = 0.0

    private var lastFrameTimestamp: CFTimeInterval = CACurrentMediaTime()
    private var elapsedTime: Float = 0.0
    private var frameCounter: UInt32 = 0
    private var hudUpdateAccumulator: Float = 0.0
    private var smoothedDeltaTime: Float = 1.0 / 60.0

    public init?(mtkView: MTKView, state: SimulationState) {
        guard let device = mtkView.device ?? MTLCreateSystemDefaultDevice(),
              let queue = device.makeCommandQueue() else {
            return nil
        }

        self.device = device
        self.commandQueue = queue
        self.state = state

        super.init()

        mtkView.device = device
        mtkView.preferredFramesPerSecond = 60
        mtkView.colorPixelFormat = .bgra8Unorm_srgb
        mtkView.depthStencilPixelFormat = .invalid
        mtkView.framebufferOnly = true
        mtkView.isPaused = false
        mtkView.enableSetNeedsDisplay = false

        buildUniformBuffers()
        buildDepthStencilStates()
        buildPipelines(viewColorPixelFormat: mtkView.colorPixelFormat)
        buildSceneGeometry()
    }

    private func buildUniformBuffers() {
        let length = MemoryLayout<Uniforms>.stride
        uniformBuffers = (0..<maxBuffersInFlight).compactMap { idx in
            let buffer = device.makeBuffer(length: length, options: .storageModeShared)
            buffer?.label = "UniformsBuffer_\(idx)"
            return buffer
        }
    }

    private func buildDepthStencilStates() {
        let skyDesc = MTLDepthStencilDescriptor()
        skyDesc.depthCompareFunction = .always
        skyDesc.isDepthWriteEnabled = false
        skyDepthState = device.makeDepthStencilState(descriptor: skyDesc)

        let opaqueDesc = MTLDepthStencilDescriptor()
        opaqueDesc.depthCompareFunction = .less
        opaqueDesc.isDepthWriteEnabled = true
        opaqueDepthState = device.makeDepthStencilState(descriptor: opaqueDesc)

        let waterDesc = MTLDepthStencilDescriptor()
        waterDesc.depthCompareFunction = .lessEqual
        waterDesc.isDepthWriteEnabled = true
        waterDepthState = device.makeDepthStencilState(descriptor: waterDesc)
    }

    private func buildPipelines(viewColorPixelFormat: MTLPixelFormat) {
        guard let library = device.makeDefaultLibrary() else {
            assertionFailure("Failed to load default Metal library.")
            return
        }

        let hdrFormat: MTLPixelFormat = .rgba16Float
        let depthFormat: MTLPixelFormat = .depth32Float

        if let vFunc = library.makeFunction(name: "skyVertexShader"),
           let fFunc = library.makeFunction(name: "skyFragmentShader") {
            let desc = MTLRenderPipelineDescriptor()
            desc.label = "SkyPipeline"
            desc.vertexFunction = vFunc
            desc.fragmentFunction = fFunc
            desc.rasterSampleCount = msaaSampleCount
            desc.colorAttachments[0].pixelFormat = hdrFormat
            desc.depthAttachmentPixelFormat = depthFormat
            skyPipelineState = try? device.makeRenderPipelineState(descriptor: desc)
        }

        if let vFunc = library.makeFunction(name: "terrainVertexShader"),
           let fFunc = library.makeFunction(name: "terrainFragmentShader") {
            let desc = MTLRenderPipelineDescriptor()
            desc.label = "TerrainPipeline"
            desc.vertexFunction = vFunc
            desc.fragmentFunction = fFunc
            desc.rasterSampleCount = msaaSampleCount
            desc.colorAttachments[0].pixelFormat = hdrFormat
            desc.depthAttachmentPixelFormat = depthFormat
            terrainPipelineState = try? device.makeRenderPipelineState(descriptor: desc)
        }

        if let vFunc = library.makeFunction(name: "waterVertexShader"),
           let fFunc = library.makeFunction(name: "waterFragmentShader") {
            let desc = MTLRenderPipelineDescriptor()
            desc.label = "WaterPipeline"
            desc.vertexFunction = vFunc
            desc.fragmentFunction = fFunc
            desc.rasterSampleCount = msaaSampleCount
            desc.colorAttachments[0].pixelFormat = hdrFormat
            desc.colorAttachments[0].isBlendingEnabled = true
            desc.colorAttachments[0].rgbBlendOperation = .add
            desc.colorAttachments[0].alphaBlendOperation = .add
            desc.colorAttachments[0].sourceRGBBlendFactor = .sourceAlpha
            desc.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha
            desc.colorAttachments[0].sourceAlphaBlendFactor = .one
            desc.colorAttachments[0].destinationAlphaBlendFactor = .oneMinusSourceAlpha
            desc.depthAttachmentPixelFormat = depthFormat
            waterPipelineState = try? device.makeRenderPipelineState(descriptor: desc)
        }

        if let vFunc = library.makeFunction(name: "postProcessVertexShader"),
           let fFunc = library.makeFunction(name: "postProcessFragmentShader") {
            let desc = MTLRenderPipelineDescriptor()
            desc.label = "PostProcessACESPipeline"
            desc.vertexFunction = vFunc
            desc.fragmentFunction = fFunc
            desc.rasterSampleCount = 1
            desc.colorAttachments[0].pixelFormat = viewColorPixelFormat
            postProcessPipelineState = try? device.makeRenderPipelineState(descriptor: desc)
        }
    }

    private func buildSceneGeometry() {
        terrainMesh = TerrainBuilder.build(device: device, gridResolution: 160, halfExtent: 64.0)
        buildWaterGrid(resolution: 180, halfExtent: waterHalfExtent)
    }

    private func buildWaterGrid(resolution: Int, halfExtent: Float) {
        let count = resolution * resolution
        var vertices = [Vertex]()
        vertices.reserveCapacity(count)

        let step = (halfExtent * 2.0) / Float(resolution - 1)
        for z in 0..<resolution {
            let vz = -halfExtent + Float(z) * step
            let vCoord = Float(z) / Float(resolution - 1)
            for x in 0..<resolution {
                let vx = -halfExtent + Float(x) * step
                let uCoord = Float(x) / Float(resolution - 1)
                let vertex = Vertex(
                    position: SIMD4<Float>(vx, waterSurfaceY, vz, 1.0),
                    normal: SIMD4<Float>(0.0, 1.0, 0.0, 1.0),
                    uvAndMaterial: SIMD4<Float>(uCoord, vCoord, 0.0, 0.04)
                )
                vertices.append(vertex)
            }
        }

        var indices = [UInt32]()
        indices.reserveCapacity((resolution - 1) * (resolution - 1) * 6)
        for z in 0..<(resolution - 1) {
            for x in 0..<(resolution - 1) {
                let topLeft = UInt32(z * resolution + x)
                let topRight = topLeft + 1
                let bottomLeft = UInt32((z + 1) * resolution + x)
                let bottomRight = bottomLeft + 1

                indices.append(topLeft)
                indices.append(bottomLeft)
                indices.append(topRight)

                indices.append(topRight)
                indices.append(bottomLeft)
                indices.append(bottomRight)
            }
        }

        waterVertexBuffer = device.makeBuffer(
            bytes: vertices,
            length: MemoryLayout<Vertex>.stride * vertices.count,
            options: .storageModeShared
        )
        waterVertexBuffer?.label = "WaterVertexBuffer"

        waterIndexBuffer = device.makeBuffer(
            bytes: indices,
            length: MemoryLayout<UInt32>.stride * indices.count,
            options: .storageModeShared
        )
        waterIndexBuffer?.label = "WaterIndexBuffer"
        waterIndexCount = indices.count
    }

    private func ensureOffscreenTargets(size: CGSize) {
        let width = max(1, Int(size.width))
        let height = max(1, Int(size.height))
        guard currentRenderSize.width != CGFloat(width) || currentRenderSize.height != CGFloat(height) else {
            return
        }
        currentRenderSize = CGSize(width: width, height: height)

        #if targetEnvironment(simulator)
        let transientStorageMode: MTLStorageMode = .private
        #else
        let transientStorageMode: MTLStorageMode = .memoryless
        #endif

        let msaaColorDesc = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: .rgba16Float,
            width: width,
            height: height,
            mipmapped: false
        )
        msaaColorDesc.textureType = .type2DMultisample
        msaaColorDesc.sampleCount = msaaSampleCount
        msaaColorDesc.storageMode = transientStorageMode
        msaaColorDesc.usage = .renderTarget
        hdrMSAATexture = device.makeTexture(descriptor: msaaColorDesc)
        hdrMSAATexture?.label = "HDR_MSAA_Color"

        let resolveColorDesc = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: .rgba16Float,
            width: width,
            height: height,
            mipmapped: false
        )
        resolveColorDesc.storageMode = .private
        resolveColorDesc.usage = [.renderTarget, .shaderRead]
        hdrResolveTexture = device.makeTexture(descriptor: resolveColorDesc)
        hdrResolveTexture?.label = "HDR_Resolve_Color"

        let msaaDepthDesc = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: .depth32Float,
            width: width,
            height: height,
            mipmapped: false
        )
        msaaDepthDesc.textureType = .type2DMultisample
        msaaDepthDesc.sampleCount = msaaSampleCount
        msaaDepthDesc.storageMode = transientStorageMode
        msaaDepthDesc.usage = .renderTarget
        msaaDepthTexture = device.makeTexture(descriptor: msaaDepthDesc)
        msaaDepthTexture?.label = "HDR_MSAA_Depth"
    }

    public func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        ensureOffscreenTargets(size: size)
    }

    public func draw(in view: MTKView) {
        let now = CACurrentMediaTime()
        let rawDelta = Float(now - lastFrameTimestamp)
        lastFrameTimestamp = now
        let deltaTime = min(max(rawDelta, 1.0 / 240.0), 0.05)
        elapsedTime += deltaTime
        frameCounter &+= 1
        smoothedDeltaTime = smoothedDeltaTime * 0.90 + deltaTime * 0.10

        if cameraController.mode != state.cameraMode {
            cameraController.setMode(state.cameraMode)
        }

        let drawableSize = view.drawableSize
        guard drawableSize.width >= 1, drawableSize.height >= 1 else { return }
        ensureOffscreenTargets(size: drawableSize)

        let meshRef = terrainMesh
        cameraController.update(deltaTime: deltaTime, waterSurfaceY: waterSurfaceY) { x, z in
            meshRef?.sampleHeight(x: x, z: z) ?? -6.0
        }

        hudUpdateAccumulator += deltaTime
        if hudUpdateAccumulator >= 0.15 {
            hudUpdateAccumulator = 0.0
            let camPos = cameraController.currentPosition
            let bedY = meshRef?.sampleHeight(x: camPos.x, z: camPos.z) ?? -6.0
            let waterColumnDepth = max(0.0, waterSurfaceY - bedY)
            state.fps = max(1, min(120, Int((1.0 / max(smoothedDeltaTime, 0.001)).rounded())))
            state.waterDepthMeters = waterColumnDepth
            state.cameraElevationMeters = camPos.y - waterSurfaceY
            state.isUnderwater = cameraController.underwaterBlend > 0.5
        }

        inFlightSemaphore.wait()

        guard let commandBuffer = commandQueue.makeCommandBuffer(),
              let viewPassDescriptor = view.currentRenderPassDescriptor,
              let drawable = view.currentDrawable,
              let hdrMSAATex = hdrMSAATexture,
              let hdrResolveTex = hdrResolveTexture,
              let msaaDepthTex = msaaDepthTexture,
              !uniformBuffers.isEmpty else {
            inFlightSemaphore.signal()
            return
        }

        commandBuffer.label = "DeepWaterFrame"
        let semaphore = inFlightSemaphore
        commandBuffer.addCompletedHandler { _ in
            semaphore.signal()
        }

        uniformBufferIndex = (uniformBufferIndex + 1) % uniformBuffers.count
        let uniformBuffer = uniformBuffers[uniformBufferIndex]
        let aspect = Float(drawableSize.width / drawableSize.height)
        var uniforms = buildUniforms(aspect: aspect, size: drawableSize, deltaTime: deltaTime)
        memcpy(uniformBuffer.contents(), &uniforms, MemoryLayout<Uniforms>.stride)

        let hdrPass = MTLRenderPassDescriptor()
        hdrPass.colorAttachments[0].texture = hdrMSAATex
        hdrPass.colorAttachments[0].resolveTexture = hdrResolveTex
        hdrPass.colorAttachments[0].loadAction = .clear
        hdrPass.colorAttachments[0].storeAction = .multisampleResolve
        hdrPass.colorAttachments[0].clearColor = MTLClearColor(red: 0.01, green: 0.04, blue: 0.07, alpha: 1.0)

        hdrPass.depthAttachment.texture = msaaDepthTex
        hdrPass.depthAttachment.loadAction = .clear
        hdrPass.depthAttachment.storeAction = .dontCare
        hdrPass.depthAttachment.clearDepth = 1.0

        if let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: hdrPass) {
            encoder.label = "HDRSceneEncoder"

            if let skyPSO = skyPipelineState, let skyDS = skyDepthState {
                encoder.setRenderPipelineState(skyPSO)
                encoder.setDepthStencilState(skyDS)
                encoder.setCullMode(.none)
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            }

            if let terrainPSO = terrainPipelineState,
               let opaqueDS = opaqueDepthState,
               let terrain = terrainMesh {
                encoder.setRenderPipelineState(terrainPSO)
                encoder.setDepthStencilState(opaqueDS)
                encoder.setCullMode(.back)
                encoder.setFrontFacing(.counterClockwise)
                encoder.setVertexBuffer(terrain.vertexBuffer, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.drawIndexedPrimitives(
                    type: .triangle,
                    indexCount: terrain.indexCount,
                    indexType: .uint32,
                    indexBuffer: terrain.indexBuffer,
                    indexBufferOffset: 0
                )
            }

            if let waterPSO = waterPipelineState,
               let waterDS = waterDepthState,
               let waterVB = waterVertexBuffer,
               let waterIB = waterIndexBuffer,
               let terrain = terrainMesh {
                encoder.setRenderPipelineState(waterPSO)
                encoder.setDepthStencilState(waterDS)
                encoder.setCullMode(.none)
                encoder.setVertexBuffer(waterVB, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentTexture(terrain.heightTexture, index: Int(TextureIndex.terrainHeight.rawValue))
                encoder.drawIndexedPrimitives(
                    type: .triangle,
                    indexCount: waterIndexCount,
                    indexType: .uint32,
                    indexBuffer: waterIB,
                    indexBufferOffset: 0
                )
            }

            encoder.endEncoding()
        }

        if let postEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: viewPassDescriptor),
           let postPSO = postProcessPipelineState {
            postEncoder.label = "PostProcessACESEncoder"
            postEncoder.setRenderPipelineState(postPSO)
            postEncoder.setCullMode(.none)
            postEncoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
            postEncoder.setFragmentTexture(hdrResolveTex, index: Int(TextureIndex.hdrColor.rawValue))
            postEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            postEncoder.endEncoding()
        }

        commandBuffer.present(drawable)
        commandBuffer.commit()
    }

    private func buildUniforms(aspect: Float, size: CGSize, deltaTime: Float) -> Uniforms {
        let cameraParams = cameraController.buildCameraParams(aspect: aspect)
        let atmosphereParams = buildAtmosphereParams(timeOfDay: state.timeOfDayHours)
        let waterParams = buildWaterParams(deltaTime: deltaTime)

        return Uniforms(
            camera: cameraParams,
            atmosphere: atmosphereParams,
            water: waterParams,
            viewportAndTime: SIMD4<Float>(Float(size.width), Float(size.height), elapsedTime, Float(frameCounter))
        )
    }

    private func buildAtmosphereParams(timeOfDay: Float) -> AtmosphereParams {
        let normalizedHour = ((timeOfDay - 6.0) / 24.0) * (2.0 * Float.pi)
        let elevation = sin(normalizedHour) * 1.12
        let azimuth = cos(normalizedHour) * 1.15 - 0.35

        let sunDir = simd_normalize(SIMD3<Float>(
            sin(azimuth) * cos(elevation),
            sin(elevation),
            -cos(azimuth) * cos(elevation)
        ))

        let dayFactor = max(0.0, min(1.0, (sin(elevation) + 0.08) / 0.45))
        let sunsetFactor = max(0.0, 1.0 - abs(sin(elevation) - 0.12) * 3.2)

        let noonSun = SIMD3<Float>(1.0, 0.96, 0.90)
        let sunsetSun = SIMD3<Float>(1.0, 0.48, 0.22)
        let moonSun = SIMD3<Float>(0.24, 0.34, 0.56)

        var sunColor = simd_mix(moonSun, noonSun, SIMD3<Float>(repeating: dayFactor))
        sunColor = simd_mix(sunColor, sunsetSun, SIMD3<Float>(repeating: sunsetFactor * 0.78))

        let sunIntensity: Float = 0.45 + dayFactor * 6.8 + sunsetFactor * 1.6

        let zenithDay = SIMD3<Float>(0.11, 0.32, 0.72)
        let zenithNight = SIMD3<Float>(0.012, 0.022, 0.052)
        let zenithColor = simd_mix(zenithNight, zenithDay, SIMD3<Float>(repeating: dayFactor))

        let horizonDay = SIMD3<Float>(0.55, 0.73, 0.88)
        let horizonSunset = SIMD3<Float>(0.96, 0.46, 0.24)
        let horizonNight = SIMD3<Float>(0.03, 0.05, 0.10)
        var horizonColor = simd_mix(horizonNight, horizonDay, SIMD3<Float>(repeating: dayFactor))
        horizonColor = simd_mix(horizonColor, horizonSunset, SIMD3<Float>(repeating: sunsetFactor * 0.85))

        let ambientColor = simd_mix(
            SIMD3<Float>(0.03, 0.05, 0.09),
            SIMD3<Float>(0.24, 0.32, 0.42),
            SIMD3<Float>(repeating: dayFactor)
        )
        let exposure: Float = 0.88 + (1.0 - dayFactor) * 0.42

        return AtmosphereParams(
            sunDirectionAndElevation: SIMD4<Float>(sunDir.x, sunDir.y, sunDir.z, elevation),
            sunColorAndIntensity: SIMD4<Float>(sunColor.x, sunColor.y, sunColor.z, sunIntensity),
            skyZenithColorAndTime: SIMD4<Float>(zenithColor.x, zenithColor.y, zenithColor.z, timeOfDay),
            skyHorizonColorAndFog: SIMD4<Float>(horizonColor.x, horizonColor.y, horizonColor.z, 0.0042),
            rayleighCoeffAndScale: SIMD4<Float>(0.0058, 0.0135, 0.0331, 1.0),
            mieCoeffAndG: SIMD4<Float>(0.0042, 0.0045, 0.0050, 0.78),
            ambientColorAndExposure: SIMD4<Float>(ambientColor.x, ambientColor.y, ambientColor.z, exposure)
        )
    }

    private func buildWaterParams(deltaTime: Float) -> WaterParams {
        let w0 = makeWave(angleDeg: 18.0, steepness: 0.14, wavelength: 26.0)
        let w1 = makeWave(angleDeg: 42.0, steepness: 0.12, wavelength: 17.5)
        let w2 = makeWave(angleDeg: -25.0, steepness: 0.11, wavelength: 12.2)
        let w3 = makeWave(angleDeg: 75.0, steepness: 0.09, wavelength: 8.6)
        let w4 = makeWave(angleDeg: -58.0, steepness: 0.08, wavelength: 6.1)
        let w5 = makeWave(angleDeg: 112.0, steepness: 0.06, wavelength: 4.3)
        let w6 = makeWave(angleDeg: -10.0, steepness: 0.05, wavelength: 2.9)
        let w7 = makeWave(angleDeg: 52.0, steepness: 0.04, wavelength: 1.85)

        let terrainHalf = terrainMesh?.halfExtent ?? 64.0

        return WaterParams(
            gerstnerWaves: (w0, w1, w2, w3, w4, w5, w6, w7),
            absorptionAndClarity: SIMD4<Float>(0.36, 0.12, 0.065, 0.85),
            deepColorAndSurfaceY: SIMD4<Float>(0.012, 0.065, 0.115, waterSurfaceY),
            shallowColorAndFoam: SIMD4<Float>(0.055, 0.24, 0.26, 0.42),
            causticParams: SIMD4<Float>(1.45, 0.36, 0.72, 1.0 / 1.333),
            godRayParams: SIMD4<Float>(0.55, 0.11, 1.0, 0.42),
            gridParams: SIMD4<Float>(waterHalfExtent, terrainHalf, elapsedTime, deltaTime)
        )
    }

    private func makeWave(angleDeg: Float, steepness: Float, wavelength: Float) -> SIMD4<Float> {
        let rad = angleDeg * .pi / 180.0
        return SIMD4<Float>(cos(rad), sin(rad), steepness, wavelength)
    }
}
