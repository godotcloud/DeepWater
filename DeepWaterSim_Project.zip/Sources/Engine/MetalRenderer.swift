import Foundation
import Metal
import MetalKit
import QuartzCore
import simd

@MainActor
public final class SimulationState: ObservableObject {
    @Published public var fps: Int = 60
    @Published public var waterDepthMeters: Float = 0.0
    @Published public var cameraElevationMeters: Float = 2.35
    @Published public var timeOfDayHours: Float = 9.5
    @Published public var cameraMode: CameraMode = .firstPersonAboveWater
    @Published public var isUnderwater: Bool = false

    @Published public var hookedFishSpecies: FishSpecies? = nil
    @Published public var hookedFishState: FishAIState? = nil
    @Published public var hookedFishStamina: Float = 1.0
    @Published public var latestLandedRecord: CatchRecord? = nil
    @Published public var shouldOpenCatchLog: Bool = false

    public var timeOfDayLabel: String {
        let h = Int(timeOfDayHours) % 24
        let m = Int((timeOfDayHours - floor(timeOfDayHours)) * 60.0)
        let phase: String
        switch timeOfDayHours {
        case 5.0..<8.5: phase = "晨"
        case 8.5..<16.5: phase = "午"
        case 16.5..<19.8: phase = "暮"
        default: phase = "夜"
        }
        return String(format: "%02d:%02d %@", h, m, phase)
    }

    public init() {}
}

private struct ActiveSplashParticle {
    var position: SIMD3<Float>
    var velocity: SIMD3<Float>
    var age: Float
    var lifetime: Float
    var baseSize: Float
}

@MainActor
public final class MetalRenderer: NSObject, MTKViewDelegate {
    public let device: MTLDevice
    public let cameraController = CameraController()
    public let state: SimulationState
    public let inputController: CastAndInputController
    public let ecosystem: EcosystemEngine
    public let governor: PerformanceGovernor
    public let catchStore: CatchLogStore
    public let physicsRig = RodAndLinePhysics()
    public let audioHaptics = HapticAndAudioEngine()

    private let commandQueue: MTLCommandQueue
    private let inFlightSemaphore = DispatchSemaphore(value: 3)
    private let maxBuffersInFlight = 3
    private var uniformBuffers: [MTLBuffer] = []
    private var uniformBufferIndex: Int = 0

    // Render pipeline states
    private var skyPipelineState: MTLRenderPipelineState?
    private var terrainPipelineState: MTLRenderPipelineState?
    private var weedPipelineState: MTLRenderPipelineState?
    private var waterPipelineState: MTLRenderPipelineState?
    private var fishPipelineState: MTLRenderPipelineState?
    private var tacklePipelineState: MTLRenderPipelineState?
    private var linePipelineState: MTLRenderPipelineState?
    private var splashPipelineState: MTLRenderPipelineState?
    private var postProcessPipelineState: MTLRenderPipelineState?

    // Depth stencil states
    private var skyDepthState: MTLDepthStencilState?
    private var opaqueDepthState: MTLDepthStencilState?
    private var waterDepthState: MTLDepthStencilState?
    private var particleDepthState: MTLDepthStencilState?

    // HDR offscreen render targets (2x memoryless MSAA + scaled Retina)
    private let msaaSampleCount: Int = 2
    private var hdrMSAATexture: MTLTexture?
    private var hdrResolveTexture: MTLTexture?
    private var msaaDepthTexture: MTLTexture?
    private var currentRenderSize: CGSize = .zero

    // Procedural PBR textures & scene meshes
    private var textureAtlas: ProceduralTextureAtlas?
    private var terrainMesh: TerrainMesh?
    private var waterVertexBuffer: MTLBuffer?
    private var waterIndexBuffer: MTLBuffer?
    private var waterIndexCount: Int = 0
    private let waterHalfExtent: Float = 105.0
    private let waterSurfaceY: Float = 0.0

    // Instanced Underwater Aquatic Weeds
    private var weedVertexBuffer: MTLBuffer?
    private var weedIndexBuffer: MTLBuffer?
    private var weedIndexCount: Int = 0
    private var weedInstanceBuffer: MTLBuffer?
    private let baseWeedInstanceCount: Int = 450

    // Fish meshes + 3-Level Distance LOD bundles + GPU Boids
    private var fishMeshes: [FishSpecies: FishMesh] = [:]
    private var fishLODs: [FishSpecies: MeshLODBundle] = [:]
    private var schoolingManager: SchoolingManager?

    // Fishing Tackle (Rod, Reel, Lures, 32-node XPBD Line)
    private var rodMesh: ProceduralMesh?
    private var rodBaseVertices: [Vertex] = []
    private var deformedRodVertexBuffer: MTLBuffer?
    private var reelAssembly: SpinningReelAssembly?
    private var lureMeshes: [LureType: ProceduralMesh] = [:]
    private var lineStripVertexBuffer: MTLBuffer?
    private let lineStripVertexCount: Int = RodAndLinePhysics.lineNodeCount * 2

    // 3D Splash & Breaching Spray Particle System
    private let maxSplashParticles: Int = 192
    private var activeSplashParticles: [ActiveSplashParticle] = []
    private var splashParticleBuffer: MTLBuffer?
    private var splashCooldownByFish: [Int: Float] = [:]

    // Frame timing & throttled HUD sync (10 Hz)
    private var lastFrameTimestamp: CFTimeInterval = CACurrentMediaTime()
    private var elapsedTime: Float = 0.0
    private var frameCounter: UInt32 = 0
    private var hudUpdateAccumulator: Float = 0.0
    private var smoothedDeltaTime: Float = 1.0 / 60.0
    private var fightClock: Float = 0.0
    private var latestEvents = PhysicsStepEvents()

    public init?(
        mtkView: MTKView,
        state: SimulationState,
        inputController: CastAndInputController,
        ecosystem: EcosystemEngine,
        governor: PerformanceGovernor,
        catchStore: CatchLogStore
    ) {
        guard let device = mtkView.device ?? MTLCreateSystemDefaultDevice(),
              let queue = device.makeCommandQueue() else {
            return nil
        }

        self.device = device
        self.commandQueue = queue
        self.state = state
        self.inputController = inputController
        self.ecosystem = ecosystem
        self.governor = governor
        self.catchStore = catchStore

        super.init()

        mtkView.device = device
        mtkView.preferredFramesPerSecond = 60
        mtkView.colorPixelFormat = .bgra8Unorm_srgb
        mtkView.depthStencilPixelFormat = .invalid
        mtkView.framebufferOnly = true
        mtkView.isPaused = false
        mtkView.enableSetNeedsDisplay = false

        buildUniformBuffers()
        buildDepthStencilStates()
        buildPipelines(viewColorPixelFormat: mtkView.colorPixelFormat)
        buildSceneGeometry()
        configureInputCallbacks()

        Task { [weak self] in
            guard let self else { return }
            if let atlas = try? await ProceduralTextureBaker.bakeAllAsync(device: self.device, commandQueue: self.commandQueue) {
                self.textureAtlas = atlas
            }
        }
    }

    public func startServices() {
        audioHaptics.start()
        inputController.startMotionUpdates()
    }

    public func stopServices() {
        inputController.stopMotionUpdates()
        audioHaptics.stop()
    }

    public func setFreeRoamMove(_ move: SIMD3<Float>) {
        cameraController.freeRoamMoveInput = move
    }

    private func configureInputCallbacks() {
        inputController.onCastTriggered = { [weak self] signal in
            guard let self else { return }
            self.physicsRig.launchCast(
                powerNormalized: signal.powerNormalized,
                aimYawOffset: signal.aimYawOffset,
                elevationRad: signal.elevationRad
            )
            self.audioHaptics.playCastWhooshSound(power: signal.powerNormalized)
            // Keep player's current camera mode; never auto-switch camera on cast
        }

        inputController.onTwitchTriggered = { [weak self] strength in
            self?.physicsRig.triggerRodTwitch(strength: strength)
        }
    }

    // MARK: - Public User Actions

    public func triggerTwitch() {
        physicsRig.triggerRodTwitch(strength: 1.0)
        audioHaptics.playNibbleHaptic()
    }

    public func resetBrokenLine() {
        physicsRig.resetRigToReadyPosition()
        schoolingManager?.aiManager.releaseHookedFish()
        state.hookedFishSpecies = nil
        state.hookedFishState = nil
        state.hookedFishStamina = 1.0
        inputController.isLineBroken = false
        inputController.simulatedFishFightActive = false
    }

    public func toggleTestFight() {
        inputController.simulatedFishFightActive.toggle()
        if inputController.simulatedFishFightActive {
            state.hookedFishSpecies = .largemouthBass
            state.hookedFishState = .fight
            state.hookedFishStamina = 0.65
            audioHaptics.playStrikeHaptic(intensity: 0.95)
        } else {
            state.hookedFishSpecies = nil
            state.hookedFishState = nil
        }
    }

    public func landHookedFish() {
        let species = state.hookedFishSpecies ?? .largemouthBass
        let genome = FishGenome.genome(for: species)
        let lengthCm = genome.bodyLength * 100.0 * Float.random(in: 0.90...1.28)
        let weightKg = max(0.35, pow(lengthCm / 36.0, 3.0) * 1.05)

        let record = catchStore.addCatch(
            species: species,
            lengthCm: lengthCm,
            weightKg: weightKg,
            captureDepthMeters: max(0.5, physicsRig.lureState.depthBelowSurface),
            lureType: inputController.activeLure,
            waterTempC: ecosystem.waterTemperature(depthMeters: physicsRig.lureState.depthBelowSurface),
            barometricPressureHPa: ecosystem.barometricPressureHPa,
            barometricTrend: ecosystem.barometricTrend,
            timeOfDayHours: state.timeOfDayHours
        )

        schoolingManager?.aiManager.releaseHookedFish()
        state.hookedFishSpecies = nil
        state.hookedFishState = nil
        state.hookedFishStamina = 1.0
        inputController.simulatedFishFightActive = false
        physicsRig.resetRigToReadyPosition()

        state.latestLandedRecord = record
        state.shouldOpenCatchLog = true
    }

    // MARK: - Resource & Pipeline Construction

    private func buildUniformBuffers() {
        let length = MemoryLayout<Uniforms>.stride
        uniformBuffers = (0..<maxBuffersInFlight).compactMap { idx in
            let buffer = device.makeBuffer(length: length, options: .storageModeShared)
            buffer?.label = "UniformsBuffer_\(idx)"
            return buffer
        }
    }

    private func buildDepthStencilStates() {
        let skyDesc = MTLDepthStencilDescriptor()
        skyDesc.depthCompareFunction = .always
        skyDesc.isDepthWriteEnabled = false
        skyDepthState = device.makeDepthStencilState(descriptor: skyDesc)

        let opaqueDesc = MTLDepthStencilDescriptor()
        opaqueDesc.depthCompareFunction = .less
        opaqueDesc.isDepthWriteEnabled = true
        opaqueDepthState = device.makeDepthStencilState(descriptor: opaqueDesc)

        let waterDesc = MTLDepthStencilDescriptor()
        waterDesc.depthCompareFunction = .lessEqual
        waterDesc.isDepthWriteEnabled = true
        waterDepthState = device.makeDepthStencilState(descriptor: waterDesc)

        let partDesc = MTLDepthStencilDescriptor()
        partDesc.depthCompareFunction = .lessEqual
        partDesc.isDepthWriteEnabled = false
        particleDepthState = device.makeDepthStencilState(descriptor: partDesc)
    }

    private func buildPipelines(viewColorPixelFormat: MTLPixelFormat) {
        guard let library = device.makeDefaultLibrary() else { return }

        let hdrFormat: MTLPixelFormat = .rgba16Float
        let depthFormat: MTLPixelFormat = .depth32Float

        func makeHDRPipeline(label: String, vert: String, frag: String, alphaBlend: Bool) -> MTLRenderPipelineState? {
            guard let v = library.makeFunction(name: vert),
                  let f = library.makeFunction(name: frag) else { return nil }
            let desc = MTLRenderPipelineDescriptor()
            desc.label = label
            desc.vertexFunction = v
            desc.fragmentFunction = f
            desc.rasterSampleCount = msaaSampleCount
            desc.colorAttachments[0].pixelFormat = hdrFormat
            if alphaBlend {
                desc.colorAttachments[0].isBlendingEnabled = true
                desc.colorAttachments[0].rgbBlendOperation = .add
                desc.colorAttachments[0].alphaBlendOperation = .add
                desc.colorAttachments[0].sourceRGBBlendFactor = .sourceAlpha
                desc.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha
                desc.colorAttachments[0].sourceAlphaBlendFactor = .one
                desc.colorAttachments[0].destinationAlphaBlendFactor = .oneMinusSourceAlpha
            }
            desc.depthAttachmentPixelFormat = depthFormat
            return try? device.makeRenderPipelineState(descriptor: desc)
        }

        skyPipelineState = makeHDRPipeline(label: "SkyPipeline", vert: "skyVertexShader", frag: "skyFragmentShader", alphaBlend: false)
        terrainPipelineState = makeHDRPipeline(label: "TerrainPipeline", vert: "terrainVertexShader", frag: "terrainFragmentShader", alphaBlend: false)
        weedPipelineState = makeHDRPipeline(label: "WeedPipeline", vert: "weedVertexShader", frag: "weedFragmentShader", alphaBlend: false)
        waterPipelineState = makeHDRPipeline(label: "WaterPipeline", vert: "waterVertexShader", frag: "waterFragmentShader", alphaBlend: true)
        fishPipelineState = makeHDRPipeline(label: "FishPBRPipeline", vert: "fishAnimatedVertexShader", frag: "fishFragmentShader", alphaBlend: true)
        tacklePipelineState = makeHDRPipeline(label: "TacklePipeline", vert: "tackleVertexShader", frag: "tackleFragmentShader", alphaBlend: false)
        linePipelineState = makeHDRPipeline(label: "LinePipeline", vert: "lineVertexShader", frag: "lineFragmentShader", alphaBlend: true)
        splashPipelineState = makeHDRPipeline(label: "SplashParticlePipeline", vert: "splashVertexShader", frag: "splashFragmentShader", alphaBlend: true)

        if let vFunc = library.makeFunction(name: "postProcessVertexShader"),
           let fFunc = library.makeFunction(name: "postProcessFragmentShader") {
            let desc = MTLRenderPipelineDescriptor()
            desc.label = "PostProcessACESPipeline"
            desc.vertexFunction = vFunc
            desc.fragmentFunction = fFunc
            desc.rasterSampleCount = 1
            desc.colorAttachments[0].pixelFormat = viewColorPixelFormat
            postProcessPipelineState = try? device.makeRenderPipelineState(descriptor: desc)
        }
    }

    private func buildSceneGeometry() {
        terrainMesh = TerrainBuilder.build(device: device, gridResolution: 120, halfExtent: 64.0)
        buildWaterGrid(resolution: 110, halfExtent: waterHalfExtent)
        buildUnderwaterWeeds()

        // Generate all 5 procedural fish species meshes + 3-level Distance LOD index bundles
        for sp in FishSpecies.allCases {
            if let mesh = FishMeshGenerator.generate(device: device, species: sp) {
                fishMeshes[sp] = mesh
                let idxPtr = mesh.indexBuffer.contents().bindMemory(to: UInt32.self, capacity: mesh.indexCount)
                let baseIndices = Array(UnsafeBufferPointer(start: idxPtr, count: mesh.indexCount))
                if let lod = PerformanceGovernor.buildLODBundle(device: device, baseIndices: baseIndices, label: "Fish_\(sp.rawValue)") {
                    fishLODs[sp] = lod
                }
            }
        }

        let meshRef = terrainMesh
        schoolingManager = SchoolingManager(
            device: device,
            baitfishCount: 320,
            targetFishCount: 40,
            ecosystem: ecosystem
        ) { x, z in
            meshRef?.sampleHeight(x: x, z: z) ?? -6.0
        }

        if let rod = TackleMeshGenerator.buildFishingRod(device: device, length: physicsRig.rodLength) {
            rodMesh = rod
            let ptr = rod.vertexBuffer.contents().bindMemory(to: Vertex.self, capacity: rod.vertexCount)
            rodBaseVertices = Array(UnsafeBufferPointer(start: ptr, count: rod.vertexCount))
            deformedRodVertexBuffer = device.makeBuffer(
                length: MemoryLayout<Vertex>.stride * rod.vertexCount,
                options: .storageModeShared
            )
            deformedRodVertexBuffer?.label = "DeformedRodVB"
        }

        reelAssembly = TackleMeshGenerator.buildSpinningReel(device: device)

        for lureType in LureType.allCases {
            if let mesh = TackleMeshGenerator.buildLure(device: device, type: lureType) {
                lureMeshes[lureType] = mesh
            }
        }

        lineStripVertexBuffer = device.makeBuffer(
            length: MemoryLayout<Vertex>.stride * lineStripVertexCount,
            options: .storageModeShared
        )
        lineStripVertexBuffer?.label = "XPBDLineRibbonVB"

        splashParticleBuffer = device.makeBuffer(
            length: MemoryLayout<SplashParticleData>.stride * maxSplashParticles,
            options: .storageModeShared
        )
        splashParticleBuffer?.label = "SplashParticlesBuffer"
    }

    private func buildUnderwaterWeeds() {
        // Multi-blade curved aquatic kelp/weed tuft geometry
        var verts: [Vertex] = []
        var idx: [UInt32] = []
        let bladeCount = 5
        let segs = 5

        for b in 0..<bladeCount {
            let baseAngle = Float(b) * (2.0 * Float.pi / Float(bladeCount))
            let leanRadius: Float = 0.08 + Float(b % 2) * 0.05
            let bladeH: Float = 0.85 + Float(b % 3) * 0.25
            let baseV = UInt32(verts.count)

            let dirX = cos(baseAngle), dirZ = sin(baseAngle)
            let sideX = -dirZ, sideZ = dirX

            for s in 0...segs {
                let t = Float(s) / Float(segs)
                let width = (1.0 - t * 0.88) * 0.065
                let y = t * bladeH
                let bend = t * t * leanRadius
                let cx = dirX * bend
                let cz = dirZ * bend
                let n = simd_normalize(SIMD3<Float>(dirX, 0.35, dirZ))

                verts.append(Vertex(
                    position: SIMD4<Float>(cx - sideX * width, y, cz - sideZ * width, 1.0),
                    normal: SIMD4<Float>(n.x, n.y, n.z, 1.0),
                    uvAndMaterial: SIMD4<Float>(0.0, t, 0.0, 0.7)
                ))
                verts.append(Vertex(
                    position: SIMD4<Float>(cx + sideX * width, y, cz + sideZ * width, 1.0),
                    normal: SIMD4<Float>(n.x, n.y, n.z, 1.0),
                    uvAndMaterial: SIMD4<Float>(1.0, t, 0.0, 0.7)
                ))
            }

            for s in 0..<segs {
                let r0 = baseV + UInt32(s * 2)
                let r1 = r0 + 1
                let r2 = r0 + 2
                let r3 = r0 + 3
                idx.append(r0); idx.append(r2); idx.append(r1)
                idx.append(r1); idx.append(r2); idx.append(r3)
            }
        }

        weedVertexBuffer = device.makeBuffer(bytes: verts, length: MemoryLayout<Vertex>.stride * verts.count, options: .storageModeShared)
        weedIndexBuffer = device.makeBuffer(bytes: idx, length: MemoryLayout<UInt32>.stride * idx.count, options: .storageModeShared)
        weedIndexCount = idx.count

        // Place 450 instanced weed clusters across shallow shoal & rocky reef pockets
        var instances: [WeedInstanceData] = []
        instances.reserveCapacity(baseWeedInstanceCount)
        var seed: UInt64 = 0x7EED_5011_9921
        func rand01() -> Float {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Float((seed >> 33) & 0x7FFF_FFFF) / Float(0x7FFF_FFFF)
        }

        var attempts = 0
        while instances.count < baseWeedInstanceCount && attempts < baseWeedInstanceCount * 5 {
            attempts += 1
            let x = (rand01() - 0.5) * 76.0
            let z = -34.0 + rand01() * 54.0
            let bedY = terrainMesh?.sampleHeight(x: x, z: z) ?? -4.0
            let depth = waterSurfaceY - bedY
            if depth > 0.75 && depth < 8.5 {
                let scale = 0.65 + rand01() * 1.15
                instances.append(WeedInstanceData(
                    positionAndScale: SIMD4<Float>(x, bedY - 0.05, z, scale),
                    swayPhaseAndTint: SIMD4<Float>(rand01() * 6.2831853, rand01() * 6.2831853, rand01(), 0.7 + rand01() * 0.6)
                ))
            }
        }

        if !instances.isEmpty {
            weedInstanceBuffer = device.makeBuffer(
                bytes: instances,
                length: MemoryLayout<WeedInstanceData>.stride * instances.count,
                options: .storageModeShared
            )
            weedInstanceBuffer?.label = "WeedInstancesBuffer"
        }
    }

    private func buildWaterGrid(resolution: Int, halfExtent: Float) {
        let count = resolution * resolution
        var vertices = [Vertex]()
        vertices.reserveCapacity(count)

        let step = (halfExtent * 2.0) / Float(resolution - 1)
        for z in 0..<resolution {
            let vz = -halfExtent + Float(z) * step
            let vCoord = Float(z) / Float(resolution - 1)
            for x in 0..<resolution {
                let vx = -halfExtent + Float(x) * step
                let uCoord = Float(x) / Float(resolution - 1)
                vertices.append(Vertex(
                    position: SIMD4<Float>(vx, waterSurfaceY, vz, 1.0),
                    normal: SIMD4<Float>(0.0, 1.0, 0.0, 1.0),
                    uvAndMaterial: SIMD4<Float>(uCoord, vCoord, 0.0, 0.04)
                ))
            }
        }

        var indices = [UInt32]()
        indices.reserveCapacity((resolution - 1) * (resolution - 1) * 6)
        for z in 0..<(resolution - 1) {
            for x in 0..<(resolution - 1) {
                let tl = UInt32(z * resolution + x)
                let tr = tl + 1
                let bl = UInt32((z + 1) * resolution + x)
                let br = bl + 1
                indices.append(tl); indices.append(bl); indices.append(tr)
                indices.append(tr); indices.append(bl); indices.append(br)
            }
        }

        waterVertexBuffer = device.makeBuffer(bytes: vertices, length: MemoryLayout<Vertex>.stride * vertices.count, options: .storageModeShared)
        waterIndexBuffer = device.makeBuffer(bytes: indices, length: MemoryLayout<UInt32>.stride * indices.count, options: .storageModeShared)
        waterIndexCount = indices.count
    }

    private func ensureOffscreenTargets(nativeSize: CGSize) {
        let scale = CGFloat(min(0.80, governor.effectiveRenderScale))
        let width = max(320, Int((nativeSize.width * scale).rounded()))
        let height = max(240, Int((nativeSize.height * scale).rounded()))
        guard currentRenderSize.width != CGFloat(width) || currentRenderSize.height != CGFloat(height) else {
            return
        }
        currentRenderSize = CGSize(width: width, height: height)

        #if targetEnvironment(simulator)
        let transientStorageMode: MTLStorageMode = .private
        #else
        let transientStorageMode: MTLStorageMode = .memoryless
        #endif

        let msaaColorDesc = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: width, height: height, mipmapped: false)
        msaaColorDesc.textureType = .type2DMultisample
        msaaColorDesc.sampleCount = msaaSampleCount
        msaaColorDesc.storageMode = transientStorageMode
        msaaColorDesc.usage = .renderTarget
        hdrMSAATexture = device.makeTexture(descriptor: msaaColorDesc)

        let resolveColorDesc = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .rgba16Float, width: width, height: height, mipmapped: false)
        resolveColorDesc.storageMode = .private
        resolveColorDesc.usage = [.renderTarget, .shaderRead]
        hdrResolveTexture = device.makeTexture(descriptor: resolveColorDesc)

        let msaaDepthDesc = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: .depth32Float, width: width, height: height, mipmapped: false)
        msaaDepthDesc.textureType = .type2DMultisample
        msaaDepthDesc.sampleCount = msaaSampleCount
        msaaDepthDesc.storageMode = transientStorageMode
        msaaDepthDesc.usage = .renderTarget
        msaaDepthTexture = device.makeTexture(descriptor: msaaDepthDesc)
    }

    public func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        ensureOffscreenTargets(nativeSize: size)
    }

    // MARK: - Main 60 FPS Render & Physics Loop

    public func draw(in view: MTKView) {
        if inFlightSemaphore.wait(timeout: .now() + .milliseconds(3)) == .timedOut {
            return
        }

        let now = CACurrentMediaTime()
        let rawDelta = Float(now - lastFrameTimestamp)
        lastFrameTimestamp = now
        let deltaTime = min(max(rawDelta, 1.0 / 240.0), 0.05)
        elapsedTime += deltaTime
        frameCounter &+= 1
        smoothedDeltaTime = smoothedDeltaTime * 0.90 + deltaTime * 0.10

        if cameraController.mode != state.cameraMode {
            cameraController.setMode(state.cameraMode)
        }

        let drawableSize = view.drawableSize
        guard drawableSize.width >= 1, drawableSize.height >= 1 else {
            inFlightSemaphore.signal()
            return
        }
        ensureOffscreenTargets(nativeSize: drawableSize)

        let meshRef = terrainMesh
        let heightLookup: (Float, Float) -> Float = { x, z in
            meshRef?.sampleHeight(x: x, z: z) ?? -6.0
        }

        cameraController.updateLureTracking(position: physicsRig.lureState.position, velocity: physicsRig.lureState.velocity)
        cameraController.update(deltaTime: deltaTime, waterSurfaceY: waterSurfaceY, terrainHeightAt: heightLookup)
        updateRodAnchorFromCamera()

        inputController.updateTouchCharge(deltaTime: deltaTime)
        physicsRig.dragSettingNormalized = inputController.dragSetting
        physicsRig.rodPower = inputController.rodPower
        physicsRig.activeLureType = inputController.activeLure

        guard let commandBuffer = commandQueue.makeCommandBuffer(),
              let viewPassDescriptor = view.currentRenderPassDescriptor,
              let drawable = view.currentDrawable,
              let hdrMSAATex = hdrMSAATexture,
              let hdrResolveTex = hdrResolveTexture,
              let msaaDepthTex = msaaDepthTexture,
              !uniformBuffers.isEmpty else {
            inFlightSemaphore.signal()
            return
        }

        commandBuffer.label = "DeepWaterFrame"
        let semaphore = inFlightSemaphore
        commandBuffer.addCompletedHandler { _ in
            semaphore.signal()
        }

        // Poll GPU-emitted breaching fish splash triggers from previous frame
        consumeFishSplashSignals(deltaTime: deltaTime)

        var externalFishPull = SIMD3<Float>.zero
        var headShake: Float = 0.0

        if let school = schoolingManager, let terrain = terrainMesh {
            let lureColor: SIMD3<Float>
            switch inputController.activeLure {
            case .minnowHardbait: lureColor = SIMD3<Float>(0.78, 0.84, 0.88)
            case .jigheadSoftWorm: lureColor = SIMD3<Float>(0.42, 0.65, 0.24)
            case .metalSpoon: lureColor = SIMD3<Float>(0.92, 0.94, 0.96)
            }
            let perception = LurePerceptionInput(
                position: physicsRig.lureState.position,
                velocity: physicsRig.lureState.velocity,
                lureType: inputController.activeLure,
                wobbleAmplitude: abs(physicsRig.lureState.wobbleAngleRad),
                lureColorRGB: lureColor,
                justSplashed: latestEvents.lureJustSplashed,
                splashEnergy: min(1.0, latestEvents.splashImpactSpeed / 12.0),
                isSubmerged: physicsRig.lureState.isSubmerged,
                rodLineTensionN: latestEvents.lineTensionNewtons
            )
            let aiTick = school.encodeSimulationPass(
                commandBuffer: commandBuffer,
                deltaTime: deltaTime,
                timeOfDayHours: state.timeOfDayHours,
                lure: perception,
                anglerPosition: physicsRig.rodButtWorldPosition,
                terrainHeightTexture: terrain.heightTexture,
                terrainHalfExtent: terrain.halfExtent,
                terrainHeightAt: heightLookup
            )

            if aiTick.nibbleTriggered { audioHaptics.playNibbleHaptic() }
            if aiTick.strikeTriggered { audioHaptics.playStrikeHaptic(intensity: 0.95) }
            if let sp = aiTick.hookedFishSpecies {
                state.hookedFishSpecies = sp
                state.hookedFishState = aiTick.hookedFishState
                state.hookedFishStamina = aiTick.hookedFishStamina
                headShake = aiTick.hookedHeadShake
                externalFishPull = aiTick.externalPullForce
            }
        }

        if inputController.simulatedFishFightActive && !physicsRig.isLineBroken {
            fightClock += deltaTime
            let surge = 0.55 + 0.45 * sin(fightClock * 2.1)
            headShake = max(headShake, max(0.0, sin(fightClock * 13.5)) * 0.65)
            externalFishPull += SIMD3<Float>(
                sin(fightClock * 1.7) * 16.0,
                -6.0 - surge * 8.0,
                -(14.0 + surge * 22.0)
            )
            let nextStamina = max(0.05, state.hookedFishStamina - deltaTime * 0.06)
            if nextStamina <= 0.12 && state.hookedFishState != .exhausted {
                state.hookedFishState = .exhausted
            }
            state.hookedFishStamina = nextStamina
        }

        let events = physicsRig.step(
            deltaTime: deltaTime,
            reelSpeedMetersPerSec: inputController.currentRetrieveSpeedMetersPerSec,
            externalFishPullForce: externalFishPull,
            terrainHeightAt: heightLookup
        )
        latestEvents = events

        if events.lureJustSplashed {
            audioHaptics.playLureSplashSound(impactSpeed: events.splashImpactSpeed)
            spawnSplashBurst(
                origin: SIMD3<Float>(physicsRig.lureState.position.x, waterSurfaceY + 0.05, physicsRig.lureState.position.z),
                intensity: min(1.0, events.splashImpactSpeed / 10.0),
                count: 26
            )
        }
        if events.lineJustBroke {
            schoolingManager?.aiManager.releaseHookedFish()
            state.hookedFishSpecies = nil
            state.hookedFishState = nil
            inputController.isLineBroken = true
            inputController.simulatedFishFightActive = false
        }

        audioHaptics.updateFightFeedback(
            deltaTime: deltaTime,
            normalizedTension: events.normalizedTension,
            headShakeIntensity: headShake,
            dragClickRateHz: events.dragClickRateHz
        )

        updateDeformedRodBuffer()
        updateFishingLineRibbonBuffer(cameraPos: cameraController.currentPosition)
        stepSplashParticles(deltaTime: deltaTime)

        hudUpdateAccumulator += deltaTime
        if hudUpdateAccumulator >= 0.10 {
            hudUpdateAccumulator = 0.0
            let camPos = cameraController.currentPosition
            let bedY = heightLookup(camPos.x, camPos.z)
            state.fps = max(1, min(120, Int((1.0 / max(smoothedDeltaTime, 0.001)).rounded())))
            state.waterDepthMeters = max(0.0, waterSurfaceY - bedY)
            state.cameraElevationMeters = camPos.y - waterSurfaceY
            state.isUnderwater = cameraController.underwaterBlend > 0.5

            inputController.currentLineTensionN = events.lineTensionNewtons
            inputController.normalizedTension = events.normalizedTension
            inputController.lineOutMeters = physicsRig.lineOutLength
            inputController.lureDepthMeters = physicsRig.lureState.depthBelowSurface
            inputController.isLineBroken = physicsRig.isLineBroken
        }

        uniformBufferIndex = (uniformBufferIndex + 1) % uniformBuffers.count
        let uniformBuffer = uniformBuffers[uniformBufferIndex]
        let aspect = Float(drawableSize.width / drawableSize.height)
        var uniforms = buildUniforms(aspect: aspect, size: currentRenderSize, deltaTime: deltaTime)
        memcpy(uniformBuffer.contents(), &uniforms, MemoryLayout<Uniforms>.stride)

        let hdrPass = MTLRenderPassDescriptor()
        hdrPass.colorAttachments[0].texture = hdrMSAATex
        hdrPass.colorAttachments[0].resolveTexture = hdrResolveTex
        hdrPass.colorAttachments[0].loadAction = .clear
        hdrPass.colorAttachments[0].storeAction = .multisampleResolve
        hdrPass.colorAttachments[0].clearColor = MTLClearColor(red: 0.01, green: 0.04, blue: 0.07, alpha: 1.0)

        hdrPass.depthAttachment.texture = msaaDepthTex
        hdrPass.depthAttachment.loadAction = .clear
        hdrPass.depthAttachment.storeAction = .dontCare
        hdrPass.depthAttachment.clearDepth = 1.0

        if let encoder = commandBuffer.makeRenderCommandEncoder(descriptor: hdrPass) {
            encoder.label = "HDRSceneEncoder"

            // 1. Sky Dome
            if let skyPSO = skyPipelineState, let skyDS = skyDepthState {
                encoder.setRenderPipelineState(skyPSO)
                encoder.setDepthStencilState(skyDS)
                encoder.setCullMode(.none)
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            }

            // 2. Underwater Terrain with GPU-Baked 1024x1024 Seabed PBR Maps
            if let terrainPSO = terrainPipelineState,
               let opaqueDS = opaqueDepthState,
               let terrain = terrainMesh,
               let atlas = textureAtlas {
                encoder.setRenderPipelineState(terrainPSO)
                encoder.setDepthStencilState(opaqueDS)
                encoder.setCullMode(.back)
                encoder.setFrontFacing(.counterClockwise)
                encoder.setVertexBuffer(terrain.vertexBuffer, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentTexture(atlas.seabed.albedo, index: Int(TextureIndex.albedo.rawValue))
                encoder.setFragmentTexture(atlas.seabed.normal, index: Int(TextureIndex.normal.rawValue))
                encoder.setFragmentTexture(atlas.seabed.roughnessMeta, index: Int(TextureIndex.roughnessMeta.rawValue))
                encoder.drawIndexedPrimitives(
                    type: .triangle,
                    indexCount: terrain.indexCount,
                    indexType: .uint32,
                    indexBuffer: terrain.indexBuffer,
                    indexBufferOffset: 0
                )
            }

            // 3. Instanced Swaying Underwater Aquatic Weeds (Thermally Scaled via PerformanceGovernor)
            let activeWeeds = governor.activeWeedInstanceCount(baseCount: baseWeedInstanceCount)
            if activeWeeds > 0,
               let weedPSO = weedPipelineState,
               let opaqueDS = opaqueDepthState,
               let weedVB = weedVertexBuffer,
               let weedIB = weedIndexBuffer,
               let weedInst = weedInstanceBuffer {
                encoder.setRenderPipelineState(weedPSO)
                encoder.setDepthStencilState(opaqueDS)
                encoder.setCullMode(.none)
                encoder.setVertexBuffer(weedVB, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setVertexBuffer(weedInst, offset: 0, index: Int(BufferIndex.weedInstances.rawValue))
                encoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.drawIndexedPrimitives(
                    type: .triangle,
                    indexCount: weedIndexCount,
                    indexType: .uint32,
                    indexBuffer: weedIB,
                    indexBufferOffset: 0,
                    instanceCount: activeWeeds
                )
            }

            // 4. 320 GPU Boids Baitfish + 5 Distinct Target Fish Species with 3-Level Distance LOD
            if let fishPSO = fishPipelineState,
               let opaqueDS = opaqueDepthState,
               let atlas = textureAtlas,
               let iridTex = atlas.fishBase.iridescence,
               let school = schoolingManager,
               let splashBuf = school.splashEventBuffer {
                encoder.setRenderPipelineState(fishPSO)
                encoder.setDepthStencilState(opaqueDS)
                encoder.setCullMode(.none)
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentTexture(atlas.fishBase.albedo, index: Int(TextureIndex.albedo.rawValue))
                encoder.setFragmentTexture(atlas.fishBase.normal, index: Int(TextureIndex.normal.rawValue))
                encoder.setFragmentTexture(atlas.fishBase.roughnessMeta, index: Int(TextureIndex.roughnessMeta.rawValue))
                encoder.setFragmentTexture(iridTex, index: Int(TextureIndex.iridescence.rawValue))

                // 4a. 320 Baitfish using distance-evaluated LOD
                if let baitMesh = fishMeshes[.topmouthCulter],
                   let baitInstBuf = school.baitfishInstanceBuffer {
                    let baitDist = simd_distance(cameraController.currentPosition, ecosystem.activeBaitfishAttractor)
                    let baitLOD = governor.evaluateFishLOD(entityID: 9999, distanceMeters: baitDist)
                    let (ib, ic) = fishLODs[.topmouthCulter]?.indexBuffer(for: baitLOD) ?? (baitMesh.indexBuffer, baitMesh.indexCount)

                    encoder.setVertexBuffer(baitMesh.vertexBuffer, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                    encoder.setVertexBuffer(baitInstBuf, offset: 0, index: Int(BufferIndex.fishInstances.rawValue))
                    encoder.setVertexBuffer(splashBuf, offset: 0, index: Int(BufferIndex.splashEvents.rawValue))
                    encoder.drawIndexedPrimitives(
                        type: .triangle,
                        indexCount: ic,
                        indexType: .uint32,
                        indexBuffer: ib,
                        indexBufferOffset: 0,
                        instanceCount: school.baitfishCount
                    )
                }

                // 4b. 40 Target Fish batched cleanly across all 5 distinct anatomical FishSpecies meshes + 3-Level LOD
                if let targetInstBuf = school.targetFishInstanceBuffer {
                    let allSpecies = FishSpecies.allCases
                    let perSpecies = max(1, school.targetFishCount / allSpecies.count)
                    let instStride = MemoryLayout<FishInstanceData>.stride
                    let splashStride = MemoryLayout<SplashTriggerEvent>.stride

                    for (spIdx, sp) in allSpecies.enumerated() {
                        let startIdx = spIdx * perSpecies
                        let count = (spIdx == allSpecies.count - 1) ? max(0, school.targetFishCount - startIdx) : perSpecies
                        guard count > 0, let mesh = fishMeshes[sp] else { continue }

                        // Compute nearest fish distance in this species batch for 3-level LOD selection
                        var minDist: Float = 60.0
                        for k in startIdx..<min(startIdx + count, school.aiManager.targetFish.count) {
                            let d = simd_distance(cameraController.currentPosition, school.aiManager.targetFish[k].position)
                            minDist = min(minDist, d)
                        }
                        let lodLevel = governor.evaluateFishLOD(entityID: sp.rawValue, distanceMeters: minDist)
                        let (ib, ic) = fishLODs[sp]?.indexBuffer(for: lodLevel) ?? (mesh.indexBuffer, mesh.indexCount)

                        encoder.setVertexBuffer(mesh.vertexBuffer, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                        encoder.setVertexBuffer(targetInstBuf, offset: startIdx * instStride, index: Int(BufferIndex.fishInstances.rawValue))
                        encoder.setVertexBuffer(splashBuf, offset: startIdx * splashStride, index: Int(BufferIndex.splashEvents.rawValue))
                        encoder.drawIndexedPrimitives(
                            type: .triangle,
                            indexCount: ic,
                            indexType: .uint32,
                            indexBuffer: ib,
                            indexBufferOffset: 0,
                            instanceCount: count
                        )
                    }
                }
            }

            // 5. Fishing Tackle with GPU-Baked Carbon Fiber, Brushed Aluminum & Natural Cork Textures
            if let tacklePSO = tacklePipelineState,
               let opaqueDS = opaqueDepthState,
               let atlas = textureAtlas {
                encoder.setRenderPipelineState(tacklePSO)
                encoder.setDepthStencilState(opaqueDS)
                encoder.setCullMode(.none)
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentTexture(atlas.carbonFiber.albedo, index: Int(TextureIndex.carbonAlbedo.rawValue))
                encoder.setFragmentTexture(atlas.brushedAluminum.albedo, index: Int(TextureIndex.aluminumAlbedo.rawValue))
                encoder.setFragmentTexture(atlas.naturalCork.albedo, index: Int(TextureIndex.corkAlbedo.rawValue))

                if let rod = rodMesh, let defVB = deformedRodVertexBuffer {
                    var rodUniforms = TackleUniforms(
                        modelMatrix: matrix_identity_float4x4,
                        tintAndParams: SIMD4<Float>(0.2, 0.2, 0.22, events.normalizedTension)
                    )
                    encoder.setVertexBuffer(defVB, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                    encoder.setVertexBytes(&rodUniforms, length: MemoryLayout<TackleUniforms>.stride, index: Int(BufferIndex.tackleUniforms.rawValue))
                    encoder.drawIndexedPrimitives(type: .triangle, indexCount: rod.indexCount, indexType: .uint32, indexBuffer: rod.indexBuffer, indexBufferOffset: 0)
                }

                if let reel = reelAssembly {
                    let reelMat = buildReelWorldMatrix()
                    var reelUniforms = TackleUniforms(modelMatrix: reelMat, tintAndParams: SIMD4<Float>(0.75, 0.78, 0.82, 0.0))
                    encoder.setVertexBuffer(reel.bodyAndSpoolMesh.vertexBuffer, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                    encoder.setVertexBytes(&reelUniforms, length: MemoryLayout<TackleUniforms>.stride, index: Int(BufferIndex.tackleUniforms.rawValue))
                    encoder.drawIndexedPrimitives(type: .triangle, indexCount: reel.bodyAndSpoolMesh.indexCount, indexType: .uint32, indexBuffer: reel.bodyAndSpoolMesh.indexBuffer, indexBufferOffset: 0)

                    let bailAngle: Float = physicsRig.isBailOpen ? 1.45 : 0.0
                    let bailMat = reelMat * translationMatrix(reel.bailPivotLocal) * rotationXMatrix(bailAngle)
                    var bailUniforms = TackleUniforms(modelMatrix: bailMat, tintAndParams: SIMD4<Float>(0.9, 0.92, 0.95, 0.0))
                    encoder.setVertexBuffer(reel.bailWireMesh.vertexBuffer, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                    encoder.setVertexBytes(&bailUniforms, length: MemoryLayout<TackleUniforms>.stride, index: Int(BufferIndex.tackleUniforms.rawValue))
                    encoder.drawIndexedPrimitives(type: .triangle, indexCount: reel.bailWireMesh.indexCount, indexType: .uint32, indexBuffer: reel.bailWireMesh.indexBuffer, indexBufferOffset: 0)
                }

                if let lureMesh = lureMeshes[inputController.activeLure] {
                    let lureMat = buildLureWorldMatrix()
                    let tint: SIMD4<Float>
                    switch inputController.activeLure {
                    case .minnowHardbait: tint = SIMD4<Float>(0.15, 0.85, 0.78, 0.0)
                    case .jigheadSoftWorm: tint = SIMD4<Float>(0.42, 0.82, 0.22, 0.0)
                    case .metalSpoon: tint = SIMD4<Float>(0.95, 0.92, 0.72, 0.0)
                    }
                    var lureUniforms = TackleUniforms(modelMatrix: lureMat, tintAndParams: tint)
                    encoder.setVertexBuffer(lureMesh.vertexBuffer, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                    encoder.setVertexBytes(&lureUniforms, length: MemoryLayout<TackleUniforms>.stride, index: Int(BufferIndex.tackleUniforms.rawValue))
                    encoder.drawIndexedPrimitives(type: .triangle, indexCount: lureMesh.indexCount, indexType: .uint32, indexBuffer: lureMesh.indexBuffer, indexBufferOffset: 0)
                }
            }

            // 6. 32-Node XPBD Fishing Line Ribbon
            if let linePSO = linePipelineState,
               let waterDS = waterDepthState,
               let lineVB = lineStripVertexBuffer,
               !physicsRig.isLineBroken {
                var lineUniforms = TackleUniforms(
                    modelMatrix: matrix_identity_float4x4,
                    tintAndParams: SIMD4<Float>(0.7, 0.95, 1.0, events.normalizedTension)
                )
                encoder.setRenderPipelineState(linePSO)
                encoder.setDepthStencilState(waterDS)
                encoder.setCullMode(.none)
                encoder.setVertexBuffer(lineVB, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setVertexBytes(&lineUniforms, length: MemoryLayout<TackleUniforms>.stride, index: Int(BufferIndex.tackleUniforms.rawValue))
                encoder.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: lineStripVertexCount)
            }

            // 7. Gerstner Water Surface
            if let waterPSO = waterPipelineState,
               let waterDS = waterDepthState,
               let waterVB = waterVertexBuffer,
               let waterIB = waterIndexBuffer,
               let terrain = terrainMesh {
                encoder.setRenderPipelineState(waterPSO)
                encoder.setDepthStencilState(waterDS)
                encoder.setCullMode(.none)
                encoder.setVertexBuffer(waterVB, offset: 0, index: Int(BufferIndex.vertices.rawValue))
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setFragmentTexture(terrain.heightTexture, index: Int(TextureIndex.terrainHeight.rawValue))
                encoder.drawIndexedPrimitives(type: .triangle, indexCount: waterIndexCount, indexType: .uint32, indexBuffer: waterIB, indexBufferOffset: 0)
            }

            // 8. 3D Splash & Breaching Water Spray Particles
            if !activeSplashParticles.isEmpty,
               let splashPSO = splashPipelineState,
               let partDS = particleDepthState,
               let splashPB = splashParticleBuffer {
                encoder.setRenderPipelineState(splashPSO)
                encoder.setDepthStencilState(partDS)
                encoder.setCullMode(.none)
                encoder.setVertexBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
                encoder.setVertexBuffer(splashPB, offset: 0, index: Int(BufferIndex.splashParticles.rawValue))
                encoder.drawPrimitives(
                    type: .triangleStrip,
                    vertexStart: 0,
                    vertexCount: 4,
                    instanceCount: min(activeSplashParticles.count, maxSplashParticles)
                )
            }

            encoder.endEncoding()
        }

        if let postEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: viewPassDescriptor),
           let postPSO = postProcessPipelineState {
            postEncoder.label = "PostProcessACESEncoder"
            postEncoder.setRenderPipelineState(postPSO)
            postEncoder.setCullMode(.none)
            postEncoder.setFragmentBuffer(uniformBuffer, offset: 0, index: Int(BufferIndex.uniforms.rawValue))
            postEncoder.setFragmentTexture(hdrResolveTex, index: Int(TextureIndex.hdrColor.rawValue))
            postEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            postEncoder.endEncoding()
        }

        commandBuffer.present(drawable)
        commandBuffer.commit()
    }

    // MARK: - 3D Splash Particle System (Lure Splash + Breaching Fish GPU Trigger)

    private func consumeFishSplashSignals(deltaTime: Float) {
        for key in splashCooldownByFish.keys {
            let rem = (splashCooldownByFish[key] ?? 0.0) - deltaTime
            if rem <= 0.0 {
                splashCooldownByFish.removeValue(forKey: key)
            } else {
                splashCooldownByFish[key] = rem
            }
        }

        guard let school = schoolingManager, let splashBuf = school.splashEventBuffer else { return }
        let count = school.targetFishCount
        let ptr = splashBuf.contents().bindMemory(to: SplashTriggerEvent.self, capacity: count)
        for i in 0..<count {
            let ev = ptr[i]
            if ev.intensityAndFlags.w > 0.5 && splashCooldownByFish[i] == nil {
                splashCooldownByFish[i] = 0.45
                let origin = SIMD3<Float>(ev.worldPositionAndRadius.x, waterSurfaceY + 0.05, ev.worldPositionAndRadius.z)
                spawnSplashBurst(origin: origin, intensity: ev.intensityAndFlags.x, count: 30)
                audioHaptics.playLureSplashSound(impactSpeed: max(5.0, ev.intensityAndFlags.y))
            }
        }
    }

    private func spawnSplashBurst(origin: SIMD3<Float>, intensity: Float, count: Int) {
        let clamped = max(0.25, min(1.0, intensity))
        for _ in 0..<count {
            if activeSplashParticles.count >= maxSplashParticles {
                activeSplashParticles.removeFirst()
            }
            let angle = Float.random(in: 0...(2.0 * Float.pi))
            let horizSpeed = Float.random(in: 0.6...3.2) * clamped
            let upSpeed = Float.random(in: 1.8...5.8) * clamped
            let vel = SIMD3<Float>(cos(angle) * horizSpeed, upSpeed, sin(angle) * horizSpeed)
            activeSplashParticles.append(ActiveSplashParticle(
                position: origin + SIMD3<Float>(Float.random(in: -0.18...0.18), 0.02, Float.random(in: -0.18...0.18)),
                velocity: vel,
                age: 0.0,
                lifetime: Float.random(in: 0.45...0.95),
                baseSize: Float.random(in: 0.08...0.22) * (0.6 + 0.6 * clamped)
            ))
        }
    }

    private func stepSplashParticles(deltaTime: Float) {
        guard let pb = splashParticleBuffer else { return }
        var surviving: [ActiveSplashParticle] = []
        surviving.reserveCapacity(activeSplashParticles.count)

        for var p in activeSplashParticles {
            p.age += deltaTime
            if p.age < p.lifetime {
                p.velocity.y -= 9.81 * deltaTime
                p.velocity *= (1.0 - min(0.25, deltaTime * 1.4))
                p.position += p.velocity * deltaTime
                surviving.append(p)
            }
        }
        activeSplashParticles = surviving

        let dst = pb.contents().bindMemory(to: SplashParticleData.self, capacity: maxSplashParticles)
        for i in 0..<min(surviving.count, maxSplashParticles) {
            let p = surviving[i]
            let lifeT = p.age / max(p.lifetime, 0.01)
            let size = p.baseSize * (1.0 + lifeT * 1.6)
            let alpha = (1.0 - lifeT) * (1.0 - lifeT) * 0.85
            dst[i] = SplashParticleData(
                positionAndSize: SIMD4<Float>(p.position.x, p.position.y, p.position.z, size),
                colorAndAlpha: SIMD4<Float>(0.88, 0.95, 0.98, alpha)
            )
        }
    }

    // MARK: - Rod, Reel, Lure & Line World Geometry Updates

    private func updateRodAnchorFromCamera() {
        if cameraController.mode == .firstPersonAboveWater {
            let camPos = cameraController.currentPosition
            let fwd = simd_normalize(cameraController.currentTarget - camPos)
            let right = simd_normalize(simd_cross(fwd, SIMD3<Float>(0, 1, 0)))
            let up = simd_cross(right, fwd)

            physicsRig.rodButtWorldPosition = camPos + right * 0.24 - up * 0.34 + fwd * 0.16
            physicsRig.rodBaseYaw = atan2(fwd.x, -fwd.z) - 0.08
            physicsRig.rodBasePitch = max(0.18, min(0.58, asin(max(-0.9, min(0.9, fwd.y))) + 0.32))
        }
    }

    private func updateDeformedRodBuffer() {
        guard let defVB = deformedRodVertexBuffer, !rodBaseVertices.isEmpty else { return }
        let dst = defVB.contents().bindMemory(to: Vertex.self, capacity: rodBaseVertices.count)
        let rodLen = physicsRig.rodLength
        let segCount = Float(RodAndLinePhysics.rodSegmentCount)
        let nodes = physicsRig.rodNodesWorld
        let tangents = physicsRig.rodTangentsWorld

        for i in 0..<rodBaseVertices.count {
            let v = rodBaseVertices[i]
            let localP = SIMD3<Float>(v.position.x, v.position.y, v.position.z)
            let frac = max(0.0, min(1.0, localP.z / rodLen))
            let fIdx = frac * segCount
            let i0 = max(0, min(RodAndLinePhysics.rodSegmentCount - 1, Int(fIdx)))
            let i1 = min(RodAndLinePhysics.rodSegmentCount, i0 + 1)
            let a = fIdx - Float(i0)

            let center = nodes[i0] + (nodes[i1] - nodes[i0]) * a
            let fwd = simd_normalize(tangents[i0] + (tangents[i1] - tangents[i0]) * a)
            let right = simd_normalize(simd_cross(fwd, SIMD3<Float>(0, 1, 0)))
            let up = simd_cross(right, fwd)

            let worldP = center + right * localP.x + up * localP.y
            let worldN = simd_normalize(right * v.normal.x + up * v.normal.y + fwd * v.normal.z)

            dst[i] = Vertex(
                position: SIMD4<Float>(worldP.x, worldP.y, worldP.z, 1.0),
                normal: SIMD4<Float>(worldN.x, worldN.y, worldN.z, v.normal.w),
                uvAndMaterial: v.uvAndMaterial
            )
        }
    }

    private func updateFishingLineRibbonBuffer(cameraPos: SIMD3<Float>) {
        guard let vb = lineStripVertexBuffer else { return }
        let dst = vb.contents().bindMemory(to: Vertex.self, capacity: lineStripVertexCount)
        let pts = physicsRig.linePositions
        let count = pts.count

        for i in 0..<count {
            let p = pts[i]
            let prev = pts[max(0, i - 1)]
            let next = pts[min(count - 1, i + 1)]
            let tangent = simd_length_squared(next - prev) > 1e-8 ? simd_normalize(next - prev) : SIMD3<Float>(0, -1, 0)
            let toCam = simd_length_squared(cameraPos - p) > 1e-8 ? simd_normalize(cameraPos - p) : SIMD3<Float>(0, 1, 0)
            let side = simd_length_squared(simd_cross(tangent, toCam)) > 1e-8 ? simd_normalize(simd_cross(tangent, toCam)) : SIMD3<Float>(1, 0, 0)

            let dist = simd_distance(cameraPos, p)
            let halfWidth = max(0.0022, min(0.016, dist * 0.0014))
            let pL = p - side * halfWidth
            let pR = p + side * halfWidth

            dst[i * 2] = Vertex(position: SIMD4<Float>(pL, 1.0), normal: SIMD4<Float>(0, 1, 0, 1), uvAndMaterial: SIMD4<Float>(0, Float(i) / Float(count - 1), 0, 0))
            dst[i * 2 + 1] = Vertex(position: SIMD4<Float>(pR, 1.0), normal: SIMD4<Float>(0, 1, 0, 1), uvAndMaterial: SIMD4<Float>(1, Float(i) / Float(count - 1), 0, 0))
        }
    }

    private func buildReelWorldMatrix() -> simd_float4x4 {
        let seatPos = physicsRig.deformRodVertex(localPosition: SIMD3<Float>(0, 0, 0.31))
        let fwd = simd_normalize(physicsRig.rodTangentsWorld[2])
        let right = simd_normalize(simd_cross(fwd, SIMD3<Float>(0, 1, 0)))
        let up = simd_cross(right, fwd)
        return simd_float4x4(columns: (
            SIMD4<Float>(right, 0),
            SIMD4<Float>(up, 0),
            SIMD4<Float>(fwd, 0),
            SIMD4<Float>(seatPos, 1)
        ))
    }

    private func buildLureWorldMatrix() -> simd_float4x4 {
        let lure = physicsRig.lureState
        let velDir = simd_length_squared(lure.velocity) > 0.01
            ? simd_normalize(lure.velocity)
            : SIMD3<Float>(0, 0, 1)
        let worldUp = SIMD3<Float>(0, 1, 0)
        var right = simd_cross(worldUp, velDir)
        right = simd_length_squared(right) < 1e-6 ? SIMD3<Float>(1, 0, 0) : simd_normalize(right)
        let up = simd_cross(velDir, right)

        let s: Float = 2.4
        let base = simd_float4x4(columns: (
            SIMD4<Float>(right * s, 0),
            SIMD4<Float>(up * s, 0),
            SIMD4<Float>(velDir * s, 0),
            SIMD4<Float>(lure.position, 1)
        ))
        return base * rotationYMatrix(lure.wobbleAngleRad) * rotationZMatrix(lure.rollAngleRad)
    }

    private func translationMatrix(_ t: SIMD3<Float>) -> simd_float4x4 {
        simd_float4x4(columns: (
            SIMD4<Float>(1, 0, 0, 0),
            SIMD4<Float>(0, 1, 0, 0),
            SIMD4<Float>(0, 0, 1, 0),
            SIMD4<Float>(t.x, t.y, t.z, 1)
        ))
    }

    private func rotationXMatrix(_ a: Float) -> simd_float4x4 {
        let c = cos(a), s = sin(a)
        return simd_float4x4(columns: (
            SIMD4<Float>(1, 0, 0, 0),
            SIMD4<Float>(0, c, s, 0),
            SIMD4<Float>(0, -s, c, 0),
            SIMD4<Float>(0, 0, 0, 1)
        ))
    }

    private func rotationYMatrix(_ a: Float) -> simd_float4x4 {
        let c = cos(a), s = sin(a)
        return simd_float4x4(columns: (
            SIMD4<Float>(c, 0, -s, 0),
            SIMD4<Float>(0, 1, 0, 0),
            SIMD4<Float>(s, 0, c, 0),
            SIMD4<Float>(0, 0, 0, 1)
        ))
    }

    private func rotationZMatrix(_ a: Float) -> simd_float4x4 {
        let c = cos(a), s = sin(a)
        return simd_float4x4(columns: (
            SIMD4<Float>(c, s, 0, 0),
            SIMD4<Float>(-s, c, 0, 0),
            SIMD4<Float>(0, 0, 1, 0),
            SIMD4<Float>(0, 0, 0, 1)
        ))
    }

    // MARK: - Frame Uniforms Builders

    private func buildUniforms(aspect: Float, size: CGSize, deltaTime: Float) -> Uniforms {
        let cameraParams = cameraController.buildCameraParams(aspect: aspect)
        let atmosphereParams = buildAtmosphereParams(timeOfDay: state.timeOfDayHours)
        let waterParams = buildWaterParams(deltaTime: deltaTime)

        return Uniforms(
            camera: cameraParams,
            atmosphere: atmosphereParams,
            water: waterParams,
            viewportAndTime: SIMD4<Float>(Float(size.width), Float(size.height), elapsedTime, Float(frameCounter))
        )
    }

    private func buildAtmosphereParams(timeOfDay: Float) -> AtmosphereParams {
        let normalizedHour = ((timeOfDay - 6.0) / 24.0) * (2.0 * Float.pi)
        let elevation = sin(normalizedHour) * 1.12
        let azimuth = cos(normalizedHour) * 1.15 - 0.35

        let sunDir = simd_normalize(SIMD3<Float>(
            sin(azimuth) * cos(elevation),
            sin(elevation),
            -cos(azimuth) * cos(elevation)
        ))

        let dayFactor = max(0.0, min(1.0, (sin(elevation) + 0.08) / 0.45))
        let sunsetFactor = max(0.0, 1.0 - abs(sin(elevation) - 0.12) * 3.2)

        let noonSun = SIMD3<Float>(1.0, 0.96, 0.90)
        let sunsetSun = SIMD3<Float>(1.0, 0.48, 0.22)
        let moonSun = SIMD3<Float>(0.24, 0.34, 0.56)

        var sunColor = simd_mix(moonSun, noonSun, SIMD3<Float>(repeating: dayFactor))
        sunColor = simd_mix(sunColor, sunsetSun, SIMD3<Float>(repeating: sunsetFactor * 0.78))

        let sunIntensity: Float = 0.45 + dayFactor * 6.8 + sunsetFactor * 1.6

        let zenithDay = SIMD3<Float>(0.11, 0.32, 0.72)
        let zenithNight = SIMD3<Float>(0.012, 0.022, 0.052)
        let zenithColor = simd_mix(zenithNight, zenithDay, SIMD3<Float>(repeating: dayFactor))

        let horizonDay = SIMD3<Float>(0.55, 0.73, 0.88)
        let horizonSunset = SIMD3<Float>(0.96, 0.46, 0.24)
        let horizonNight = SIMD3<Float>(0.03, 0.05, 0.10)
        var horizonColor = simd_mix(horizonNight, horizonDay, SIMD3<Float>(repeating: dayFactor))
        horizonColor = simd_mix(horizonColor, horizonSunset, SIMD3<Float>(repeating: sunsetFactor * 0.85))

        let ambientColor = simd_mix(
            SIMD3<Float>(0.03, 0.05, 0.09),
            SIMD3<Float>(0.24, 0.32, 0.42),
            SIMD3<Float>(repeating: dayFactor)
        )
        let exposure: Float = 0.88 + (1.0 - dayFactor) * 0.42

        return AtmosphereParams(
            sunDirectionAndElevation: SIMD4<Float>(sunDir.x, sunDir.y, sunDir.z, elevation),
            sunColorAndIntensity: SIMD4<Float>(sunColor.x, sunColor.y, sunColor.z, sunIntensity),
            skyZenithColorAndTime: SIMD4<Float>(zenithColor.x, zenithColor.y, zenithColor.z, timeOfDay),
            skyHorizonColorAndFog: SIMD4<Float>(horizonColor.x, horizonColor.y, horizonColor.z, 0.0042),
            rayleighCoeffAndScale: SIMD4<Float>(0.0058, 0.0135, 0.0331, 1.0),
            mieCoeffAndG: SIMD4<Float>(0.0042, 0.0045, 0.0050, 0.78),
            ambientColorAndExposure: SIMD4<Float>(ambientColor.x, ambientColor.y, ambientColor.z, exposure)
        )
    }

    private func buildWaterParams(deltaTime: Float) -> WaterParams {
        let w0 = makeWave(angleDeg: 18.0, steepness: 0.14, wavelength: 26.0)
        let w1 = makeWave(angleDeg: 42.0, steepness: 0.12, wavelength: 17.5)
        let w2 = makeWave(angleDeg: -25.0, steepness: 0.11, wavelength: 12.2)
        let w3 = makeWave(angleDeg: 75.0, steepness: 0.09, wavelength: 8.6)
        let w4 = makeWave(angleDeg: -58.0, steepness: 0.08, wavelength: 6.1)
        let w5 = makeWave(angleDeg: 112.0, steepness: 0.06, wavelength: 4.3)
        let w6 = makeWave(angleDeg: -10.0, steepness: 0.05, wavelength: 2.9)
        let w7 = makeWave(angleDeg: 52.0, steepness: 0.04, wavelength: 1.85)

        let terrainHalf = terrainMesh?.halfExtent ?? 64.0
        let causticFactor = governor.qualityProfile.causticSampleFactor

        return WaterParams(
            gerstnerWaves: (w0, w1, w2, w3, w4, w5, w6, w7),
            absorptionAndClarity: SIMD4<Float>(0.36, 0.12, 0.065, 0.85),
            deepColorAndSurfaceY: SIMD4<Float>(0.012, 0.065, 0.115, waterSurfaceY),
            shallowColorAndFoam: SIMD4<Float>(0.055, 0.24, 0.26, 0.42),
            causticParams: SIMD4<Float>(1.45 * causticFactor, 0.36, 0.72, 1.0 / 1.333),
            godRayParams: SIMD4<Float>(0.55 * causticFactor, 0.11, 1.0, 0.42),
            gridParams: SIMD4<Float>(waterHalfExtent, terrainHalf, elapsedTime, deltaTime)
        )
    }

    private func makeWave(angleDeg: Float, steepness: Float, wavelength: Float) -> SIMD4<Float> {
        let rad = angleDeg * .pi / 180.0
        return SIMD4<Float>(cos(rad), sin(rad), steepness, wavelength)
    }
}
