import Foundation
import simd

public enum CameraMode: Int, CaseIterable, Sendable, Identifiable {
    case firstPersonAboveWater = 0
    case castTracking = 1
    case underwaterPeriscope = 2
    case subsurfaceLureCam = 3

    public var id: Int { rawValue }

    public var displayName: String {
        switch self {
        case .firstPersonAboveWater:
            return "水上第一人称"
        case .castTracking:
            return "抛投追踪"
        case .underwaterPeriscope:
            return "水下潜望"
        case .subsurfaceLureCam:
            return "水下跟饵镜"
        }
    }

    public var isUnderwaterPreset: Bool {
        self == .underwaterPeriscope || self == .subsurfaceLureCam
    }
}

@MainActor
public final class CameraController {
    public private(set) var mode: CameraMode = .firstPersonAboveWater
    public private(set) var currentPosition: SIMD3<Float> = SIMD3<Float>(0.0, 2.35, 25.0)
    public private(set) var currentTarget: SIMD3<Float> = SIMD3<Float>(0.0, -0.35, -6.0)
    public private(set) var currentFovRadians: Float = 58.0 * .pi / 180.0
    public private(set) var underwaterBlend: Float = 0.0

    public var trackedLurePosition: SIMD3<Float> = SIMD3<Float>(0.0, -2.0, 6.0)
    public var trackedLureVelocity: SIMD3<Float> = SIMD3<Float>(0.0, 0.0, 1.0)

    private var yawOffset: Float = 0.0
    private var pitchOffset: Float = 0.0
    private var zoomOffset: Float = 0.0
    private var castPhaseTime: Float = 0.0

    public let nearPlane: Float = 0.12
    public let farPlane: Float = 450.0

    public init() {}

    public func setMode(_ newMode: CameraMode) {
        guard mode != newMode else { return }
        mode = newMode
        if newMode == .castTracking {
            castPhaseTime = 0.0
        }
        pitchOffset = max(-0.35, min(0.35, pitchOffset))
    }

    public func toggleWaterlineView() {
        if mode.isUnderwaterPreset {
            setMode(.firstPersonAboveWater)
        } else {
            setMode(.subsurfaceLureCam)
        }
    }

    public func updateLureTracking(position: SIMD3<Float>, velocity: SIMD3<Float>) {
        trackedLurePosition = position
        if simd_length_squared(velocity) > 0.01 {
            trackedLureVelocity = simd_normalize(velocity)
        }
    }

    public func applyLookDelta(dx: Float, dy: Float) {
        let sensitivity: Float = 0.0045
        yawOffset += dx * sensitivity
        pitchOffset = max(-0.78, min(0.72, pitchOffset - dy * sensitivity))
    }

    public func applyZoomDelta(scale: Float) {
        let delta = (1.0 - scale) * 6.0
        zoomOffset = max(-6.0, min(8.0, zoomOffset + delta))
    }

    public func update(deltaTime: Float, waterSurfaceY: Float, terrainHeightAt: (Float, Float) -> Float) {
        let dt = min(max(deltaTime, 0.0001), 0.05)
        castPhaseTime += dt

        let (desiredPos, desiredTarget, desiredFov) = computePresetPose()

        let baseForward = simd_normalize(desiredTarget - desiredPos)
        let baseYaw = atan2(baseForward.x, -baseForward.z)
        let basePitch = asin(max(-0.98, min(0.98, baseForward.y)))

        let finalYaw = baseYaw + yawOffset
        let finalPitch = max(-1.15, min(1.15, basePitch + pitchOffset))

        let lookDir = SIMD3<Float>(
            sin(finalYaw) * cos(finalPitch),
            sin(finalPitch),
            -cos(finalYaw) * cos(finalPitch)
        )

        var adjustedPos = desiredPos - lookDir * (zoomOffset * 0.45)

        let groundY = terrainHeightAt(adjustedPos.x, adjustedPos.z)
        let minClearance: Float = mode.isUnderwaterPreset ? 0.65 : 1.15
        if adjustedPos.y < groundY + minClearance {
            adjustedPos.y = groundY + minClearance
        }

        let adjustedTarget = (mode == .subsurfaceLureCam)
            ? trackedLurePosition + SIMD3<Float>(sin(yawOffset) * 1.2, sin(pitchOffset) * 0.8, 0.0)
            : (adjustedPos + lookDir * 24.0)

        let smoothRate: Float = (mode == .subsurfaceLureCam) ? 7.5 : 5.2
        let smoothFactor = 1.0 - exp(-dt * smoothRate)
        currentPosition = simd_mix(currentPosition, adjustedPos, SIMD3<Float>(repeating: smoothFactor))
        currentTarget = simd_mix(currentTarget, adjustedTarget, SIMD3<Float>(repeating: smoothFactor))
        currentFovRadians = currentFovRadians + (desiredFov - currentFovRadians) * smoothFactor

        let depthBelowSurface = waterSurfaceY - currentPosition.y
        let t = max(0.0, min(1.0, (depthBelowSurface + 0.18) / 0.36))
        underwaterBlend = t * t * (3.0 - 2.0 * t)
    }

    private func computePresetPose() -> (SIMD3<Float>, SIMD3<Float>, Float) {
        switch mode {
        case .firstPersonAboveWater:
            let pos = SIMD3<Float>(0.0, 2.35, 25.0)
            let target = SIMD3<Float>(0.0, -0.35, -6.0)
            return (pos, target, 58.0 * .pi / 180.0)

        case .castTracking:
            let phase = 0.5 - 0.5 * cos(castPhaseTime * 0.45)
            let pos = SIMD3<Float>(
                sin(castPhaseTime * 0.25) * 4.5 + 3.5,
                6.2 - phase * 2.2,
                19.0 - phase * 16.0
            )
            let target = SIMD3<Float>(
                1.5 * sin(castPhaseTime * 0.3),
                -0.8,
                -14.0 - phase * 8.0
            )
            return (pos, target, 52.0 * .pi / 180.0)

        case .underwaterPeriscope:
            let swayX = sin(castPhaseTime * 0.35) * 0.65
            let swayY = cos(castPhaseTime * 0.50) * 0.18
            let pos = SIMD3<Float>(swayX, -4.2 + swayY, 7.5)
            let target = SIMD3<Float>(0.0, -2.6, -18.0)
            return (pos, target, 66.0 * .pi / 180.0)

        case .subsurfaceLureCam:
            let lure = trackedLurePosition
            let trailDir = simd_normalize(SIMD3<Float>(trackedLureVelocity.x, 0.0, trackedLureVelocity.z))
            let side = SIMD3<Float>(-trailDir.z, 0.0, trailDir.x)
            let camPos = SIMD3<Float>(
                lure.x + trailDir.x * 1.45 + side.x * 0.95,
                min(-0.45, lure.y - 0.18),
                lure.z + trailDir.z * 1.45 + side.z * 0.95
            )
            return (camPos, lure, 62.0 * .pi / 180.0)
        }
    }

    public func buildCameraParams(aspect: Float) -> CameraParams {
        let safeAspect = max(aspect, 0.25)
        let worldUp = SIMD3<Float>(0.0, 1.0, 0.0)
        let forward = simd_normalize(currentTarget - currentPosition)
        let right = simd_normalize(simd_cross(forward, worldUp))
        let up = simd_cross(right, forward)

        let viewMatrix = Self.makeLookAt(eye: currentPosition, target: currentTarget, up: worldUp)
        let projMatrix = Self.makePerspectiveRightHanded(
            fovYRadians: currentFovRadians,
            aspect: safeAspect,
            nearZ: nearPlane,
            farZ: farPlane
        )
        let viewProj = projMatrix * viewMatrix
        let invViewProj = simd_inverse(viewProj)

        return CameraParams(
            viewMatrix: viewMatrix,
            projectionMatrix: projMatrix,
            viewProjectionMatrix: viewProj,
            invViewProjectionMatrix: invViewProj,
            positionAndFov: SIMD4<Float>(currentPosition.x, currentPosition.y, currentPosition.z, currentFovRadians),
            forwardAndNear: SIMD4<Float>(forward.x, forward.y, forward.z, nearPlane),
            rightAndFar: SIMD4<Float>(right.x, right.y, right.z, farPlane),
            upAndUnderwater: SIMD4<Float>(up.x, up.y, up.z, underwaterBlend)
        )
    }

    private static func makeLookAt(eye: SIMD3<Float>, target: SIMD3<Float>, up: SIMD3<Float>) -> simd_float4x4 {
        let zAxis = simd_normalize(eye - target)
        let xAxis = simd_normalize(simd_cross(up, zAxis))
        let yAxis = simd_cross(zAxis, xAxis)

        let col0 = SIMD4<Float>(xAxis.x, yAxis.x, zAxis.x, 0.0)
        let col1 = SIMD4<Float>(xAxis.y, yAxis.y, zAxis.y, 0.0)
        let col2 = SIMD4<Float>(xAxis.z, yAxis.z, zAxis.z, 0.0)
        let col3 = SIMD4<Float>(
            -simd_dot(xAxis, eye),
            -simd_dot(yAxis, eye),
            -simd_dot(zAxis, eye),
            1.0
        )
        return simd_float4x4(columns: (col0, col1, col2, col3))
    }

    private static func makePerspectiveRightHanded(
        fovYRadians: Float,
        aspect: Float,
        nearZ: Float,
        farZ: Float
    ) -> simd_float4x4 {
        let yScale = 1.0 / tan(fovYRadians * 0.5)
        let xScale = yScale / aspect
        let zRange = farZ - nearZ
        let zScale = -(farZ) / zRange
        let wzScale = -(farZ * nearZ) / zRange

        let col0 = SIMD4<Float>(xScale, 0.0, 0.0, 0.0)
        let col1 = SIMD4<Float>(0.0, yScale, 0.0, 0.0)
        let col2 = SIMD4<Float>(0.0, 0.0, zScale, -1.0)
        let col3 = SIMD4<Float>(0.0, 0.0, wzScale, 0.0)
        return simd_float4x4(columns: (col0, col1, col2, col3))
    }
}
