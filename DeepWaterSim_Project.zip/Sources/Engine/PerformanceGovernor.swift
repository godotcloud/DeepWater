import Foundation
import Combine
import Metal
import simd

public enum MeshLODLevel: Int, CaseIterable, Sendable {
    case high = 0
    case medium = 1
    case low = 2
}

public struct ThermalQualityProfile: Sendable, Equatable {
    public let thermalState: ProcessInfo.ThermalState
    public let renderResolutionScale: Float
    public let causticSampleFactor: Float
    public let godRayStepCount: Int
    public let distantWeedInstanceRatio: Float
    public let lodDistanceMultiplier: Float
    public let targetFPS: Int

    public var thermalLabel: String {
        switch thermalState {
        case .nominal: return "正常"
        case .fair: return "微温"
        case .serious: return "降载保护"
        case .critical: return "极限温控"
        @unknown default: return "正常"
        }
    }

    public static func profile(for state: ProcessInfo.ThermalState) -> ThermalQualityProfile {
        switch state {
        case .nominal:
            return ThermalQualityProfile(
                thermalState: state,
                renderResolutionScale: 1.00,
                causticSampleFactor: 1.00,
                godRayStepCount: 8,
                distantWeedInstanceRatio: 1.00,
                lodDistanceMultiplier: 1.00,
                targetFPS: 60
            )
        case .fair:
            return ThermalQualityProfile(
                thermalState: state,
                renderResolutionScale: 0.92,
                causticSampleFactor: 0.85,
                godRayStepCount: 6,
                distantWeedInstanceRatio: 0.78,
                lodDistanceMultiplier: 0.88,
                targetFPS: 60
            )
        case .serious:
            return ThermalQualityProfile(
                thermalState: state,
                renderResolutionScale: 0.85,
                causticSampleFactor: 0.58,
                godRayStepCount: 4,
                distantWeedInstanceRatio: 0.45,
                lodDistanceMultiplier: 0.72,
                targetFPS: 60
            )
        case .critical:
            return ThermalQualityProfile(
                thermalState: state,
                renderResolutionScale: 0.72,
                causticSampleFactor: 0.32,
                godRayStepCount: 2,
                distantWeedInstanceRatio: 0.20,
                lodDistanceMultiplier: 0.55,
                targetFPS: 45
            )
        @unknown default:
            return ThermalQualityProfile(
                thermalState: .nominal,
                renderResolutionScale: 1.00,
                causticSampleFactor: 1.00,
                godRayStepCount: 8,
                distantWeedInstanceRatio: 1.00,
                lodDistanceMultiplier: 1.00,
                targetFPS: 60
            )
        }
    }
}

public struct MeshLODBundle: @unchecked Sendable {
    public let lod0IndexBuffer: MTLBuffer
    public let lod0IndexCount: Int
    public let lod1IndexBuffer: MTLBuffer
    public let lod1IndexCount: Int
    public let lod2IndexBuffer: MTLBuffer
    public let lod2IndexCount: Int

    public func indexBuffer(for level: MeshLODLevel) -> (buffer: MTLBuffer, count: Int) {
        switch level {
        case .high: return (lod0IndexBuffer, lod0IndexCount)
        case .medium: return (lod1IndexBuffer, lod1IndexCount)
        case .low: return (lod2IndexBuffer, lod2IndexCount)
        }
    }
}

@MainActor
public final class PerformanceGovernor: ObservableObject {
    @Published public private(set) var qualityProfile: ThermalQualityProfile
    @Published public private(set) var effectiveRenderScale: Float = 1.0

    private var thermalCancellable: AnyCancellable?
    private var lastFishLODByID: [Int: MeshLODLevel] = [:]
    private var lastRockLODByID: [Int: MeshLODLevel] = [:]

    public init() {
        let initial = ThermalQualityProfile.profile(for: ProcessInfo.processInfo.thermalState)
        self.qualityProfile = initial
        self.effectiveRenderScale = initial.renderResolutionScale
        subscribeThermalState()
    }

    private func subscribeThermalState() {
        thermalCancellable = NotificationCenter.default
            .publisher(for: ProcessInfo.thermalStateDidChangeNotification)
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                self?.refreshThermalState()
            }
    }

    public func refreshThermalState() {
        let next = ThermalQualityProfile.profile(for: ProcessInfo.processInfo.thermalState)
        qualityProfile = next
        effectiveRenderScale = next.renderResolutionScale
    }

    public func scaledDrawableSize(from nativeSize: CGSize) -> CGSize {
        let s = CGFloat(effectiveRenderScale)
        return CGSize(
            width: max(320.0, (nativeSize.width * s).rounded()),
            height: max(240.0, (nativeSize.height * s).rounded())
        )
    }

    public func activeWeedInstanceCount(baseCount: Int) -> Int {
        max(0, Int((Float(baseCount) * qualityProfile.distantWeedInstanceRatio).rounded()))
    }

    public func evaluateFishLOD(entityID: Int, distanceMeters: Float) -> MeshLODLevel {
        let mult = qualityProfile.lodDistanceMultiplier
        let nearThreshold: Float = 7.5 * mult
        let midThreshold: Float = 19.0 * mult
        let hysteresis: Float = 1.2

        let prev = lastFishLODByID[entityID] ?? .high
        let next: MeshLODLevel
        switch prev {
        case .high:
            next = (distanceMeters > nearThreshold + hysteresis) ? .medium : .high
        case .medium:
            if distanceMeters < nearThreshold - hysteresis {
                next = .high
            } else if distanceMeters > midThreshold + hysteresis {
                next = .low
            } else {
                next = .medium
            }
        case .low:
            next = (distanceMeters < midThreshold - hysteresis) ? .medium : .low
        }

        lastFishLODByID[entityID] = next
        return next
    }

    public func evaluateRockLOD(clusterID: Int, distanceMeters: Float) -> MeshLODLevel {
        let mult = qualityProfile.lodDistanceMultiplier
        let nearThreshold: Float = 14.0 * mult
        let midThreshold: Float = 34.0 * mult
        let hysteresis: Float = 2.0

        let prev = lastRockLODByID[clusterID] ?? .high
        let next: MeshLODLevel
        switch prev {
        case .high:
            next = (distanceMeters > nearThreshold + hysteresis) ? .medium : .high
        case .medium:
            if distanceMeters < nearThreshold - hysteresis {
                next = .high
            } else if distanceMeters > midThreshold + hysteresis {
                next = .low
            } else {
                next = .medium
            }
        case .low:
            next = (distanceMeters < midThreshold - hysteresis) ? .medium : .low
        }

        lastRockLODByID[clusterID] = next
        return next
    }

    public static func buildLODBundle(
        device: MTLDevice,
        baseIndices: [UInt32],
        label: String
    ) -> MeshLODBundle? {
        guard baseIndices.count >= 3 else { return nil }
        let triCount = baseIndices.count / 3

        var lod1: [UInt32] = []
        var lod2: [UInt32] = []
        lod1.reserveCapacity((triCount / 2 + 1) * 3)
        lod2.reserveCapacity((triCount / 4 + 1) * 3)

        for t in 0..<triCount {
            let base = t * 3
            if t % 2 == 0 {
                lod1.append(baseIndices[base])
                lod1.append(baseIndices[base + 1])
                lod1.append(baseIndices[base + 2])
            }
            if t % 4 == 0 {
                lod2.append(baseIndices[base])
                lod2.append(baseIndices[base + 1])
                lod2.append(baseIndices[base + 2])
            }
        }

        if lod1.isEmpty { lod1 = baseIndices }
        if lod2.isEmpty { lod2 = lod1 }

        guard let b0 = device.makeBuffer(bytes: baseIndices, length: MemoryLayout<UInt32>.stride * baseIndices.count, options: .storageModeShared),
              let b1 = device.makeBuffer(bytes: lod1, length: MemoryLayout<UInt32>.stride * lod1.count, options: .storageModeShared),
              let b2 = device.makeBuffer(bytes: lod2, length: MemoryLayout<UInt32>.stride * lod2.count, options: .storageModeShared) else {
            return nil
        }

        b0.label = "\(label)_LOD0"
        b1.label = "\(label)_LOD1"
        b2.label = "\(label)_LOD2"

        return MeshLODBundle(
            lod0IndexBuffer: b0, lod0IndexCount: baseIndices.count,
            lod1IndexBuffer: b1, lod1IndexCount: lod1.count,
            lod2IndexBuffer: b2, lod2IndexCount: lod2.count
        )
    }
}
