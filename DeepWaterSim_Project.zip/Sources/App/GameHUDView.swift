import SwiftUI
import simd

public struct GameHUDView: View {
    @ObservedObject public var simState: SimulationState
    @ObservedObject public var inputController: CastAndInputController
    @ObservedObject public var ecosystem: EcosystemEngine
    @ObservedObject public var governor: PerformanceGovernor
    @ObservedObject public var catchStore: CatchLogStore

    public let hookedFishSpecies: FishSpecies?
    public let hookedFishState: FishAIState?
    public let hookedFishStamina: Float
    public let maxSpoolCapacityMeters: Float

    public let onOpenCatchLog: () -> Void
    public let onTwitch: () -> Void
    public let onRodPumpChanged: (Bool) -> Void
    public let onLandFish: () -> Void
    public let onResetBrokenLine: () -> Void
    public let onToggleTestFight: () -> Void
    public let onFreeRoamMove: (SIMD3<Float>) -> Void

    @State private var showQuickSettings: Bool = false
    @State private var isHoldingReel: Bool = false
    @State private var isHoldingPump: Bool = false
    @State private var reelIconSpinDeg: Double = 0.0

    public var body: some View {
        VStack(spacing: 8) {
            // Top bar: strictly single-line pills so Portrait never wraps text vertically
            HStack(alignment: .center, spacing: 6) {
                topLeftEcoPill
                Spacer(minLength: 4)
                topRightActionCluster
            }

            if simState.isLandingInProgress {
                landingBanner
                    .transition(.scale.combined(with: .opacity))
            } else if let species = hookedFishSpecies, let fishState = hookedFishState {
                hookedFishBanner(species: species, fishState: fishState)
                    .transition(.scale.combined(with: .opacity))
            }

            if showQuickSettings {
                quickEnvironmentPanel
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }

            // Visual Cast Power Meter with Sweet-Spot Zone (Fishing Planet / Fishing Clash style)
            if inputController.isChargingCast {
                castPowerBar
                    .transition(.scale.combined(with: .opacity))
            }

            Spacer()

            if simState.cameraMode == .underwaterFreeRoam {
                underwaterFreeRoamControls
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }

            // Bottom Ergonomic Left-Right Control Cluster
            HStack(alignment: .bottom) {
                leftTelemetryAndDragCluster
                Spacer()
                rightProFishingControls
            }
        }
        .padding(.horizontal, 12)
        .padding(.top, 4)
        .padding(.bottom, 10)
        .safeAreaPadding(.horizontal, 4)
    }

    // MARK: - Top-Left Compact Eco Pill (Zero Vertical Wrapping)

    private var topLeftEcoPill: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 6) {
                Circle()
                    .fill(thermalIndicatorColor)
                    .frame(width: 6, height: 6)
                Text("\(simState.fps)FPS")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                Text(String(format: "%.0fhPa%@", ecosystem.barometricPressureHPa, pressureArrow))
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(.cyan)
                Text(String(format: "%.1f°C", ecosystem.waterTemperature(depthMeters: inputController.lureDepthMeters)))
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
            }
            .lineLimit(1)
            .fixedSize(horizontal: true, vertical: false)

            HStack(spacing: 6) {
                Text(simState.timeOfDayLabel)
                Text("·")
                Text(String(format: "深%.1fm", simState.waterDepthMeters))
                Text("·")
                Text("\(inputController.rodPower.shortCode)/\(inputController.activeLure.chineseName)")
            }
            .font(.system(size: 9, weight: .medium, design: .monospaced))
            .foregroundStyle(.white.opacity(0.78))
            .lineLimit(1)
            .fixedSize(horizontal: true, vertical: false)
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(.ultraThinMaterial.opacity(0.82))
        .background(Color.black.opacity(0.32))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.white.opacity(0.15), lineWidth: 0.7))
    }

    // MARK: - Top-Right Compact Non-Wrapping Action Pills

    private var topRightActionCluster: some View {
        HStack(spacing: 5) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    if simState.cameraMode == .underwaterFreeRoam {
                        simState.cameraMode = .firstPersonAboveWater
                        onFreeRoamMove(.zero)
                    } else {
                        simState.cameraMode = .underwaterFreeRoam
                    }
                }
            } label: {
                HStack(spacing: 3) {
                    Image(systemName: simState.cameraMode == .underwaterFreeRoam ? "arrow.up.to.line" : "figure.pool.swim")
                    Text(simState.cameraMode == .underwaterFreeRoam ? "水面" : "漫游")
                }
                .font(.system(size: 10, weight: .bold))
                .lineLimit(1)
                .fixedSize()
                .padding(.horizontal, 8)
                .padding(.vertical, 7)
                .background(simState.cameraMode == .underwaterFreeRoam ? Color.teal.opacity(0.72) : Color.indigo.opacity(0.55))
                .clipShape(Capsule())
            }
            .buttonStyle(.plain)

            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    onFreeRoamMove(.zero)
                    simState.cameraMode = (simState.cameraMode == .subsurfaceLureCam) ? .firstPersonAboveWater : .subsurfaceLureCam
                }
            } label: {
                HStack(spacing: 3) {
                    Image(systemName: "scope")
                    Text(simState.cameraMode == .subsurfaceLureCam ? "退出" : "跟饵")
                }
                .font(.system(size: 10, weight: .bold))
                .lineLimit(1)
                .fixedSize()
                .padding(.horizontal, 8)
                .padding(.vertical, 7)
                .background(simState.cameraMode == .subsurfaceLureCam ? Color.cyan.opacity(0.65) : Color.blue.opacity(0.48))
                .clipShape(Capsule())
            }
            .buttonStyle(.plain)

            Button(action: onOpenCatchLog) {
                HStack(spacing: 3) {
                    Image(systemName: "fish.fill")
                    Text("\(catchStore.records.count)")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                }
                .lineLimit(1)
                .fixedSize()
                .padding(.horizontal, 8)
                .padding(.vertical, 7)
                .background(Color.white.opacity(0.18))
                .clipShape(Capsule())
            }
            .buttonStyle(.plain)

            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    showQuickSettings.toggle()
                }
            } label: {
                Image(systemName: showQuickSettings ? "xmark" : "slider.horizontal.3")
                    .font(.system(size: 11, weight: .bold))
                    .frame(width: 28, height: 28)
                    .background(Color.white.opacity(0.18))
                    .clipShape(Circle())
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(.white)
    }

    // MARK: - Cast Power Bar with Sweet-Spot Zone

    private var castPowerBar: some View {
        let p = CGFloat(max(0.0, min(1.0, inputController.castChargeProgress)))
        let inSweetSpot = (p >= 0.68 && p <= 0.86)
        return VStack(spacing: 4) {
            Text(inSweetSpot ? "松手抛投 · 精准黄金力度！" : "蓄力抛投 \(Int(p * 100))%")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(inSweetSpot ? .green : .white)

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.black.opacity(0.45))
                    // Green sweet-spot zone (68%..86%)
                    Rectangle()
                        .fill(Color.green.opacity(0.45))
                        .frame(width: geo.size.width * 0.18)
                        .offset(x: geo.size.width * 0.68)
                    Capsule()
                        .fill(inSweetSpot ? Color.green : Color.cyan)
                        .frame(width: geo.size.width * p)
                }
                .clipShape(Capsule())
            }
            .frame(width: 210, height: 10)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial.opacity(0.85))
        .clipShape(Capsule())
        .overlay(Capsule().stroke(inSweetSpot ? Color.green : Color.cyan.opacity(0.6), lineWidth: 1.2))
    }

    // MARK: - Left Cluster: Dual-Arc Tension Meter + Ergonomic Drag Micro-Adjust

    private var leftTelemetryAndDragCluster: some View {
        let tension = CGFloat(max(0.0, min(1.0, inputController.normalizedTension)))
        let remainingRatio = CGFloat(max(0.0, min(1.0, (maxSpoolCapacityMeters - inputController.lineOutMeters) / max(maxSpoolCapacityMeters, 1.0))))

        return VStack(alignment: .leading, spacing: 8) {
            ZStack {
                LeftArcShape(startDeg: 132, endDeg: 228)
                    .stroke(Color.white.opacity(0.18), style: StrokeStyle(lineWidth: 7, lineCap: .round))
                LeftArcShape(startDeg: 132, endDeg: 132 + 96 * Double(tension))
                    .stroke(tensionColor(tension), style: StrokeStyle(lineWidth: 7, lineCap: .round))

                LeftArcShape(startDeg: 138, endDeg: 222)
                    .inset(by: 11)
                    .stroke(Color.white.opacity(0.12), style: StrokeStyle(lineWidth: 4, lineCap: .round))
                LeftArcShape(startDeg: 138, endDeg: 138 + 84 * Double(remainingRatio))
                    .inset(by: 11)
                    .stroke(Color.teal.opacity(0.90), style: StrokeStyle(lineWidth: 4, lineCap: .round))

                VStack(alignment: .leading, spacing: 2) {
                    Text(inputController.isLineBroken ? "断线!" : String(format: "%.1fN", inputController.currentLineTensionN))
                        .font(.system(size: 12, weight: .heavy, design: .monospaced))
                        .foregroundStyle(inputController.isLineBroken ? .red : tensionColor(tension))
                    Text(String(format: "余线 %.0fm", max(0.0, maxSpoolCapacityMeters - inputController.lineOutMeters)))
                        .font(.system(size: 9, weight: .semibold, design: .monospaced))
                        .foregroundStyle(.white.opacity(0.88))
                    Text(String(format: "饵深 %.1fm", inputController.lureDepthMeters))
                        .font(.system(size: 9, weight: .medium, design: .monospaced))
                        .foregroundStyle(.cyan)
                }
                .offset(x: 16)
            }
            .frame(width: 108, height: 132)

            // Left-Thumb Drag Clutch Quick Controls (泄力 - / + 微调)
            HStack(spacing: 6) {
                Button {
                    inputController.dragSetting = max(0.05, inputController.dragSetting - 0.05)
                } label: {
                    Image(systemName: "minus")
                        .font(.system(size: 11, weight: .bold))
                        .frame(width: 26, height: 26)
                        .background(Color.black.opacity(0.48))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)

                VStack(spacing: 1) {
                    Text("泄力")
                        .font(.system(size: 8))
                        .foregroundStyle(.white.opacity(0.7))
                    Text("\(Int(inputController.dragSetting * 100))%")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .foregroundStyle(.orange)
                }
                .frame(width: 38)

                Button {
                    inputController.dragSetting = min(1.0, inputController.dragSetting + 0.05)
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 11, weight: .bold))
                        .frame(width: 26, height: 26)
                        .background(Color.black.opacity(0.48))
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 6)
            .padding(.vertical, 5)
            .background(.ultraThinMaterial.opacity(0.75))
            .clipShape(Capsule())
            .overlay(Capsule().stroke(Color.orange.opacity(0.45), lineWidth: 0.8))

            HStack(spacing: 6) {
                Button {
                    let next: InputControlMode = (inputController.controlMode == .motionCasting) ? .oneHandTouch : .motionCasting
                    inputController.setControlMode(next)
                } label: {
                    HStack(spacing: 4) {
                        Image(systemName: inputController.controlMode == .motionCasting ? "gyroscope" : "hand.tap.fill")
                        Text(inputController.controlMode == .motionCasting ? "体感" : "触控")
                    }
                    .font(.system(size: 10, weight: .semibold))
                    .padding(.horizontal, 9)
                    .padding(.vertical, 6)
                    .background(Color.black.opacity(0.45))
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(Color.white.opacity(0.20), lineWidth: 0.7))
                }
                .buttonStyle(.plain)

                if inputController.isLineBroken {
                    Button(action: onResetBrokenLine) {
                        Text("重绑线组")
                            .font(.system(size: 10, weight: .bold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 6)
                            .background(Color.red.opacity(0.72))
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
            .foregroundStyle(.white)
        }
    }

    // MARK: - Right Pro Fishing Controls (Hold-to-Reel + Slide-Speed + Rod Pump + Cast)

    private var rightProFishingControls: some View {
        VStack(alignment: .trailing, spacing: 10) {
            HStack(spacing: 8) {
                // Rod Pump / Twitch Button (点按抽竿 / 长按扬竿泵鱼)
                VStack(spacing: 2) {
                    Image(systemName: "arrow.up.forward")
                        .font(.system(size: 14, weight: .bold))
                    Text(hookedFishSpecies != nil ? "扬竿" : "抽竿")
                        .font(.system(size: 10, weight: .bold))
                }
                .foregroundStyle(.white)
                .frame(width: 54, height: 54)
                .background(isHoldingPump ? Color.teal.opacity(0.85) : Color.teal.opacity(0.45))
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.32), lineWidth: 1))
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { _ in
                            if !isHoldingPump {
                                isHoldingPump = true
                                onRodPumpChanged(true)
                            }
                        }
                        .onEnded { _ in
                            isHoldingPump = false
                            onRodPumpChanged(false)
                        }
                )

                // Hold-to-Charge Cast Button (蓄力抛投)
                VStack(spacing: 2) {
                    Image(systemName: "location.north.fill")
                        .font(.system(size: 14, weight: .bold))
                    Text(inputController.isChargingCast ? "\(Int(inputController.castChargeProgress * 100))%" : "抛投")
                        .font(.system(size: 10, weight: .bold))
                }
                .foregroundStyle(.white)
                .frame(width: 54, height: 54)
                .background(inputController.isChargingCast ? Color.cyan.opacity(0.82) : Color.blue.opacity(0.50))
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.35), lineWidth: 1))
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { _ in
                            if !inputController.isChargingCast {
                                inputController.beginTouchCastCharge()
                            }
                        }
                        .onEnded { _ in
                            inputController.releaseTouchCast()
                        }
                )
            }

            // Primary Hold-to-Reel & Slide-Up/Down Speed Pad (按住收线 · 上下滑动无级控速)
            ZStack {
                Circle()
                    .fill(.ultraThinMaterial.opacity(0.65))
                    .background(Circle().fill(isHoldingReel ? Color.cyan.opacity(0.35) : Color.black.opacity(0.40)))
                    .frame(width: 94, height: 94)
                    .overlay(Circle().stroke(isHoldingReel ? Color.cyan : Color.white.opacity(0.35), lineWidth: isHoldingReel ? 2.5 : 1.5))

                // Speed gauge ring
                Circle()
                    .trim(from: 0.0, to: CGFloat(inputController.reelThrottle))
                    .stroke(Color.cyan, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .frame(width: 82, height: 82)

                VStack(spacing: 2) {
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(isHoldingReel ? .cyan : .white)
                        .rotationEffect(.degrees(reelIconSpinDeg))
                    Text(isHoldingReel ? String(format: "%.1fm/s", inputController.currentRetrieveSpeedMetersPerSec) : "按住收线")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white)
                    Text("上下滑控速")
                        .font(.system(size: 8))
                        .foregroundStyle(.white.opacity(0.65))
                }
            }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        isHoldingReel = true
                        // Base comfortable speed 0.55; sliding thumb up increases speed to 1.0, down slows to 0.18
                        let slideDelta = Float(-value.translation.height) * 0.008
                        let speed = max(0.18, min(1.0, 0.55 + slideDelta))
                        inputController.reelThrottle = speed
                        reelIconSpinDeg += Double(speed) * 14.0
                    }
                    .onEnded { _ in
                        isHoldingReel = false
                        inputController.reelThrottle = 0.0
                    }
            )
        }
    }

    // MARK: - Underwater Free-Roam Controls & Banners

    private var underwaterFreeRoamControls: some View {
        HStack(spacing: 8) {
            holdMovePill(label: "前进", icon: "arrow.up", vec: SIMD3<Float>(0, 0, 1))
            holdMovePill(label: "后退", icon: "arrow.down", vec: SIMD3<Float>(0, 0, -1))
            holdMovePill(label: "上浮", icon: "chevron.up", vec: SIMD3<Float>(0, 1, 0))
            holdMovePill(label: "下潜", icon: "chevron.down", vec: SIMD3<Float>(0, -1, 0))
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(.ultraThinMaterial.opacity(0.78))
        .background(Color.black.opacity(0.35))
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.cyan.opacity(0.40), lineWidth: 0.8))
    }

    private func holdMovePill(label: String, icon: String, vec: SIMD3<Float>) -> some View {
        HStack(spacing: 3) {
            Image(systemName: icon)
            Text(label)
        }
        .font(.system(size: 10, weight: .semibold))
        .foregroundStyle(.white)
        .padding(.horizontal, 9)
        .padding(.vertical, 6)
        .background(Color.cyan.opacity(0.32))
        .clipShape(Capsule())
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in onFreeRoamMove(vec) }
                .onEnded { _ in onFreeRoamMove(.zero) }
        )
    }

    private var landingBanner: some View {
        HStack(spacing: 8) {
            Image(systemName: "sparkles")
                .foregroundStyle(.yellow)
            Text("起竿提鱼入护中...")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(.white)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 7)
        .background(Color.green.opacity(0.65))
        .clipShape(Capsule())
    }

    private func hookedFishBanner(species: FishSpecies, fishState: FishAIState) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text("中鱼！\(species.chineseName) · \(simState.fightHintText.isEmpty ? fishState.chineseName : simState.fightHintText)")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(simState.fightHintText.contains("喘息") ? .green : .white)
                ProgressView(value: Double(max(0.0, min(1.0, hookedFishStamina))))
                    .tint(hookedFishStamina < 0.15 ? .green : .orange)
                    .frame(width: 140)
            }

            if fishState == .exhausted || hookedFishStamina <= 0.12 {
                Button(action: onLandFish) {
                    Label("起竿入护", systemImage: "checkmark.seal.fill")
                        .font(.system(size: 11, weight: .bold))
                        .padding(.horizontal, 11)
                        .padding(.vertical, 6)
                        .background(Color.green.opacity(0.80))
                        .foregroundStyle(.white)
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.black.opacity(0.58))
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.orange.opacity(0.68), lineWidth: 1))
    }

    private var quickEnvironmentPanel: some View {
        VStack(spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: "sun.horizon.fill").foregroundStyle(.yellow).font(.system(size: 11))
                Slider(value: $simState.timeOfDayHours, in: 0.0...23.95, step: 0.05).tint(.cyan)
                Button(action: onToggleTestFight) {
                    Text(inputController.simulatedFishFightActive ? "停测" : "试鱼")
                        .font(.system(size: 10, weight: .bold))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.orange.opacity(0.55))
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }

            HStack(spacing: 4) {
                ForEach(CameraMode.allCases) { mode in
                    Button {
                        onFreeRoamMove(.zero)
                        simState.cameraMode = mode
                    } label: {
                        Text(mode.displayName)
                            .font(.system(size: 8.5, weight: .semibold))
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 5)
                            .background(simState.cameraMode == mode ? Color.cyan.opacity(0.45) : Color.white.opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 7, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
            }

            HStack(spacing: 6) {
                ForEach(RodPower.allCases) { power in
                    Button {
                        inputController.rodPower = power
                    } label: {
                        Text(power.shortCode)
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(inputController.rodPower == power ? Color.orange.opacity(0.48) : Color.white.opacity(0.10))
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
                Spacer()
                ForEach(LureType.allCases) { lure in
                    Button {
                        inputController.activeLure = lure
                    } label: {
                        Text(lure.chineseName)
                            .font(.system(size: 10, weight: .medium))
                            .padding(.horizontal, 7)
                            .padding(.vertical, 4)
                            .background(inputController.activeLure == lure ? Color.teal.opacity(0.48) : Color.white.opacity(0.10))
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .foregroundStyle(.white)
        .padding(10)
        .frame(maxWidth: 380)
        .background(.ultraThinMaterial.opacity(0.84))
        .background(Color.black.opacity(0.35))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.white.opacity(0.15), lineWidth: 0.8))
    }

    private var thermalIndicatorColor: Color {
        switch governor.qualityProfile.thermalState {
        case .nominal: return .green
        case .fair: return .yellow
        case .serious: return .orange
        case .critical: return .red
        @unknown default: return .green
        }
    }

    private var pressureArrow: String {
        switch ecosystem.barometricTrend {
        case .rising: return "↗"
        case .steady: return "→"
        case .falling: return "↘"
        case .stormFront: return "⇊"
        }
    }

    private func tensionColor(_ ratio: CGFloat) -> Color {
        if ratio > 0.80 { return .red }
        if ratio > 0.55 { return .orange }
        return .cyan
    }
}

private struct LeftArcShape: InsettableShape {
    var startDeg: Double
    var endDeg: Double
    var insetAmount: CGFloat = 0

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.maxX + 18, y: rect.midY)
        let radius = max(10, min(rect.width, rect.height) * 0.55 - insetAmount)
        path.addArc(
            center: center,
            radius: radius,
            startAngle: .degrees(startDeg),
            endAngle: .degrees(endDeg),
            clockwise: false
        )
        return path
    }

    func inset(by amount: CGFloat) -> some InsettableShape {
        var copy = self
        copy.insetAmount += amount
        return copy
    }
}
