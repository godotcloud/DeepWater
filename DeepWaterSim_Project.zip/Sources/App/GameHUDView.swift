import SwiftUI

public struct GameHUDView: View {
    @ObservedObject public var simState: SimulationState
    @ObservedObject public var inputController: CastAndInputController
    @ObservedObject public var ecosystem: EcosystemEngine
    @ObservedObject public var governor: PerformanceGovernor
    @ObservedObject public var catchStore: CatchLogStore

    public let hookedFishSpecies: FishSpecies?
    public let hookedFishState: FishAIState?
    public let hookedFishStamina: Float
    public let maxSpoolCapacityMeters: Float

    public let onOpenCatchLog: () -> Void
    public let onTwitch: () -> Void
    public let onLandFish: () -> Void
    public let onResetBrokenLine: () -> Void
    public let onToggleTestFight: () -> Void

    @State private var showQuickSettings: Bool = false
    @State private var crankAngleRad: Double = 0.0
    @State private var lastCrankAngleRad: Double? = nil

    public var body: some View {
        ZStack {
            HStack {
                leftArcTelemetryGauge
                Spacer()
                rightTactileReelAndDragCluster
            }
            .padding(.horizontal, 12)

            VStack(spacing: 8) {
                HStack(alignment: .top, spacing: 8) {
                    topLeftEcoPill
                    Spacer()
                    topRightActionCluster
                }

                if let species = hookedFishSpecies, let fishState = hookedFishState {
                    hookedFishBanner(species: species, fishState: fishState)
                        .transition(.scale.combined(with: .opacity))
                }

                if showQuickSettings {
                    quickEnvironmentPanel
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }

                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.top, 4)
        }
        .safeAreaPadding(.horizontal, 6)
        .safeAreaPadding(.vertical, 4)
    }

    private var topLeftEcoPill: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 8) {
                HStack(spacing: 4) {
                    Circle()
                        .fill(thermalIndicatorColor)
                        .frame(width: 6, height: 6)
                    Text("\(simState.fps) FPS")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                }

                Text(String(format: "%.0fhPa %@", ecosystem.barometricPressureHPa, pressureArrow))
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(.cyan)

                Text(String(format: "%.1f°C", ecosystem.waterTemperature(depthMeters: inputController.lureDepthMeters)))
                    .font(.system(size: 10, weight: .medium, design: .monospaced))

                Text(String(format: "深 %.1fm", simState.waterDepthMeters))
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
            }

            HStack(spacing: 8) {
                Text(simState.timeOfDayLabel)
                Text("·")
                Text("渲染 \(Int(governor.effectiveRenderScale * 100))% (\(governor.qualityProfile.thermalLabel))")
                Text("·")
                Text(inputController.rodPower.shortCode + "/" + inputController.activeLure.chineseName)
            }
            .font(.system(size: 9, weight: .medium, design: .monospaced))
            .foregroundStyle(.white.opacity(0.75))
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 11)
        .padding(.vertical, 7)
        .background(.ultraThinMaterial.opacity(0.82))
        .background(Color.black.opacity(0.32))
        .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 13, style: .continuous)
                .stroke(Color.white.opacity(0.15), lineWidth: 0.7)
        )
    }

    private var topRightActionCluster: some View {
        HStack(spacing: 7) {
            Button {
                withAnimation(.easeInOut(duration: 0.25)) {
                    if simState.cameraMode == .subsurfaceLureCam {
                        simState.cameraMode = .firstPersonAboveWater
                    } else {
                        simState.cameraMode = .subsurfaceLureCam
                    }
                }
            } label: {
                Label(
                    simState.cameraMode == .subsurfaceLureCam ? "退出跟饵镜" : "水下跟饵镜",
                    systemImage: simState.cameraMode == .subsurfaceLureCam ? "eye.slash.fill" : "scope"
                )
                .font(.system(size: 11, weight: .bold))
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(simState.cameraMode == .subsurfaceLureCam ? Color.cyan.opacity(0.55) : Color.blue.opacity(0.38))
                .clipShape(Capsule())
            }
            .buttonStyle(.plain)

            Button(action: onOpenCatchLog) {
                HStack(spacing: 4) {
                    Image(systemName: "fish.fill")
                    Text("\(catchStore.records.count)")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(Color.white.opacity(0.16))
                .clipShape(Capsule())
            }
            .buttonStyle(.plain)

            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    showQuickSettings.toggle()
                }
            } label: {
                Image(systemName: showQuickSettings ? "xmark" : "slider.horizontal.3")
                    .font(.system(size: 11, weight: .bold))
                    .frame(width: 30, height: 30)
                    .background(Color.white.opacity(0.16))
                    .clipShape(Circle())
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(.white)
    }

    private var leftArcTelemetryGauge: some View {
        let tension = CGFloat(max(0.0, min(1.0, inputController.normalizedTension)))
        let remainingRatio = CGFloat(max(0.0, min(1.0, (maxSpoolCapacityMeters - inputController.lineOutMeters) / max(maxSpoolCapacityMeters, 1.0))))

        return VStack(alignment: .leading, spacing: 8) {
            ZStack {
                LeftArcShape(startDeg: 130, endDeg: 230)
                    .stroke(Color.white.opacity(0.16), style: StrokeStyle(lineWidth: 7, lineCap: .round))
                LeftArcShape(startDeg: 130, endDeg: 130 + 100 * Double(tension))
                    .stroke(tensionColor(tension), style: StrokeStyle(lineWidth: 7, lineCap: .round))

                LeftArcShape(startDeg: 136, endDeg: 224)
                    .inset(by: 12)
                    .stroke(Color.white.opacity(0.12), style: StrokeStyle(lineWidth: 4, lineCap: .round))
                LeftArcShape(startDeg: 136, endDeg: 136 + 88 * Double(remainingRatio))
                    .inset(by: 12)
                    .stroke(Color.teal.opacity(0.88), style: StrokeStyle(lineWidth: 4, lineCap: .round))

                VStack(alignment: .leading, spacing: 2) {
                    Text(inputController.isLineBroken ? "断线" : String(format: "%.1fN", inputController.currentLineTensionN))
                        .font(.system(size: 12, weight: .heavy, design: .monospaced))
                        .foregroundStyle(inputController.isLineBroken ? .red : tensionColor(tension))
                    Text(String(format: "余线 %.0fm", max(0.0, maxSpoolCapacityMeters - inputController.lineOutMeters)))
                        .font(.system(size: 9, weight: .semibold, design: .monospaced))
                        .foregroundStyle(.white.opacity(0.85))
                    Text(String(format: "饵深 %.1fm", inputController.lureDepthMeters))
                        .font(.system(size: 9, weight: .medium, design: .monospaced))
                        .foregroundStyle(.cyan.opacity(0.9))
                }
                .offset(x: 18)
            }
            .frame(width: 112, height: 158)

            HStack(spacing: 6) {
                Button {
                    let next: InputControlMode = (inputController.controlMode == .motionCasting) ? .oneHandTouch : .motionCasting
                    inputController.setControlMode(next)
                } label: {
                    Image(systemName: inputController.controlMode == .motionCasting ? "gyroscope" : "hand.tap.fill")
                        .font(.system(size: 12, weight: .bold))
                        .frame(width: 32, height: 32)
                        .background(Color.black.opacity(0.42))
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white.opacity(0.22), lineWidth: 0.8))
                }
                .buttonStyle(.plain)

                if inputController.isLineBroken {
                    Button(action: onResetBrokenLine) {
                        Text("重绑线组")
                            .font(.system(size: 10, weight: .bold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 6)
                            .background(Color.red.opacity(0.65))
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
            .foregroundStyle(.white)
        }
    }

    private var rightTactileReelAndDragCluster: some View {
        VStack(alignment: .trailing, spacing: 10) {
            VStack(spacing: 3) {
                ZStack {
                    Circle()
                        .fill(Color.black.opacity(0.45))
                        .frame(width: 58, height: 58)
                    Circle()
                        .trim(from: 0.0, to: CGFloat(inputController.dragSetting))
                        .stroke(Color.orange, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .frame(width: 52, height: 52)
                    Circle()
                        .stroke(Color.white.opacity(0.22), style: StrokeStyle(lineWidth: 2, dash: [2, 4]))
                        .frame(width: 40, height: 40)
                        .rotationEffect(.degrees(Double(inputController.dragSetting) * 270.0))

                    VStack(spacing: 0) {
                        Text("泄力")
                            .font(.system(size: 8, weight: .medium))
                            .foregroundStyle(.white.opacity(0.7))
                        Text("\(Int(inputController.dragSetting * 100))%")
                            .font(.system(size: 11, weight: .bold, design: .monospaced))
                            .foregroundStyle(.orange)
                    }
                }
                .gesture(
                    DragGesture(minimumDistance: 2)
                        .onChanged { value in
                            let delta = Float(-value.translation.height) * 0.0045
                            let next = max(0.05, min(1.0, inputController.dragSetting + delta * 0.12))
                            inputController.dragSetting = next
                        }
                )
            }

            HStack(spacing: 6) {
                Button(action: onTwitch) {
                    Text("抽竿")
                        .font(.system(size: 11, weight: .bold))
                        .padding(.horizontal, 11)
                        .padding(.vertical, 7)
                        .background(Color.teal.opacity(0.48))
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)

                Text(inputController.isChargingCast ? "\(Int(inputController.castChargeProgress * 100))%" : "抛投")
                    .font(.system(size: 11, weight: .bold))
                    .padding(.horizontal, 13)
                    .padding(.vertical, 7)
                    .background(inputController.isChargingCast ? Color.cyan.opacity(0.70) : Color.blue.opacity(0.50))
                    .clipShape(Capsule())
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { _ in
                                if !inputController.isChargingCast {
                                    inputController.beginTouchCastCharge()
                                }
                            }
                            .onEnded { _ in
                                inputController.releaseTouchCast()
                            }
                    )
            }
            .foregroundStyle(.white)

            ZStack {
                Circle()
                    .fill(.ultraThinMaterial.opacity(0.55))
                    .background(Circle().fill(Color.black.opacity(0.35)))
                    .frame(width: 96, height: 96)
                    .overlay(Circle().stroke(Color.cyan.opacity(0.38), lineWidth: 1.5))

                Rectangle()
                    .fill(Color.white.opacity(0.75))
                    .frame(width: 34, height: 3)
                    .offset(x: 17)
                    .rotationEffect(.radians(crankAngleRad))

                Circle()
                    .fill(Color.cyan)
                    .frame(width: 18, height: 18)
                    .shadow(color: .cyan.opacity(0.6), radius: 4)
                    .offset(x: 34)
                    .rotationEffect(.radians(crankAngleRad))

                VStack(spacing: 1) {
                    Text("收线")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.8))
                    Text(String(format: "%.1f", inputController.currentRetrieveSpeedMetersPerSec))
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .foregroundStyle(.cyan)
                }
            }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        let center = CGPoint(x: 48, y: 48)
                        let dx = Double(value.location.x - center.x)
                        let dy = Double(value.location.y - center.y)
                        let angle = atan2(dy, dx)
                        if let prev = lastCrankAngleRad {
                            var diff = angle - prev
                            if diff > .pi { diff -= 2.0 * .pi }
                            if diff < -.pi { diff += 2.0 * .pi }
                            let speedNorm = Float(min(1.0, abs(diff) * 3.8))
                            inputController.reelThrottle = max(0.22, speedNorm)
                        } else {
                            inputController.reelThrottle = 0.45
                        }
                        lastCrankAngleRad = angle
                        crankAngleRad = angle
                    }
                    .onEnded { _ in
                        lastCrankAngleRad = nil
                        inputController.reelThrottle = 0.0
                    }
            )
        }
    }

    private func hookedFishBanner(species: FishSpecies, fishState: FishAIState) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text("中鱼！\(species.chineseName) · \(fishState.chineseName)")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(.white)
                ProgressView(value: Double(max(0.0, min(1.0, hookedFishStamina))))
                    .tint(hookedFishStamina < 0.15 ? .green : .orange)
                    .frame(width: 145)
            }

            if fishState == .exhausted || hookedFishStamina <= 0.12 {
                Button(action: onLandFish) {
                    Label("抄网入护", systemImage: "checkmark.seal.fill")
                        .font(.system(size: 11, weight: .bold))
                        .padding(.horizontal, 11)
                        .padding(.vertical, 6)
                        .background(Color.green.opacity(0.75))
                        .foregroundStyle(.white)
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.black.opacity(0.55))
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.orange.opacity(0.65), lineWidth: 1))
    }

    private var quickEnvironmentPanel: some View {
        VStack(spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: "sun.horizon.fill").foregroundStyle(.yellow).font(.system(size: 11))
                Slider(value: $simState.timeOfDayHours, in: 0.0...23.95, step: 0.05).tint(.cyan)
                Button(action: onToggleTestFight) {
                    Text(inputController.simulatedFishFightActive ? "停测" : "试鱼")
                        .font(.system(size: 10, weight: .bold))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.orange.opacity(0.5))
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }

            HStack(spacing: 5) {
                ForEach(CameraMode.allCases) { mode in
                    Button {
                        simState.cameraMode = mode
                    } label: {
                        Text(mode.displayName)
                            .font(.system(size: 9, weight: .semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 5)
                            .background(simState.cameraMode == mode ? Color.cyan.opacity(0.45) : Color.white.opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 7, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
            }

            HStack(spacing: 6) {
                ForEach(RodPower.allCases) { power in
                    Button {
                        inputController.rodPower = power
                    } label: {
                        Text(power.shortCode)
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(inputController.rodPower == power ? Color.orange.opacity(0.48) : Color.white.opacity(0.10))
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
                Spacer()
                ForEach(LureType.allCases) { lure in
                    Button {
                        inputController.activeLure = lure
                    } label: {
                        Text(lure.chineseName)
                            .font(.system(size: 10, weight: .medium))
                            .padding(.horizontal, 7)
                            .padding(.vertical, 4)
                            .background(inputController.activeLure == lure ? Color.teal.opacity(0.48) : Color.white.opacity(0.10))
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .foregroundStyle(.white)
        .padding(10)
        .frame(maxWidth: 360)
        .background(.ultraThinMaterial.opacity(0.84))
        .background(Color.black.opacity(0.35))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .stroke(Color.white.opacity(0.15), lineWidth: 0.8)
        )
    }

    private var thermalIndicatorColor: Color {
        switch governor.qualityProfile.thermalState {
        case .nominal: return .green
        case .fair: return .yellow
        case .serious: return .orange
        case .critical: return .red
        @unknown default: return .green
        }
    }

    private var pressureArrow: String {
        switch ecosystem.barometricTrend {
        case .rising: return "↗"
        case .steady: return "→"
        case .falling: return "↘"
        case .stormFront: return "⇊"
        }
    }

    private func tensionColor(_ ratio: CGFloat) -> Color {
        if ratio > 0.80 { return .red }
        if ratio > 0.55 { return .orange }
        return .cyan
    }
}

private struct LeftArcShape: InsettableShape {
    var startDeg: Double
    var endDeg: Double
    var insetAmount: CGFloat = 0

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.maxX + 18, y: rect.midY)
        let radius = max(10, min(rect.width, rect.height) * 0.55 - insetAmount)
        path.addArc(
            center: center,
            radius: radius,
            startAngle: .degrees(startDeg),
            endAngle: .degrees(endDeg),
            clockwise: false
        )
        return path
    }

    func inset(by amount: CGFloat) -> some InsettableShape {
        var copy = self
        copy.insetAmount += amount
        return copy
    }
}
