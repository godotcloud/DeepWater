import SwiftUI
import MetalKit
import simd

public struct CatchRecord: Codable, Identifiable, Sendable {
    public let id: UUID
    public let speciesRawValue: Int
    public let lengthCm: Float
    public let weightKg: Float
    public let captureDepthMeters: Float
    public let lureTypeRawValue: Int
    public let waterTempC: Float
    public let barometricPressureHPa: Float
    public let barometricTrendRawValue: Int
    public let timeOfDayHours: Float
    public let capturedAt: Date

    public var species: FishSpecies {
        FishSpecies(rawValue: speciesRawValue) ?? .largemouthBass
    }

    public var lureType: LureType {
        LureType(rawValue: lureTypeRawValue) ?? .minnowHardbait
    }

    public var barometricTrend: BarometricTrend {
        BarometricTrend(rawValue: barometricTrendRawValue) ?? .steady
    }
}

@MainActor
public final class CatchLogStore: ObservableObject {
    @Published public private(set) var records: [CatchRecord] = []
    private let storageKey = "com.deepwatersim.catchlog.v1"

    public init() {
        load()
    }

    public func addCatch(
        species: FishSpecies,
        lengthCm: Float,
        weightKg: Float,
        captureDepthMeters: Float,
        lureType: LureType,
        waterTempC: Float,
        barometricPressureHPa: Float,
        barometricTrend: BarometricTrend,
        timeOfDayHours: Float
    ) -> CatchRecord {
        let rec = CatchRecord(
            id: UUID(),
            speciesRawValue: species.rawValue,
            lengthCm: lengthCm,
            weightKg: weightKg,
            captureDepthMeters: captureDepthMeters,
            lureTypeRawValue: lureType.rawValue,
            waterTempC: waterTempC,
            barometricPressureHPa: barometricPressureHPa,
            barometricTrendRawValue: barometricTrend.rawValue,
            timeOfDayHours: timeOfDayHours,
            capturedAt: Date()
        )
        records.insert(rec, at: 0)
        save()
        return rec
    }

    public func deleteRecord(id: UUID) {
        records.removeAll { $0.id == id }
        save()
    }

    public var personalBestWeightKg: Float {
        records.map(\.weightKg).max() ?? 0.0
    }

    public var uniqueSpeciesCount: Int {
        Set(records.map(\.speciesRawValue)).count
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([CatchRecord].self, from: data) else {
            return
        }
        records = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(records) else { return }
        UserDefaults.standard.set(data, forKey: storageKey)
    }
}

@MainActor
private final class FishInspectorRenderer: NSObject, MTKViewDelegate {
    private let device: MTLDevice
    private let commandQueue: MTLCommandQueue
    private var pipelineState: MTLRenderPipelineState?
    private var depthState: MTLDepthStencilState?
    private var fishMesh: FishMesh?
    private var fishTextureSet: PBRTextureSet?
    private var currentSpecies: FishSpecies = .largemouthBass

    public var orbitYaw: Float = 0.65
    public var orbitPitch: Float = 0.14
    public var cameraDistance: Float = 0.72
    private var elapsedTime: Float = 0.0

    init?(mtkView: MTKView, species: FishSpecies) {
        guard let dev = mtkView.device ?? MTLCreateSystemDefaultDevice(),
              let queue = dev.makeCommandQueue() else {
            return nil
        }
        self.device = dev
        self.commandQueue = queue
        self.currentSpecies = species
        super.init()

        mtkView.device = dev
        mtkView.colorPixelFormat = .bgra8Unorm_srgb
        mtkView.depthStencilPixelFormat = .depth32Float
        mtkView.clearColor = MTLClearColor(red: 0.015, green: 0.045, blue: 0.075, alpha: 1.0)
        mtkView.preferredFramesPerSecond = 60

        buildPipeline(colorFormat: mtkView.colorPixelFormat)
        fishMesh = FishMeshGenerator.generate(device: dev, species: species)

        Task { [weak self] in
            guard let self else { return }
            if let atlas = try? await ProceduralTextureBaker.bakeAllAsync(device: self.device, commandQueue: self.commandQueue) {
                self.fishTextureSet = atlas.fishBase
            }
        }
    }

    func setSpecies(_ species: FishSpecies) {
        guard species != currentSpecies else { return }
        currentSpecies = species
        fishMesh = FishMeshGenerator.generate(device: device, species: species)
    }

    private func buildPipeline(colorFormat: MTLPixelFormat) {
        guard let library = device.makeDefaultLibrary(),
              let vFunc = library.makeFunction(name: "fishVertexShader"),
              let fFunc = library.makeFunction(name: "fishFragmentShader") else {
            return
        }

        let desc = MTLRenderPipelineDescriptor()
        desc.label = "FishInspectorPBRPipeline"
        desc.vertexFunction = vFunc
        desc.fragmentFunction = fFunc
        desc.colorAttachments[0].pixelFormat = colorFormat
        desc.colorAttachments[0].isBlendingEnabled = true
        desc.colorAttachments[0].sourceRGBBlendFactor = .sourceAlpha
        desc.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha
        desc.colorAttachments[0].sourceAlphaBlendFactor = .one
        desc.colorAttachments[0].destinationAlphaBlendFactor = .oneMinusSourceAlpha
        desc.depthAttachmentPixelFormat = .depth32Float
        pipelineState = try? device.makeRenderPipelineState(descriptor: desc)

        let dsDesc = MTLDepthStencilDescriptor()
        dsDesc.depthCompareFunction = .less
        dsDesc.isDepthWriteEnabled = true
        depthState = device.makeDepthStencilState(descriptor: dsDesc)
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}

    func draw(in view: MTKView) {
        elapsedTime += 1.0 / 60.0
        guard let pso = pipelineState,
              let ds = depthState,
              let mesh = fishMesh,
              let tex = fishTextureSet,
              let iridTex = tex.iridescence,
              let rpd = view.currentRenderPassDescriptor,
              let drawable = view.currentDrawable,
              let cb = commandQueue.makeCommandBuffer(),
              let enc = cb.makeRenderCommandEncoder(descriptor: rpd) else {
            return
        }

        let aspect = max(0.3, Float(view.drawableSize.width / max(1.0, view.drawableSize.height)))
        let eye = SIMD3<Float>(
            sin(orbitYaw) * cos(orbitPitch) * cameraDistance,
            sin(orbitPitch) * cameraDistance,
            cos(orbitYaw) * cos(orbitPitch) * cameraDistance
        )
        let viewMat = Self.lookAt(eye: eye, target: .zero, up: SIMD3<Float>(0, 1, 0))
        let projMat = Self.perspective(fovY: 42.0 * .pi / 180.0, aspect: aspect, nearZ: 0.05, farZ: 20.0)
        let vp = projMat * viewMat

        let camParams = CameraParams(
            viewMatrix: viewMat,
            projectionMatrix: projMat,
            viewProjectionMatrix: vp,
            invViewProjectionMatrix: simd_inverse(vp),
            positionAndFov: SIMD4<Float>(eye.x, eye.y, eye.z, 42.0 * .pi / 180.0),
            forwardAndNear: SIMD4<Float>(simd_normalize(-eye), 0.05),
            rightAndFar: SIMD4<Float>(1, 0, 0, 20.0),
            upAndUnderwater: SIMD4<Float>(0, 1, 0, 0.0)
        )

        let sunDir = simd_normalize(SIMD3<Float>(0.55, 0.65, 0.52))
        let atmo = AtmosphereParams(
            sunDirectionAndElevation: SIMD4<Float>(sunDir.x, sunDir.y, sunDir.z, 0.8),
            sunColorAndIntensity: SIMD4<Float>(1.0, 0.97, 0.92, 5.2),
            skyZenithColorAndTime: SIMD4<Float>(0.15, 0.36, 0.62, 11.0),
            skyHorizonColorAndFog: SIMD4<Float>(0.45, 0.68, 0.84, 0.0),
            rayleighCoeffAndScale: SIMD4<Float>(0.0058, 0.0135, 0.0331, 1.0),
            mieCoeffAndG: SIMD4<Float>(0.004, 0.004, 0.004, 0.76),
            ambientColorAndExposure: SIMD4<Float>(0.36, 0.44, 0.52, 1.0)
        )

        let zeroWave = SIMD4<Float>(1, 0, 0, 10)
        let water = WaterParams(
            gerstnerWaves: (zeroWave, zeroWave, zeroWave, zeroWave, zeroWave, zeroWave, zeroWave, zeroWave),
            absorptionAndClarity: SIMD4<Float>(0.25, 0.08, 0.04, 1.0),
            deepColorAndSurfaceY: SIMD4<Float>(0.02, 0.08, 0.14, 10.0),
            shallowColorAndFoam: SIMD4<Float>(0.10, 0.30, 0.34, 0.2),
            causticParams: SIMD4<Float>(0.6, 0.4, 0.5, 0.75),
            godRayParams: SIMD4<Float>(0.0, 0.1, 1.0, 0.2),
            gridParams: SIMD4<Float>(60, 60, elapsedTime, 1.0 / 60.0)
        )

        var uniforms = Uniforms(
            camera: camParams,
            atmosphere: atmo,
            water: water,
            viewportAndTime: SIMD4<Float>(Float(view.drawableSize.width), Float(view.drawableSize.height), elapsedTime, 0)
        )

        let g = mesh.genome
        var instance = FishInstanceData(
            modelMatrix: matrix_identity_float4x4,
            swimParams: SIMD4<Float>(elapsedTime * 3.2, 3.2, 0.045, g.bodyLength),
            dorsalColorAndSpecies: SIMD4<Float>(g.dorsalColor.x, g.dorsalColor.y, g.dorsalColor.z, Float(g.species.rawValue)),
            ventralColorAndIridescence: SIMD4<Float>(g.ventralColor.x, g.ventralColor.y, g.ventralColor.z, g.iridescenceStrength),
            biomechParams: SIMD4<Float>(0.5, 0.0, elapsedTime * 2.5, 0.0),
            breachAndShakeParams: SIMD4<Float>(0.0, 0.0, 0.0, 0.0)
        )

        enc.setRenderPipelineState(pso)
        enc.setDepthStencilState(ds)
        enc.setCullMode(.none)
        enc.setVertexBuffer(mesh.vertexBuffer, offset: 0, index: Int(BufferIndex.vertices.rawValue))
        enc.setVertexBytes(&uniforms, length: MemoryLayout<Uniforms>.stride, index: Int(BufferIndex.uniforms.rawValue))
        enc.setVertexBytes(&instance, length: MemoryLayout<FishInstanceData>.stride, index: Int(BufferIndex.fishInstances.rawValue))
        enc.setFragmentBytes(&uniforms, length: MemoryLayout<Uniforms>.stride, index: Int(BufferIndex.uniforms.rawValue))
        enc.setFragmentTexture(tex.albedo, index: Int(TextureIndex.albedo.rawValue))
        enc.setFragmentTexture(tex.normal, index: Int(TextureIndex.normal.rawValue))
        enc.setFragmentTexture(tex.roughnessMeta, index: Int(TextureIndex.roughnessMeta.rawValue))
        enc.setFragmentTexture(iridTex, index: Int(TextureIndex.iridescence.rawValue))

        enc.drawIndexedPrimitives(
            type: .triangle,
            indexCount: mesh.indexCount,
            indexType: .uint32,
            indexBuffer: mesh.indexBuffer,
            indexBufferOffset: 0,
            instanceCount: 1
        )
        enc.endEncoding()
        cb.present(drawable)
        cb.commit()
    }

    private static func lookAt(eye: SIMD3<Float>, target: SIMD3<Float>, up: SIMD3<Float>) -> simd_float4x4 {
        let z = simd_normalize(eye - target)
        let x = simd_normalize(simd_cross(up, z))
        let y = simd_cross(z, x)
        return simd_float4x4(columns: (
            SIMD4<Float>(x.x, y.x, z.x, 0),
            SIMD4<Float>(x.y, y.y, z.y, 0),
            SIMD4<Float>(x.z, y.z, z.z, 0),
            SIMD4<Float>(-simd_dot(x, eye), -simd_dot(y, eye), -simd_dot(z, eye), 1)
        ))
    }

    private static func perspective(fovY: Float, aspect: Float, nearZ: Float, farZ: Float) -> simd_float4x4 {
        let ys = 1.0 / tan(fovY * 0.5)
        let xs = ys / aspect
        let zr = farZ - nearZ
        return simd_float4x4(columns: (
            SIMD4<Float>(xs, 0, 0, 0),
            SIMD4<Float>(0, ys, 0, 0),
            SIMD4<Float>(0, 0, -farZ / zr, -1),
            SIMD4<Float>(0, 0, -(farZ * nearZ) / zr, 0)
        ))
    }
}

private struct FishInspector3DView: UIViewRepresentable {
    let species: FishSpecies

    final class Coordinator: NSObject {
        var renderer: FishInspectorRenderer?
        private var lastPan: CGPoint = .zero

        @MainActor
        @objc func handlePan(_ gesture: UIPanGestureRecognizer) {
            let pt = gesture.location(in: gesture.view)
            switch gesture.state {
            case .began:
                lastPan = pt
            case .changed:
                let dx = Float(pt.x - lastPan.x)
                let dy = Float(pt.y - lastPan.y)
                lastPan = pt
                renderer?.orbitYaw -= dx * 0.012
                renderer?.orbitPitch = max(-1.0, min(1.0, (renderer?.orbitPitch ?? 0.0) + dy * 0.010))
            default:
                break
            }
        }

        @MainActor
        @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
            if gesture.state == .changed, let r = renderer {
                r.cameraDistance = max(0.32, min(1.35, r.cameraDistance / Float(gesture.scale)))
                gesture.scale = 1.0
            }
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView()
        view.isMultipleTouchEnabled = true
        if let r = FishInspectorRenderer(mtkView: view, species: species) {
            context.coordinator.renderer = r
            view.delegate = r
        }
        let pan = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePan(_:)))
        pan.minimumNumberOfTouches = 1
        pan.maximumNumberOfTouches = 2
        let pinch = UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePinch(_:)))
        view.addGestureRecognizer(pan)
        view.addGestureRecognizer(pinch)
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {
        context.coordinator.renderer?.setSpecies(species)
    }
}

public struct CatchLogView: View {
    @ObservedObject public var store: CatchLogStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedRecordID: UUID?
    @State private var previewSpecies: FishSpecies = .largemouthBass

    public init(store: CatchLogStore, initialRecord: CatchRecord? = nil) {
        self.store = store
        self._selectedRecordID = State(initialValue: initialRecord?.id ?? store.records.first?.id)
        self._previewSpecies = State(initialValue: initialRecord?.species ?? store.records.first?.species ?? .largemouthBass)
    }

    private var activeRecord: CatchRecord? {
        if let id = selectedRecordID, let found = store.records.first(where: { $0.id == id }) {
            return found
        }
        return store.records.first
    }

    public var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                ZStack(alignment: .bottomLeading) {
                    FishInspector3DView(species: activeRecord?.species ?? previewSpecies)
                        .frame(height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .stroke(Color.cyan.opacity(0.35), lineWidth: 1)
                        )

                    HStack {
                        Label("单/双指旋转缩放检视鱼鳞与虹彩", systemImage: "rotate.3d")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(.white.opacity(0.88))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(Color.black.opacity(0.45))
                            .clipShape(Capsule())
                        Spacer()
                        Text((activeRecord?.species ?? previewSpecies).chineseName)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.cyan)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(Color.black.opacity(0.55))
                            .clipShape(Capsule())
                    }
                    .padding(10)
                }

                if let rec = activeRecord {
                    HStack(spacing: 10) {
                        statTile(title: "体长", value: String(format: "%.1f cm", rec.lengthCm))
                        statTile(title: "体重", value: String(format: "%.2f kg", rec.weightKg))
                        statTile(title: "水深", value: String(format: "%.1f m", rec.captureDepthMeters))
                        statTile(title: "水温", value: String(format: "%.1f°C", rec.waterTempC))
                    }
                    HStack {
                        Text("拟饵：\(rec.lureType.chineseName)")
                        Spacer()
                        Text(String(format: "气压 %.0f hPa (%@)", rec.barometricPressureHPa, rec.barometricTrend.displayName))
                    }
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.82))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Color.white.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                } else {
                    HStack(spacing: 6) {
                        ForEach(FishSpecies.allCases) { sp in
                            Button {
                                previewSpecies = sp
                            } label: {
                                Text(sp.chineseName)
                                    .font(.system(size: 11, weight: .semibold))
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 6)
                                    .background(previewSpecies == sp ? Color.cyan.opacity(0.42) : Color.white.opacity(0.10))
                                    .foregroundStyle(.white)
                                    .clipShape(Capsule())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                List {
                    Section {
                        if store.records.isEmpty {
                            Text("暂无渔获记录，抛投并溜鱼力竭后点击「抄网入护」即可永久珍藏。")
                                .font(.system(size: 13))
                                .foregroundStyle(.secondary)
                        } else {
                            ForEach(store.records) { rec in
                                Button {
                                    selectedRecordID = rec.id
                                    previewSpecies = rec.species
                                } label: {
                                    HStack {
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(rec.species.chineseName)
                                                .font(.system(size: 14, weight: .bold))
                                                .foregroundStyle(.white)
                                            Text("\(rec.lureType.chineseName) · 水深 \(String(format: "%.1fm", rec.captureDepthMeters)) · \(String(format: "%.1f°C", rec.waterTempC))")
                                                .font(.system(size: 11))
                                                .foregroundStyle(.secondary)
                                        }
                                        Spacer()
                                        VStack(alignment: .trailing, spacing: 3) {
                                            Text(String(format: "%.2f kg", rec.weightKg))
                                                .font(.system(size: 14, weight: .semibold, design: .monospaced))
                                                .foregroundStyle(.cyan)
                                            Text(String(format: "%.1f cm", rec.lengthCm))
                                                .font(.system(size: 11, design: .monospaced))
                                                .foregroundStyle(.secondary)
                                        }
                                    }
                                    .padding(.vertical, 2)
                                }
                                .listRowBackground(selectedRecordID == rec.id ? Color.cyan.opacity(0.18) : Color.white.opacity(0.04))
                            }
                            .onDelete { offsets in
                                for idx in offsets {
                                    store.deleteRecord(id: store.records[idx].id)
                                }
                            }
                        }
                    } header: {
                        Text("历史渔获（已收集 \(store.uniqueSpeciesCount)/\(FishSpecies.allCases.count) 鱼种 · PB \(String(format: "%.2f kg", store.personalBestWeightKg))）")
                    }
                }
                .listStyle(.insetGrouped)
                .scrollContentBackground(.hidden)
            }
            .padding(.horizontal, 14)
            .background(Color(red: 0.03, green: 0.06, blue: 0.10).ignoresSafeArea())
            .navigationTitle("3D 渔获图鉴")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") { dismiss() }
                        .foregroundStyle(.cyan)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private func statTile(title: String, value: String) -> some View {
        VStack(spacing: 3) {
            Text(title)
                .font(.system(size: 10))
                .foregroundStyle(.secondary)
            Text(value)
                .font(.system(size: 13, weight: .bold, design: .monospaced))
                .foregroundStyle(.white)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(Color.white.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}
