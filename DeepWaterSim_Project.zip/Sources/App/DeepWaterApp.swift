import SwiftUI

@main
public struct DeepWaterApp: App {
    @StateObject private var simulationState = SimulationState()

    public init() {}

    public var body: some Scene {
        WindowGroup {
            ContentView(state: simulationState)
                .preferredColorScheme(.dark)
        }
    }
}
