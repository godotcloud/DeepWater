import SwiftUI
import MetalKit

@MainActor
private final class RendererBridge: ObservableObject {
    weak var renderer: MetalRenderer?
}

public struct ContentView: View {
    @ObservedObject public var state: SimulationState
    @StateObject private var inputController = CastAndInputController()
    @StateObject private var ecosystem = EcosystemEngine()
    @StateObject private var governor = PerformanceGovernor()
    @StateObject private var catchStore = CatchLogStore()
    @StateObject private var bridge = RendererBridge()

    @State private var showCatchLogSheet: Bool = false

    public init(state: SimulationState) {
        self.state = state
    }

    public var body: some View {
        ZStack {
            MetalViewport(
                state: state,
                inputController: inputController,
                ecosystem: ecosystem,
                governor: governor,
                catchStore: catchStore,
                bridge: bridge
            )
            .ignoresSafeArea()

            GameHUDView(
                simState: state,
                inputController: inputController,
                ecosystem: ecosystem,
                governor: governor,
                catchStore: catchStore,
                hookedFishSpecies: state.hookedFishSpecies,
                hookedFishState: state.hookedFishState,
                hookedFishStamina: state.hookedFishStamina,
                maxSpoolCapacityMeters: 110.0,
                onOpenCatchLog: {
                    state.latestLandedRecord = catchStore.records.first
                    showCatchLogSheet = true
                },
                onTwitch: {
                    bridge.renderer?.triggerTwitch()
                },
                onLandFish: {
                    bridge.renderer?.landHookedFish()
                },
                onResetBrokenLine: {
                    bridge.renderer?.resetBrokenLine()
                },
                onToggleTestFight: {
                    bridge.renderer?.toggleTestFight()
                }
            )
        }
        .statusBarHidden(true)
        .sheet(isPresented: $showCatchLogSheet) {
            CatchLogView(store: catchStore, initialRecord: state.latestLandedRecord)
        }
        .onChange(of: state.shouldOpenCatchLog) { _, shouldOpen in
            if shouldOpen {
                state.shouldOpenCatchLog = false
                showCatchLogSheet = true
            }
        }
        .onDisappear {
            bridge.renderer?.stopServices()
        }
    }
}

private struct MetalViewport: UIViewRepresentable {
    let state: SimulationState
    let inputController: CastAndInputController
    let ecosystem: EcosystemEngine
    let governor: PerformanceGovernor
    let catchStore: CatchLogStore
    let bridge: RendererBridge

    final class Coordinator: NSObject {
        var renderer: MetalRenderer?
        private var lastPanLocation: CGPoint = .zero

        @MainActor
        @objc func handlePan(_ gesture: UIPanGestureRecognizer) {
            let location = gesture.location(in: gesture.view)
            switch gesture.state {
            case .began:
                lastPanLocation = location
            case .changed:
                let dx = Float(location.x - lastPanLocation.x)
                let dy = Float(location.y - lastPanLocation.y)
                lastPanLocation = location
                renderer?.cameraController.applyLookDelta(dx: dx, dy: dy)
            default:
                break
            }
        }

        @MainActor
        @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
            if gesture.state == .changed {
                renderer?.cameraController.applyZoomDelta(scale: Float(gesture.scale))
                gesture.scale = 1.0
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> MTKView {
        let mtkView = MTKView()
        mtkView.isMultipleTouchEnabled = true
        if let renderer = MetalRenderer(
            mtkView: mtkView,
            state: state,
            inputController: inputController,
            ecosystem: ecosystem,
            governor: governor,
            catchStore: catchStore
        ) {
            context.coordinator.renderer = renderer
            bridge.renderer = renderer
            mtkView.delegate = renderer
            renderer.startServices()
        }

        let pan = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePan(_:)))
        let pinch = UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePinch(_:)))
        mtkView.addGestureRecognizer(pan)
        mtkView.addGestureRecognizer(pinch)

        return mtkView
    }

    func updateUIView(_ uiView: MTKView, context: Context) {
        // Lightweight camera sync only; simulation loop runs directly inside MetalRenderer
        context.coordinator.renderer?.cameraController.setMode(state.cameraMode)
    }
}
