import SwiftUI
import MetalKit
import simd

public struct ContentView: View {
    @ObservedObject public var state: SimulationState
    @StateObject private var inputController = CastAndInputController()
    @StateObject private var ecosystem = EcosystemEngine()
    @StateObject private var governor = PerformanceGovernor()
    @StateObject private var catchStore = CatchLogStore()

    @State private var physicsRig = RodAndLinePhysics()
    @State private var audioHaptics = HapticAndAudioEngine()
    @State private var fishAI: FishAIManager? = nil

    @State private var hookedFishSpecies: FishSpecies? = nil
    @State private var hookedFishState: FishAIState? = nil
    @State private var hookedFishStamina: Float = 1.0
    @State private var showCatchLogSheet: Bool = false
    @State private var latestCatchRecord: CatchRecord? = nil
    @State private var liveLurePosition: SIMD3<Float> = SIMD3<Float>(0.0, -2.0, 6.0)
    @State private var liveLureVelocity: SIMD3<Float> = SIMD3<Float>(0.0, 0.0, 1.0)
    @State private var fightClock: Float = 0.0

    private let simTimer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()

    public init(state: SimulationState) {
        self.state = state
    }

    public var body: some View {
        ZStack {
            MetalViewport(
                state: state,
                lurePosition: liveLurePosition,
                lureVelocity: liveLureVelocity
            )
            .ignoresSafeArea()

            GameHUDView(
                simState: state,
                inputController: inputController,
                ecosystem: ecosystem,
                governor: governor,
                catchStore: catchStore,
                hookedFishSpecies: hookedFishSpecies,
                hookedFishState: hookedFishState,
                hookedFishStamina: hookedFishStamina,
                maxSpoolCapacityMeters: physicsRig.maxSpoolCapacity,
                onOpenCatchLog: {
                    latestCatchRecord = catchStore.records.first
                    showCatchLogSheet = true
                },
                onTwitch: {
                    physicsRig.triggerRodTwitch(strength: 1.0)
                    audioHaptics.playNibbleHaptic()
                },
                onLandFish: landHookedFish,
                onResetBrokenLine: {
                    physicsRig.resetRigToReadyPosition()
                    fishAI?.releaseHookedFish()
                    hookedFishSpecies = nil
                    hookedFishState = nil
                    inputController.isLineBroken = false
                    inputController.simulatedFishFightActive = false
                },
                onToggleTestFight: {
                    inputController.simulatedFishFightActive.toggle()
                    if inputController.simulatedFishFightActive {
                        hookedFishSpecies = .largemouthBass
                        hookedFishState = .fight
                        hookedFishStamina = 0.65
                        audioHaptics.playStrikeHaptic(intensity: 0.95)
                    } else {
                        hookedFishSpecies = nil
                        hookedFishState = nil
                    }
                }
            )
        }
        .statusBarHidden(true)
        .sheet(isPresented: $showCatchLogSheet) {
            CatchLogView(store: catchStore, initialRecord: latestCatchRecord)
        }
        .onAppear {
            if fishAI == nil {
                fishAI = FishAIManager(count: 40, ecosystem: ecosystem) { _, z in
                    return z > 16.0 ? -1.8 : -11.5
                }
            }
            configureRigCallbacks()
            audioHaptics.start()
            inputController.startMotionUpdates()
        }
        .onDisappear {
            inputController.stopMotionUpdates()
            audioHaptics.stop()
        }
        .onReceive(simTimer) { _ in
            stepCompleteFishingLoop(dt: 1.0 / 60.0)
        }
    }

    private func configureRigCallbacks() {
        inputController.onCastTriggered = { signal in
            physicsRig.launchCast(
                powerNormalized: signal.powerNormalized,
                aimYawOffset: signal.aimYawOffset,
                elevationRad: signal.elevationRad
            )
            audioHaptics.playCastWhooshSound(power: signal.powerNormalized)
            state.cameraMode = .castTracking
        }

        inputController.onTwitchTriggered = { strength in
            physicsRig.triggerRodTwitch(strength: strength)
        }
    }

    private func stepCompleteFishingLoop(dt: Float) {
        inputController.updateTouchCharge(deltaTime: dt)
        ecosystem.update(deltaTime: dt, timeOfDayHours: state.timeOfDayHours)

        physicsRig.dragSettingNormalized = inputController.dragSetting
        physicsRig.rodPower = inputController.rodPower
        physicsRig.activeLureType = inputController.activeLure

        var externalFishPull = SIMD3<Float>.zero
        var headShake: Float = 0.0

        let lureColor: SIMD3<Float>
        switch inputController.activeLure {
        case .minnowHardbait: lureColor = SIMD3<Float>(0.78, 0.84, 0.88)
        case .jigheadSoftWorm: lureColor = SIMD3<Float>(0.42, 0.65, 0.24)
        case .metalSpoon: lureColor = SIMD3<Float>(0.92, 0.94, 0.96)
        }

        if let ai = fishAI {
            let perception = LurePerceptionInput(
                position: physicsRig.lureState.position,
                velocity: physicsRig.lureState.velocity,
                lureType: inputController.activeLure,
                wobbleAmplitude: abs(physicsRig.lureState.wobbleAngleRad),
                lureColorRGB: lureColor,
                justSplashed: false,
                splashEnergy: 0.0,
                isSubmerged: physicsRig.lureState.isSubmerged,
                rodLineTensionN: inputController.currentLineTensionN
            )
            let (aiTick, _) = ai.step(
                deltaTime: dt,
                ecosystem: ecosystem,
                lure: perception,
                anglerPosition: physicsRig.rodButtWorldPosition
            ) { _, z in
                return z > 16.0 ? -1.8 : -11.5
            }

            if aiTick.nibbleTriggered {
                audioHaptics.playNibbleHaptic()
            }
            if aiTick.strikeTriggered {
                audioHaptics.playStrikeHaptic(intensity: 0.95)
            }
            if let species = aiTick.hookedFishSpecies {
                hookedFishSpecies = species
                hookedFishState = aiTick.hookedFishState
                hookedFishStamina = aiTick.hookedFishStamina
                headShake = aiTick.hookedHeadShake
                externalFishPull = aiTick.externalPullForce
            }
        }

        if inputController.simulatedFishFightActive && !physicsRig.isLineBroken {
            fightClock += dt
            let surge = 0.55 + 0.45 * sin(fightClock * 2.1)
            headShake = max(headShake, max(0.0, sin(fightClock * 13.5)) * 0.65)
            externalFishPull += SIMD3<Float>(
                sin(fightClock * 1.7) * 16.0,
                -6.0 - surge * 8.0,
                -(14.0 + surge * 22.0)
            )
            hookedFishStamina = max(0.05, hookedFishStamina - dt * 0.06)
            if hookedFishStamina <= 0.12 {
                hookedFishState = .exhausted
            }
        }

        let events = physicsRig.step(
            deltaTime: dt,
            reelSpeedMetersPerSec: inputController.currentRetrieveSpeedMetersPerSec,
            externalFishPullForce: externalFishPull
        ) { _, z in
            return z > 16.0 ? -1.8 : -11.5
        }

        if events.lureJustSplashed {
            audioHaptics.playLureSplashSound(impactSpeed: events.splashImpactSpeed)
        }
        if events.lineJustBroke {
            fishAI?.releaseHookedFish()
            hookedFishSpecies = nil
            hookedFishState = nil
            inputController.simulatedFishFightActive = false
        }

        audioHaptics.updateFightFeedback(
            deltaTime: dt,
            normalizedTension: events.normalizedTension,
            headShakeIntensity: headShake,
            dragClickRateHz: events.dragClickRateHz
        )

        inputController.currentLineTensionN = events.lineTensionNewtons
        inputController.normalizedTension = events.normalizedTension
        inputController.lineOutMeters = physicsRig.lineOutLength
        inputController.lureDepthMeters = physicsRig.lureState.depthBelowSurface
        inputController.isLineBroken = physicsRig.isLineBroken

        liveLurePosition = physicsRig.lureState.position
        liveLureVelocity = physicsRig.lureState.velocity
    }

    private func landHookedFish() {
        let species = hookedFishSpecies ?? .largemouthBass
        let genome = FishGenome.genome(for: species)
        let lengthCm = genome.bodyLength * 100.0 * Float.random(in: 0.90...1.28)
        let weightKg = max(0.35, pow(lengthCm / 36.0, 3.0) * 1.05)

        let record = catchStore.addCatch(
            species: species,
            lengthCm: lengthCm,
            weightKg: weightKg,
            captureDepthMeters: max(0.5, inputController.lureDepthMeters),
            lureType: inputController.activeLure,
            waterTempC: ecosystem.waterTemperature(depthMeters: inputController.lureDepthMeters),
            barometricPressureHPa: ecosystem.barometricPressureHPa,
            barometricTrend: ecosystem.barometricTrend,
            timeOfDayHours: state.timeOfDayHours
        )

        fishAI?.releaseHookedFish()
        hookedFishSpecies = nil
        hookedFishState = nil
        hookedFishStamina = 1.0
        inputController.simulatedFishFightActive = false
        physicsRig.resetRigToReadyPosition()

        latestCatchRecord = record
        showCatchLogSheet = true
    }
}

private struct MetalViewport: UIViewRepresentable {
    let state: SimulationState
    let lurePosition: SIMD3<Float>
    let lureVelocity: SIMD3<Float>

    final class Coordinator: NSObject {
        var renderer: MetalRenderer?
        private var lastPanLocation: CGPoint = .zero

        @MainActor
        @objc func handlePan(_ gesture: UIPanGestureRecognizer) {
            let location = gesture.location(in: gesture.view)
            switch gesture.state {
            case .began:
                lastPanLocation = location
            case .changed:
                let dx = Float(location.x - lastPanLocation.x)
                let dy = Float(location.y - lastPanLocation.y)
                lastPanLocation = location
                renderer?.cameraController.applyLookDelta(dx: dx, dy: dy)
            default:
                break
            }
        }

        @MainActor
        @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
            if gesture.state == .changed {
                renderer?.cameraController.applyZoomDelta(scale: Float(gesture.scale))
                gesture.scale = 1.0
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> MTKView {
        let mtkView = MTKView()
        mtkView.isMultipleTouchEnabled = true
        if let renderer = MetalRenderer(mtkView: mtkView, state: state) {
            context.coordinator.renderer = renderer
            mtkView.delegate = renderer
        }

        let pan = UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePan(_:)))
        let pinch = UIPinchGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePinch(_:)))
        mtkView.addGestureRecognizer(pan)
        mtkView.addGestureRecognizer(pinch)

        return mtkView
    }

    func updateUIView(_ uiView: MTKView, context: Context) {
        context.coordinator.renderer?.cameraController.setMode(state.cameraMode)
        context.coordinator.renderer?.cameraController.updateLureTracking(
            position: lurePosition,
            velocity: lureVelocity
        )
    }
}
