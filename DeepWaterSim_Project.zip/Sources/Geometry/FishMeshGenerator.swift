import Foundation
import Metal
import simd

public enum FishSpecies: Int, CaseIterable, Sendable, Identifiable {
    case largemouthBass = 0   // 大口黑鲈
    case rainbowTrout = 1     // 虹鳟
    case redSnapper = 2       // 红鲷
    case topmouthCulter = 3   // 翘嘴鲌
    case grouper = 4          // 石斑鱼
    case goldenKoi = 5        // 黄金锦鲤
    case mahiMahi = 6         // 鲯鳅（鬼头刀）
    case northernPike = 7     // 白斑狗鱼

    public var id: Int { rawValue }

    public var chineseName: String {
        switch self {
        case .largemouthBass: return "大口黑鲈"
        case .rainbowTrout: return "虹鳟"
        case .redSnapper: return "红鲷"
        case .topmouthCulter: return "翘嘴鲌"
        case .grouper: return "石斑鱼"
        case .goldenKoi: return "黄金锦鲤"
        case .mahiMahi: return "鲯鳅"
        case .northernPike: return "白斑狗鱼"
        }
    }
}

public struct FishGenome: Sendable {
    public let species: FishSpecies
    public let bodyLength: Float
    public let dorsalProfile: [Float]
    public let ventralProfile: [Float]
    public let halfWidthProfile: [Float]
    public let jawUpturn: Float
    public let dorsalFinRange: ClosedRange<Float>
    public let dorsalFinHeight: Float
    public let pectoralFinLength: Float
    public let pelvicFinLength: Float
    public let analFinRange: ClosedRange<Float>
    public let analFinHeight: Float
    public let caudalLength: Float
    public let caudalHalfSpan: Float
    public let caudalForkDepth: Float
    public let eyeRadius: Float
    public let eyeSpineT: Float
    public let eyeVerticalRatio: Float
    public let dorsalColor: SIMD3<Float>
    public let ventralColor: SIMD3<Float>
    public let iridescenceStrength: Float

    public static func genome(for species: FishSpecies) -> FishGenome {
        switch species {
        case .largemouthBass:
            return FishGenome(
                species: .largemouthBass,
                bodyLength: 0.48,
                dorsalProfile:    [0.016, 0.118, 0.172, 0.148, 0.070, 0.048],
                ventralProfile:   [0.026, 0.108, 0.155, 0.128, 0.064, 0.046],
                halfWidthProfile: [0.022, 0.074, 0.098, 0.078, 0.036, 0.018],
                jawUpturn: 0.014,
                dorsalFinRange: 0.28...0.77,
                dorsalFinHeight: 0.088,
                pectoralFinLength: 0.120,
                pelvicFinLength: 0.080,
                analFinRange: 0.62...0.80,
                analFinHeight: 0.065,
                caudalLength: 0.160,
                caudalHalfSpan: 0.132,
                caudalForkDepth: 0.22,
                eyeRadius: 0.016,
                eyeSpineT: 0.115,
                eyeVerticalRatio: 0.28,
                dorsalColor: SIMD3<Float>(0.13, 0.26, 0.12),
                ventralColor: SIMD3<Float>(0.86, 0.88, 0.80),
                iridescenceStrength: 0.58
            )

        case .rainbowTrout:
            return FishGenome(
                species: .rainbowTrout,
                bodyLength: 0.52,
                dorsalProfile:    [0.010, 0.086, 0.122, 0.112, 0.056, 0.042],
                ventralProfile:   [0.012, 0.078, 0.115, 0.104, 0.052, 0.040],
                halfWidthProfile: [0.016, 0.058, 0.074, 0.064, 0.030, 0.016],
                jawUpturn: 0.004,
                dorsalFinRange: 0.39...0.59,
                dorsalFinHeight: 0.078,
                pectoralFinLength: 0.108,
                pelvicFinLength: 0.068,
                analFinRange: 0.68...0.82,
                analFinHeight: 0.056,
                caudalLength: 0.155,
                caudalHalfSpan: 0.122,
                caudalForkDepth: 0.16,
                eyeRadius: 0.014,
                eyeSpineT: 0.105,
                eyeVerticalRatio: 0.24,
                dorsalColor: SIMD3<Float>(0.14, 0.29, 0.27),
                ventralColor: SIMD3<Float>(0.90, 0.87, 0.90),
                iridescenceStrength: 0.96
            )

        case .redSnapper:
            return FishGenome(
                species: .redSnapper,
                bodyLength: 0.46,
                dorsalProfile:    [0.014, 0.175, 0.245, 0.185, 0.074, 0.046],
                ventralProfile:   [0.024, 0.125, 0.182, 0.146, 0.064, 0.044],
                halfWidthProfile: [0.016, 0.052, 0.064, 0.052, 0.024, 0.014],
                jawUpturn: -0.010,
                dorsalFinRange: 0.24...0.79,
                dorsalFinHeight: 0.105,
                pectoralFinLength: 0.155,
                pelvicFinLength: 0.095,
                analFinRange: 0.56...0.80,
                analFinHeight: 0.082,
                caudalLength: 0.182,
                caudalHalfSpan: 0.162,
                caudalForkDepth: 0.44,
                eyeRadius: 0.019,
                eyeSpineT: 0.125,
                eyeVerticalRatio: 0.30,
                dorsalColor: SIMD3<Float>(0.78, 0.15, 0.14),
                ventralColor: SIMD3<Float>(0.98, 0.76, 0.72),
                iridescenceStrength: 0.80
            )

        case .topmouthCulter:
            return FishGenome(
                species: .topmouthCulter,
                bodyLength: 0.58,
                dorsalProfile:    [0.008, 0.064, 0.096, 0.086, 0.044, 0.030],
                ventralProfile:   [0.014, 0.076, 0.112, 0.090, 0.042, 0.028],
                halfWidthProfile: [0.011, 0.038, 0.048, 0.038, 0.018, 0.010],
                jawUpturn: 0.032,
                dorsalFinRange: 0.45...0.60,
                dorsalFinHeight: 0.096,
                pectoralFinLength: 0.130,
                pelvicFinLength: 0.075,
                analFinRange: 0.58...0.85,
                analFinHeight: 0.068,
                caudalLength: 0.205,
                caudalHalfSpan: 0.165,
                caudalForkDepth: 0.58,
                eyeRadius: 0.015,
                eyeSpineT: 0.095,
                eyeVerticalRatio: 0.25,
                dorsalColor: SIMD3<Float>(0.22, 0.32, 0.42),
                ventralColor: SIMD3<Float>(0.95, 0.97, 0.99),
                iridescenceStrength: 1.00
            )

        case .grouper:
            return FishGenome(
                species: .grouper,
                bodyLength: 0.54,
                dorsalProfile:    [0.026, 0.155, 0.208, 0.180, 0.098, 0.072],
                ventralProfile:   [0.034, 0.144, 0.184, 0.154, 0.088, 0.066],
                halfWidthProfile: [0.032, 0.098, 0.124, 0.102, 0.056, 0.028],
                jawUpturn: 0.012,
                dorsalFinRange: 0.26...0.84,
                dorsalFinHeight: 0.094,
                pectoralFinLength: 0.145,
                pelvicFinLength: 0.090,
                analFinRange: 0.62...0.84,
                analFinHeight: 0.078,
                caudalLength: 0.152,
                caudalHalfSpan: 0.138,
                caudalForkDepth: 0.01,
                eyeRadius: 0.017,
                eyeSpineT: 0.120,
                eyeVerticalRatio: 0.34,
                dorsalColor: SIMD3<Float>(0.34, 0.21, 0.12),
                ventralColor: SIMD3<Float>(0.76, 0.64, 0.46),
                iridescenceStrength: 0.38
            )

        case .goldenKoi:
            // Plump ornamental carp with flowing elongated veil fins & bright gold-vermilion-white calico
            return FishGenome(
                species: .goldenKoi,
                bodyLength: 0.50,
                dorsalProfile:    [0.018, 0.128, 0.186, 0.158, 0.080, 0.054],
                ventralProfile:   [0.024, 0.122, 0.172, 0.142, 0.072, 0.050],
                halfWidthProfile: [0.024, 0.084, 0.114, 0.090, 0.044, 0.022],
                jawUpturn: -0.014,
                dorsalFinRange: 0.34...0.78,
                dorsalFinHeight: 0.118,
                pectoralFinLength: 0.175,
                pelvicFinLength: 0.115,
                analFinRange: 0.66...0.82,
                analFinHeight: 0.085,
                caudalLength: 0.220,
                caudalHalfSpan: 0.178,
                caudalForkDepth: 0.34,
                eyeRadius: 0.015,
                eyeSpineT: 0.110,
                eyeVerticalRatio: 0.22,
                dorsalColor: SIMD3<Float>(0.96, 0.42, 0.08),
                ventralColor: SIMD3<Float>(0.98, 0.96, 0.92),
                iridescenceStrength: 0.88
            )

        case .mahiMahi:
            // Iconic blunt vertical forehead, full-length golden-emerald crest dorsal fin, deeply forked crescent tail
            return FishGenome(
                species: .mahiMahi,
                bodyLength: 0.68,
                dorsalProfile:    [0.145, 0.195, 0.168, 0.120, 0.058, 0.032],
                ventralProfile:   [0.052, 0.105, 0.118, 0.088, 0.042, 0.026],
                halfWidthProfile: [0.022, 0.052, 0.058, 0.044, 0.020, 0.011],
                jawUpturn: 0.008,
                dorsalFinRange: 0.10...0.88,
                dorsalFinHeight: 0.112,
                pectoralFinLength: 0.145,
                pelvicFinLength: 0.110,
                analFinRange: 0.44...0.88,
                analFinHeight: 0.068,
                caudalLength: 0.225,
                caudalHalfSpan: 0.195,
                caudalForkDepth: 0.64,
                eyeRadius: 0.016,
                eyeSpineT: 0.090,
                eyeVerticalRatio: 0.18,
                dorsalColor: SIMD3<Float>(0.08, 0.62, 0.72),
                ventralColor: SIMD3<Float>(0.95, 0.82, 0.18),
                iridescenceStrength: 1.00
            )

        case .northernPike:
            // Ultra-elongated torpedo ambush predator with long duckbill snout & rear-set dorsal fin
            return FishGenome(
                species: .northernPike,
                bodyLength: 0.72,
                dorsalProfile:    [0.008, 0.042, 0.084, 0.086, 0.054, 0.032],
                ventralProfile:   [0.010, 0.040, 0.080, 0.082, 0.050, 0.030],
                halfWidthProfile: [0.014, 0.036, 0.054, 0.052, 0.028, 0.014],
                jawUpturn: 0.006,
                dorsalFinRange: 0.68...0.84,
                dorsalFinHeight: 0.072,
                pectoralFinLength: 0.095,
                pelvicFinLength: 0.075,
                analFinRange: 0.70...0.85,
                analFinHeight: 0.068,
                caudalLength: 0.150,
                caudalHalfSpan: 0.115,
                caudalForkDepth: 0.30,
                eyeRadius: 0.012,
                eyeSpineT: 0.145,
                eyeVerticalRatio: 0.36,
                dorsalColor: SIMD3<Float>(0.11, 0.24, 0.15),
                ventralColor: SIMD3<Float>(0.84, 0.86, 0.72),
                iridescenceStrength: 0.62
            )
        }
    }
}

public struct FishMesh: @unchecked Sendable {
    public let species: FishSpecies
    public let genome: FishGenome
    public let vertexBuffer: MTLBuffer
    public let indexBuffer: MTLBuffer
    public let vertexCount: Int
    public let indexCount: Int
    public var triangleCount: Int { indexCount / 3 }
}

public enum FishMeshGenerator {
    public static func generate(device: MTLDevice, species: FishSpecies) -> FishMesh? {
        let genome = FishGenome.genome(for: species)
        var vertices: [FishVertex] = []
        var indices: [UInt32] = []
        vertices.reserveCapacity(2600)
        indices.reserveCapacity(14000)

        appendBodyLoft(genome: genome, vertices: &vertices, indices: &indices)
        appendDorsalFin(genome: genome, vertices: &vertices, indices: &indices)
        appendAnalFin(genome: genome, vertices: &vertices, indices: &indices)
        appendPairedPectoralFins(genome: genome, vertices: &vertices, indices: &indices)
        appendPairedPelvicFins(genome: genome, vertices: &vertices, indices: &indices)
        appendCaudalFin(genome: genome, vertices: &vertices, indices: &indices)
        appendDualLayerEyes(genome: genome, vertices: &vertices, indices: &indices)

        guard let vb = device.makeBuffer(
            bytes: vertices,
            length: MemoryLayout<FishVertex>.stride * vertices.count,
            options: .storageModeShared
        ),
        let ib = device.makeBuffer(
            bytes: indices,
            length: MemoryLayout<UInt32>.stride * indices.count,
            options: .storageModeShared
        ) else {
            return nil
        }

        vb.label = "FishVB_\(species.rawValue)"
        ib.label = "FishIB_\(species.rawValue)"

        return FishMesh(
            species: species,
            genome: genome,
            vertexBuffer: vb,
            indexBuffer: ib,
            vertexCount: vertices.count,
            indexCount: indices.count
        )
    }

    private static let knotT: [Float] = [0.0, 0.14, 0.34, 0.58, 0.80, 1.0]

    private static func sampleSpline(_ values: [Float], t rawT: Float) -> Float {
        let t = max(0.0, min(1.0, rawT))
        var seg = 0
        for i in 0..<(knotT.count - 1) {
            if t >= knotT[i] && t <= knotT[i + 1] {
                seg = i
                break
            }
        }
        let t0 = knotT[seg]
        let t1 = knotT[seg + 1]
        let u = (t - t0) / max(t1 - t0, 0.0001)

        let p0 = values[max(0, seg - 1)]
        let p1 = values[seg]
        let p2 = values[min(values.count - 1, seg + 1)]
        let p3 = values[min(values.count - 1, seg + 2)]

        let u2 = u * u
        let u3 = u2 * u
        let res = 0.5 * (
            (2.0 * p1) +
            (-p0 + p2) * u +
            (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * u2 +
            (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * u3
        )
        return max(0.002, res)
    }

    private static func bodyCenterlineZ(spineT: Float, length: Float) -> Float {
        return (0.5 - spineT) * length
    }

    private static func bodySection(genome: FishGenome, spineT: Float) -> (topY: Float, botY: Float, halfW: Float, jawY: Float) {
        let L = genome.bodyLength
        let top = sampleSpline(genome.dorsalProfile, t: spineT) * L
        let bot = sampleSpline(genome.ventralProfile, t: spineT) * L
        let hw = sampleSpline(genome.halfWidthProfile, t: spineT) * L
        let jawLift = genome.jawUpturn * L * pow(max(0.0, 1.0 - spineT * 4.5), 2.0)
        return (top + jawLift, -bot + jawLift, hw, jawLift)
    }

    private static func appendBodyLoft(
        genome: FishGenome,
        vertices: inout [FishVertex],
        indices: inout [UInt32]
    ) {
        let rings = 48
        let slices = 32
        let baseVertex = UInt32(vertices.count)
        let L = genome.bodyLength

        var ringPositions = [[SIMD3<Float>]](repeating: [SIMD3<Float>](repeating: .zero, count: slices), count: rings)
        var ringSpineT = [Float](repeating: 0.0, count: rings)
        var ringPartID = [[Float]](repeating: [Float](repeating: 0.0, count: slices), count: rings)
        var ringAO = [[Float]](repeating: [Float](repeating: 1.0, count: slices), count: rings)

        for r in 0..<rings {
            let lin = Float(r) / Float(rings - 1)
            let cosT = 0.5 - 0.5 * cos(lin * Float.pi)
            let spineT = lin * 0.65 + cosT * 0.35
            ringSpineT[r] = spineT

            let z = bodyCenterlineZ(spineT: spineT, length: L)
            let sec = bodySection(genome: genome, spineT: spineT)
            let midY = 0.5 * (sec.topY + sec.botY)
            let halfH = max(0.002, 0.5 * (sec.topY - sec.botY))

            let snoutPinch: Float = (r == 0) ? (genome.species == .mahiMahi ? 0.35 : 0.05) : 1.0

            for s in 0..<slices {
                let phi = (Float(s) / Float(slices)) * 2.0 * Float.pi
                let sinP = sin(phi)
                let cosP = cos(phi)

                let shapePinch = 1.0 - 0.14 * max(0.0, cosP) - 0.10 * max(0.0, -cosP)
                var x = sinP * sec.halfW * shapePinch * snoutPinch
                let y = midY + cosP * halfH * snoutPinch

                let gillCurveT = 0.215 - 0.032 * abs(cosP)
                let gillDist = spineT - gillCurveT
                var partID: Float = 0.0
                var ao: Float = 1.0
                if abs(sinP) > 0.25 && abs(gillDist) < 0.032 {
                    let sideSign: Float = sinP >= 0.0 ? 1.0 : -1.0
                    let gillFlare = exp(-pow((gillDist + 0.010) / 0.014, 2.0)) * 0.0055 * L
                    let gillCleft = exp(-pow((gillDist - 0.008) / 0.005, 2.0)) * 0.0045 * L
                    x += sideSign * (gillFlare - gillCleft)
                    partID = 2.0
                    ao = 1.0 - exp(-pow((gillDist - 0.008) / 0.006, 2.0)) * 0.55
                }

                ringPositions[r][s] = SIMD3<Float>(x, y, z)
                ringPartID[r][s] = partID
                ringAO[r][s] = ao
            }
        }

        for r in 0..<rings {
            let spineT = ringSpineT[r]
            let rPrev = max(0, r - 1)
            let rNext = min(rings - 1, r + 1)

            for s in 0..<slices {
                let sPrev = (s - 1 + slices) % slices
                let sNext = (s + 1) % slices

                let pos = ringPositions[r][s]
                let dU = ringPositions[rNext][s] - ringPositions[rPrev][s]
                let dV = ringPositions[r][sNext] - ringPositions[r][sPrev]

                var normal = simd_cross(dV, dU)
                if simd_length_squared(normal) < 1e-10 {
                    normal = SIMD3<Float>(0.0, 1.0, 0.0)
                } else {
                    normal = simd_normalize(normal)
                }

                var tangent = dU
                if simd_length_squared(tangent) < 1e-10 {
                    tangent = SIMD3<Float>(0.0, 0.0, -1.0)
                } else {
                    tangent = simd_normalize(tangent)
                }

                let phi = (Float(s) / Float(slices)) * 2.0 * Float.pi
                let dorsalFactor = clamp01(cos(phi) * 0.5 + 0.5)
                let vCoord = dorsalFactor

                vertices.append(FishVertex(
                    position: SIMD4<Float>(pos.x, pos.y, pos.z, 1.0),
                    normal: SIMD4<Float>(normal.x, normal.y, normal.z, ringAO[r][s]),
                    tangent: SIMD4<Float>(tangent.x, tangent.y, tangent.z, 1.0),
                    uvAndWeights: SIMD4<Float>(spineT, vCoord, spineT * 0.85, 0.0),
                    anatomyMask: SIMD4<Float>(ringPartID[r][s], dorsalFactor, 0.0, 1.0)
                ))
            }
        }

        for r in 0..<(rings - 1) {
            for s in 0..<slices {
                let sNext = (s + 1) % slices
                let i0 = baseVertex + UInt32(r * slices + s)
                let i1 = baseVertex + UInt32(r * slices + sNext)
                let i2 = baseVertex + UInt32((r + 1) * slices + s)
                let i3 = baseVertex + UInt32((r + 1) * slices + sNext)

                indices.append(i0); indices.append(i2); indices.append(i1)
                indices.append(i1); indices.append(i2); indices.append(i3)
            }
        }
    }

    private static func appendDoubleSidedFinGrid(
        cols: Int,
        rows: Int,
        evalPoint: (_ u: Float, _ v: Float, _ side: Float) -> (pos: SIMD3<Float>, normal: SIMD3<Float>, spineT: Float, rayCoord: Float),
        vertices: inout [FishVertex],
        indices: inout [UInt32]
    ) {
        for side in [-1.0 as Float, 1.0 as Float] {
            let base = UInt32(vertices.count)
            for r in 0..<rows {
                let v = Float(r) / Float(rows - 1)
                for c in 0..<cols {
                    let u = Float(c) / Float(cols - 1)
                    let sample = evalPoint(u, v, side)
                    let n = simd_normalize(sample.normal)
                    let tangent = SIMD3<Float>(0.0, 0.0, -1.0)
                    let thickness = max(0.05, 1.0 - v * 0.90)

                    vertices.append(FishVertex(
                        position: SIMD4<Float>(sample.pos.x, sample.pos.y, sample.pos.z, 1.0),
                        normal: SIMD4<Float>(n.x, n.y, n.z, 0.85 + 0.15 * v),
                        tangent: SIMD4<Float>(tangent.x, tangent.y, tangent.z, side),
                        uvAndWeights: SIMD4<Float>(u, v, sample.spineT, v),
                        anatomyMask: SIMD4<Float>(1.0, 0.65, sample.rayCoord, thickness)
                    ))
                }
            }

            for r in 0..<(rows - 1) {
                for c in 0..<(cols - 1) {
                    let i0 = base + UInt32(r * cols + c)
                    let i1 = i0 + 1
                    let i2 = base + UInt32((r + 1) * cols + c)
                    let i3 = i2 + 1

                    if side > 0 {
                        indices.append(i0); indices.append(i2); indices.append(i1)
                        indices.append(i1); indices.append(i2); indices.append(i3)
                    } else {
                        indices.append(i0); indices.append(i1); indices.append(i2)
                        indices.append(i1); indices.append(i3); indices.append(i2)
                    }
                }
            }
        }
    }

    private static func appendDorsalFin(genome: FishGenome, vertices: inout [FishVertex], indices: inout [UInt32]) {
        let L = genome.bodyLength
        let tStart = genome.dorsalFinRange.lowerBound
        let tEnd = genome.dorsalFinRange.upperBound
        let finH = genome.dorsalFinHeight * L

        appendDoubleSidedFinGrid(cols: 14, rows: 6, evalPoint: { u, v, side in
            let spineT = tStart + (tEnd - tStart) * u
            let sec = bodySection(genome: genome, spineT: spineT)
            let zRoot = bodyCenterlineZ(spineT: spineT, length: L)
            let arch = (genome.species == .mahiMahi)
                ? (0.78 + 0.22 * (1.0 - u)) * sin(pow(u, 0.55) * Float.pi)
                : sin(u * Float.pi) * (0.75 + 0.25 * (1.0 - u))
            let rayRib = sin(u * 14.0 * Float.pi * 2.0) * 0.0018 * L * v
            let thicknessOffset = side * (0.0032 * L * (1.0 - v * 0.78) + rayRib)

            let y = sec.topY - 0.004 * L + finH * arch * v
            let z = zRoot - finH * 0.42 * v
            let normal = SIMD3<Float>(side, 0.12, -0.05)
            return (SIMD3<Float>(thicknessOffset, y, z), normal, spineT * 0.85, u * 14.0)
        }, vertices: &vertices, indices: &indices)
    }

    private static func appendAnalFin(genome: FishGenome, vertices: inout [FishVertex], indices: inout [UInt32]) {
        let L = genome.bodyLength
        let tStart = genome.analFinRange.lowerBound
        let tEnd = genome.analFinRange.upperBound
        let finH = genome.analFinHeight * L

        appendDoubleSidedFinGrid(cols: 10, rows: 5, evalPoint: { u, v, side in
            let spineT = tStart + (tEnd - tStart) * u
            let sec = bodySection(genome: genome, spineT: spineT)
            let zRoot = bodyCenterlineZ(spineT: spineT, length: L)
            let arch = sin(pow(u, 0.8) * Float.pi)
            let rayRib = sin(u * 10.0 * Float.pi * 2.0) * 0.0015 * L * v
            let x = side * (0.0026 * L * (1.0 - v * 0.8) + rayRib)

            let y = sec.botY + 0.003 * L - finH * arch * v
            let z = zRoot - finH * 0.45 * v
            let normal = SIMD3<Float>(side, -0.15, -0.05)
            return (SIMD3<Float>(x, y, z), normal, spineT * 0.85, u * 10.0)
        }, vertices: &vertices, indices: &indices)
    }

    private static func appendPairedPectoralFins(genome: FishGenome, vertices: inout [FishVertex], indices: inout [UInt32]) {
        let L = genome.bodyLength
        let attachT: Float = 0.255
        let sec = bodySection(genome: genome, spineT: attachT)
        let zAttach = bodyCenterlineZ(spineT: attachT, length: L)
        let yAttach = sec.botY + (sec.topY - sec.botY) * 0.30
        let finLen = genome.pectoralFinLength * L

        for bodySide in [-1.0 as Float, 1.0 as Float] {
            appendDoubleSidedFinGrid(cols: 8, rows: 5, evalPoint: { u, v, sheetSide in
                let fanAngle = (u - 0.5) * 0.82
                let reach = finLen * v * (0.72 + 0.28 * sin(u * Float.pi))
                let rayRib = sin(u * 9.0 * Float.pi * 2.0) * 0.0012 * L * v

                let x = bodySide * (sec.halfW * 0.88 + reach * 0.52)
                let y = yAttach - reach * 0.28 + sin(fanAngle) * reach * 0.38 + sheetSide * (0.0018 * L * (1.0 - v * 0.7) + rayRib)
                let z = zAttach - reach * 0.80 - cos(fanAngle) * reach * 0.10
                let normal = SIMD3<Float>(bodySide * 0.35, sheetSide * 0.90, 0.15)
                return (SIMD3<Float>(x, y, z), normal, attachT * 0.85, u * 9.0)
            }, vertices: &vertices, indices: &indices)
        }
    }

    private static func appendPairedPelvicFins(genome: FishGenome, vertices: inout [FishVertex], indices: inout [UInt32]) {
        let L = genome.bodyLength
        let attachT: Float = 0.36
        let sec = bodySection(genome: genome, spineT: attachT)
        let zAttach = bodyCenterlineZ(spineT: attachT, length: L)
        let finLen = genome.pelvicFinLength * L

        for bodySide in [-1.0 as Float, 1.0 as Float] {
            appendDoubleSidedFinGrid(cols: 6, rows: 4, evalPoint: { u, v, sheetSide in
                let reach = finLen * v * (0.70 + 0.30 * sin(u * Float.pi))
                let x = bodySide * (sec.halfW * 0.26 + reach * 0.34)
                let y = sec.botY + 0.004 * L - reach * 0.45 + sheetSide * 0.0015 * L * (1.0 - v * 0.7)
                let z = zAttach - reach * 0.82 - u * 0.018 * L
                let normal = SIMD3<Float>(bodySide * 0.4, sheetSide * 0.88, 0.1)
                return (SIMD3<Float>(x, y, z), normal, attachT * 0.85, u * 6.0)
            }, vertices: &vertices, indices: &indices)
        }
    }

    private static func appendCaudalFin(genome: FishGenome, vertices: inout [FishVertex], indices: inout [UInt32]) {
        let L = genome.bodyLength
        let sec = bodySection(genome: genome, spineT: 1.0)
        let zRoot = bodyCenterlineZ(spineT: 1.0, length: L)
        let midY = 0.5 * (sec.topY + sec.botY)
        let rootHalfH = 0.5 * (sec.topY - sec.botY)
        let tailLen = genome.caudalLength * L
        let maxHalfSpan = genome.caudalHalfSpan * L

        appendDoubleSidedFinGrid(cols: 14, rows: 9, evalPoint: { u, v, side in
            let lobe = u * 2.0 - 1.0
            let absLobe = abs(lobe)

            let forkCut = (1.0 - absLobe * absLobe) * genome.caudalForkDepth
            let paddleBulge = (1.0 - absLobe * absLobe) * max(0.0, 0.12 - genome.caudalForkDepth)
            let localReach = tailLen * (1.0 - forkCut + paddleBulge) * v

            let spanY = rootHalfH * (1.0 - v) + maxHalfSpan * v * pow(absLobe, 0.85)
            let y = midY + (lobe >= 0 ? 1.0 : -1.0) * spanY * absLobe
            let z = zRoot + 0.006 * L - localReach

            let rayRib = sin(u * 18.0 * Float.pi * 2.0) * 0.0016 * L * v
            let x = side * (0.0042 * L * (1.0 - v * 0.82) + rayRib)
            let spineT = 0.85 + 0.15 * v
            let normal = SIMD3<Float>(side, 0.0, -0.08)
            return (SIMD3<Float>(x, y, z), normal, spineT, u * 18.0)
        }, vertices: &vertices, indices: &indices)
    }

    private static func appendDualLayerEyes(genome: FishGenome, vertices: inout [FishVertex], indices: inout [UInt32]) {
        let L = genome.bodyLength
        let sec = bodySection(genome: genome, spineT: genome.eyeSpineT)
        let zEye = bodyCenterlineZ(spineT: genome.eyeSpineT, length: L)
        let yEye = sec.botY + (sec.topY - sec.botY) * (0.5 + genome.eyeVerticalRatio * 0.5)
        let rIris = genome.eyeRadius * L
        let rCornea = rIris * 1.14

        for side in [-1.0 as Float, 1.0 as Float] {
            let center = SIMD3<Float>(side * sec.halfW * 0.82, yEye, zEye)
            appendEyeHemisphere(center: center, radius: rIris, side: side, spineT: genome.eyeSpineT * 0.85, partID: 3.0, vertices: &vertices, indices: &indices)
            appendEyeHemisphere(center: center + SIMD3<Float>(side * rIris * 0.10, 0.0, 0.0), radius: rCornea, side: side, spineT: genome.eyeSpineT * 0.85, partID: 4.0, vertices: &vertices, indices: &indices)
        }
    }

    private static func appendEyeHemisphere(
        center: SIMD3<Float>,
        radius: Float,
        side: Float,
        spineT: Float,
        partID: Float,
        vertices: inout [FishVertex],
        indices: inout [UInt32]
    ) {
        let rings = 6
        let segs = 12
        let base = UInt32(vertices.count)

        for r in 0..<rings {
            let theta = (Float(r) / Float(rings - 1)) * (Float.pi * 0.52)
            let sinT = sin(theta)
            let cosT = cos(theta)
            for s in 0..<segs {
                let phi = (Float(s) / Float(segs)) * 2.0 * Float.pi
                let localN = SIMD3<Float>(side * cosT, sin(phi) * sinT, cos(phi) * sinT)
                let pos = center + localN * radius
                let uv = SIMD2<Float>(0.5 + cos(phi) * sinT * 0.5, 0.5 + sin(phi) * sinT * 0.5)

                vertices.append(FishVertex(
                    position: SIMD4<Float>(pos.x, pos.y, pos.z, 1.0),
                    normal: SIMD4<Float>(localN.x, localN.y, localN.z, 1.0),
                    tangent: SIMD4<Float>(0.0, 0.0, -1.0, side),
                    uvAndWeights: SIMD4<Float>(uv.x, uv.y, spineT, 0.0),
                    anatomyMask: SIMD4<Float>(partID, 0.5, 0.0, 1.0)
                ))
            }
        }

        for r in 0..<(rings - 1) {
            for s in 0..<segs {
                let sNext = (s + 1) % segs
                let i0 = base + UInt32(r * segs + s)
                let i1 = base + UInt32(r * segs + sNext)
                let i2 = base + UInt32((r + 1) * segs + s)
                let i3 = base + UInt32((r + 1) * segs + sNext)

                if side > 0 {
                    indices.append(i0); indices.append(i2); indices.append(i1)
                    indices.append(i1); indices.append(i2); indices.append(i3)
                } else {
                    indices.append(i0); indices.append(i1); indices.append(i2)
                    indices.append(i1); indices.append(i3); indices.append(i2)
                }
            }
        }
    }

    private static func clamp01(_ x: Float) -> Float {
        max(0.0, min(1.0, x))
    }
}
