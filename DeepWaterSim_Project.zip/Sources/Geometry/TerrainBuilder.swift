import Foundation
import Metal
import simd

public struct TerrainMesh: @unchecked Sendable {
    public let vertexBuffer: MTLBuffer
    public let indexBuffer: MTLBuffer
    public let indexCount: Int
    public let heightTexture: MTLTexture
    public let gridResolution: Int
    public let halfExtent: Float
    private let heights: [Float]

    public init(
        vertexBuffer: MTLBuffer,
        indexBuffer: MTLBuffer,
        indexCount: Int,
        heightTexture: MTLTexture,
        gridResolution: Int,
        halfExtent: Float,
        heights: [Float]
    ) {
        self.vertexBuffer = vertexBuffer
        self.indexBuffer = indexBuffer
        self.indexCount = indexCount
        self.heightTexture = heightTexture
        self.gridResolution = gridResolution
        self.halfExtent = halfExtent
        self.heights = heights
    }

    public func sampleHeight(x: Float, z: Float) -> Float {
        let u = (x / (halfExtent * 2.0)) + 0.5
        let v = (z / (halfExtent * 2.0)) + 0.5
        let fx = max(0.0, min(Float(gridResolution - 1), u * Float(gridResolution - 1)))
        let fz = max(0.0, min(Float(gridResolution - 1), v * Float(gridResolution - 1)))

        let x0 = Int(floor(fx))
        let z0 = Int(floor(fz))
        let x1 = min(gridResolution - 1, x0 + 1)
        let z1 = min(gridResolution - 1, z0 + 1)

        let tx = fx - Float(x0)
        let tz = fz - Float(z0)

        let h00 = heights[z0 * gridResolution + x0]
        let h10 = heights[z0 * gridResolution + x1]
        let h01 = heights[z1 * gridResolution + x0]
        let h11 = heights[z1 * gridResolution + x1]

        let h0 = h00 + (h10 - h00) * tx
        let h1 = h01 + (h11 - h01) * tx
        return h0 + (h1 - h0) * tz
    }
}

public enum TerrainBuilder {
    public static func build(device: MTLDevice, gridResolution: Int = 160, halfExtent: Float = 64.0) -> TerrainMesh? {
        let count = gridResolution * gridResolution
        var heights = [Float](repeating: 0.0, count: count)
        var rockWeights = [Float](repeating: 0.0, count: count)

        let step = (halfExtent * 2.0) / Float(gridResolution - 1)

        for zIdx in 0..<gridResolution {
            let z = -halfExtent + Float(zIdx) * step
            for xIdx in 0..<gridResolution {
                let x = -halfExtent + Float(xIdx) * step
                let (h, rockiness) = evaluateRiverbed(x: x, z: z)
                let idx = zIdx * gridResolution + xIdx
                heights[idx] = h
                rockWeights[idx] = rockiness
            }
        }

        var vertices = [Vertex]()
        vertices.reserveCapacity(count)

        for zIdx in 0..<gridResolution {
            let z = -halfExtent + Float(zIdx) * step
            let vCoord = Float(zIdx) / Float(gridResolution - 1)
            for xIdx in 0..<gridResolution {
                let x = -halfExtent + Float(xIdx) * step
                let uCoord = Float(xIdx) / Float(gridResolution - 1)
                let idx = zIdx * gridResolution + xIdx

                let hC = heights[idx]
                let hL = heights[zIdx * gridResolution + max(0, xIdx - 1)]
                let hR = heights[zIdx * gridResolution + min(gridResolution - 1, xIdx + 1)]
                let hD = heights[max(0, zIdx - 1) * gridResolution + xIdx]
                let hU = heights[min(gridResolution - 1, zIdx + 1) * gridResolution + xIdx]

                let normal = simd_normalize(SIMD3<Float>(hL - hR, 2.0 * step, hD - hU))
                let avgNeighbor = 0.25 * (hL + hR + hD + hU)
                let cavity = max(0.35, min(1.0, 0.85 + (hC - avgNeighbor) * 0.45))

                let slope = 1.0 - normal.y
                let materialBlend = max(0.0, min(1.0, rockWeights[idx] * 0.72 + slope * 1.45))
                let roughness = 0.78 - materialBlend * 0.16

                vertices.append(Vertex(
                    position: SIMD4<Float>(x, hC, z, 1.0),
                    normal: SIMD4<Float>(normal.x, normal.y, normal.z, cavity),
                    uvAndMaterial: SIMD4<Float>(uCoord, vCoord, materialBlend, roughness)
                ))
            }
        }

        var indices = [UInt32]()
        indices.reserveCapacity((gridResolution - 1) * (gridResolution - 1) * 6)
        for zIdx in 0..<(gridResolution - 1) {
            for xIdx in 0..<(gridResolution - 1) {
                let tl = UInt32(zIdx * gridResolution + xIdx)
                let tr = tl + 1
                let bl = UInt32((zIdx + 1) * gridResolution + xIdx)
                let br = bl + 1

                indices.append(tl)
                indices.append(bl)
                indices.append(tr)

                indices.append(tr)
                indices.append(bl)
                indices.append(br)
            }
        }

        guard let vertexBuffer = device.makeBuffer(
            bytes: vertices,
            length: MemoryLayout<Vertex>.stride * vertices.count,
            options: .storageModeShared
        ),
        let indexBuffer = device.makeBuffer(
            bytes: indices,
            length: MemoryLayout<UInt32>.stride * indices.count,
            options: .storageModeShared
        ) else {
            return nil
        }

        vertexBuffer.label = "TerrainVertexBuffer"
        indexBuffer.label = "TerrainIndexBuffer"

        let texDesc = MTLTextureDescriptor.texture2DDescriptor(
            pixelFormat: .r32Float,
            width: gridResolution,
            height: gridResolution,
            mipmapped: false
        )
        texDesc.storageMode = .shared
        texDesc.usage = .shaderRead

        guard let heightTexture = device.makeTexture(descriptor: texDesc) else {
            return nil
        }
        heightTexture.label = "TerrainHeightMapR32F"

        heights.withUnsafeBytes { rawPtr in
            if let base = rawPtr.baseAddress {
                heightTexture.replace(
                    region: MTLRegionMake2D(0, 0, gridResolution, gridResolution),
                    mipmapLevel: 0,
                    withBytes: base,
                    bytesPerRow: gridResolution * MemoryLayout<Float>.stride
                )
            }
        }

        return TerrainMesh(
            vertexBuffer: vertexBuffer,
            indexBuffer: indexBuffer,
            indexCount: indices.count,
            heightTexture: heightTexture,
            gridResolution: gridResolution,
            halfExtent: halfExtent,
            heights: heights
        )
    }

    private static func evaluateRiverbed(x: Float, z: Float) -> (height: Float, rockiness: Float) {
        let shoreFactor = smoothstep(edge0: 14.0, edge1: 38.0, x: z)
        let shoalHeight = -2.2 + shoreFactor * 5.2

        let ledgeTransition = smoothstep(edge0: 10.0, edge1: -6.0, x: z)
        var height = shoalHeight - ledgeTransition * 6.8

        let poolDX = (x - 4.0) * 0.055
        let poolDZ = (z + 22.0) * 0.062
        let poolDistSq = poolDX * poolDX + poolDZ * poolDZ
        let deepPool = exp(-poolDistSq * 2.2) * 7.4
        height -= deepPool

        let macroFbm = fbm(x: x * 0.045, z: z * 0.045, octaves: 5)
        let detailFbm = fbm(x: x * 0.16 + 13.7, z: z * 0.16 - 9.2, octaves: 4)
        height += (macroFbm - 0.5) * 2.8 + (detailFbm - 0.5) * 0.65

        let boulder1 = boulderCluster(x: x, z: z, cx: -10.5, cz: 9.0, radius: 7.5, peakHeight: 3.1)
        let boulder2 = boulderCluster(x: x, z: z, cx: 12.0, cz: 4.5, radius: 8.2, peakHeight: 3.6)
        let boulder3 = boulderCluster(x: x, z: z, cx: -3.5, cz: -8.5, radius: 6.8, peakHeight: 3.4)
        let boulder4 = boulderCluster(x: x, z: z, cx: 16.5, cz: -14.0, radius: 9.0, peakHeight: 4.2)
        let boulder5 = boulderCluster(x: x, z: z, cx: -18.0, cz: 21.0, radius: 10.5, peakHeight: 4.4)

        let ridgeNoise = 1.0 - abs(fbm(x: x * 0.12 - 5.1, z: z * 0.12 + 3.4, octaves: 4) * 2.0 - 1.0)
        let rockOutcrop = (boulder1 + boulder2 + boulder3 + boulder4 + boulder5) * (0.55 + 0.65 * ridgeNoise)
        height += rockOutcrop

        let rockiness = max(0.0, min(1.0, rockOutcrop * 0.45 + shoreFactor * 0.35 + (ridgeNoise - 0.55) * 0.5))
        return (height, rockiness)
    }

    private static func boulderCluster(
        x: Float,
        z: Float,
        cx: Float,
        cz: Float,
        radius: Float,
        peakHeight: Float
    ) -> Float {
        let dx = x - cx
        let dz = z - cz
        let dist = sqrt(dx * dx + dz * dz)
        let t = max(0.0, 1.0 - dist / radius)
        return t * t * (3.0 - 2.0 * t) * peakHeight
    }

    private static func smoothstep(edge0: Float, edge1: Float, x: Float) -> Float {
        let t = max(0.0, min(1.0, (x - edge0) / (edge1 - edge0)))
        return t * t * (3.0 - 2.0 * t)
    }

    private static func hash2D(_ ix: Int, _ iz: Int) -> Float {
        var n = ix &* 374761393 &+ iz &* 668265263
        n = (n ^ (n >> 13)) &* 1274126177
        n = n ^ (n >> 16)
        return Float(n & 0x7fffffff) / Float(0x7fffffff)
    }

    private static func valueNoise(_ x: Float, _ z: Float) -> Float {
        let ix = Int(floor(x))
        let iz = Int(floor(z))
        let fx = x - Float(ix)
        let fz = z - Float(iz)
        let ux = fx * fx * (3.0 - 2.0 * fx)
        let uz = fz * fz * (3.0 - 2.0 * fz)

        let a = hash2D(ix, iz)
        let b = hash2D(ix + 1, iz)
        let c = hash2D(ix, iz + 1)
        let d = hash2D(ix + 1, iz + 1)

        let ab = a + (b - a) * ux
        let cd = c + (d - c) * ux
        return ab + (cd - ab) * uz
    }

    private static func fbm(x: Float, z: Float, octaves: Int) -> Float {
        var value: Float = 0.0
        var amplitude: Float = 0.5
        var freq: Float = 1.0
        var norm: Float = 0.0
        for _ in 0..<octaves {
            value += amplitude * valueNoise(x * freq, z * freq)
            norm += amplitude
            freq *= 2.04
            amplitude *= 0.5
        }
        return value / max(norm, 0.0001)
    }
}
