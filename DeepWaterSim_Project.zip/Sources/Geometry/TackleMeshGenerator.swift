import Foundation
import Metal
import simd

public enum LureType: Int, CaseIterable, Sendable, Identifiable {
    case minnowHardbait = 0
    case jigheadSoftWorm = 1
    case metalSpoon = 2

    public var id: Int { rawValue }

    public var chineseName: String {
        switch self {
        case .minnowHardbait: return "米诺硬饵"
        case .jigheadSoftWorm: return "铅头钩软虫"
        case .metalSpoon: return "金属亮片"
        }
    }
}

public struct ProceduralMesh: @unchecked Sendable {
    public let vertexBuffer: MTLBuffer
    public let indexBuffer: MTLBuffer
    public let vertexCount: Int
    public let indexCount: Int
    public let label: String
}

public struct SpinningReelAssembly: @unchecked Sendable {
    public let bodyAndSpoolMesh: ProceduralMesh
    public let bailWireMesh: ProceduralMesh
    public let bailPivotLocal: SIMD3<Float>
    public let lineRollerOffset: SIMD3<Float>
}

public enum TackleMeshGenerator {
    public static func buildFishingRod(device: MTLDevice, length: Float = 2.40) -> ProceduralMesh? {
        var vertices: [Vertex] = []
        var indices: [UInt32] = []
        vertices.reserveCapacity(4200)
        indices.reserveCapacity(18000)

        appendLatheProfile(
            profile: [
                (0.00, 0.0135), (0.015, 0.0145), (0.11, 0.0138), (0.125, 0.0115),
                (0.13, 0.0075)
            ],
            radialSegments: 20,
            materialID: 2.0,
            roughness: 0.82,
            vertices: &vertices,
            indices: &indices
        )

        appendLatheProfile(
            profile: [
                (0.24, 0.0085), (0.25, 0.0118), (0.35, 0.0118), (0.365, 0.0128), (0.38, 0.0095)
            ],
            radialSegments: 20,
            materialID: 1.0,
            roughness: 0.24,
            vertices: &vertices,
            indices: &indices
        )

        appendLatheProfile(
            profile: [
                (0.38, 0.0095), (0.39, 0.0126), (0.46, 0.0112), (0.48, 0.0072)
            ],
            radialSegments: 20,
            materialID: 2.0,
            roughness: 0.82,
            vertices: &vertices,
            indices: &indices
        )

        var blankProfile: [(Float, Float)] = []
        let blankSegments = 36
        for i in 0...blankSegments {
            let t = Float(i) / Float(blankSegments)
            let z = 0.12 + t * (length - 0.12)
            let radius = 0.0068 * pow(1.0 - t, 1.25) + 0.0011
            blankProfile.append((z, radius))
        }
        appendLatheProfile(
            profile: blankProfile,
            radialSegments: 16,
            materialID: 0.0,
            roughness: 0.22,
            vertices: &vertices,
            indices: &indices
        )

        let guideFractions: [Float] = [0.34, 0.46, 0.57, 0.67, 0.76, 0.84, 0.92, 0.996]
        for (idx, frac) in guideFractions.enumerated() {
            let zPos = frac * length
            let blankR = 0.0068 * pow(1.0 - frac, 1.25) + 0.0011
            let scale = 1.0 - Float(idx) * 0.095
            let ringRadius = max(0.0024, 0.0105 * scale)
            let ringTube = max(0.0007, 0.0014 * scale)
            let standOff = blankR + ringRadius + 0.0065 * scale
            let ringCenter = SIMD3<Float>(0.0, -standOff, zPos)

            appendTorus(
                center: ringCenter,
                axis: SIMD3<Float>(0.0, 0.0, 1.0),
                majorRadius: ringRadius + ringTube * 0.65,
                minorRadius: ringTube * 0.75,
                majorSegs: 16,
                minorSegs: 8,
                materialID: 1.0,
                roughness: 0.22,
                vertices: &vertices,
                indices: &indices
            )

            appendTorus(
                center: ringCenter,
                axis: SIMD3<Float>(0.0, 0.0, 1.0),
                majorRadius: ringRadius,
                minorRadius: ringTube * 0.65,
                majorSegs: 16,
                minorSegs: 8,
                materialID: 3.0,
                roughness: 0.08,
                vertices: &vertices,
                indices: &indices
            )

            for side in [-1.0 as Float, 1.0 as Float] {
                let pStart = SIMD3<Float>(side * blankR * 0.45, -blankR * 0.85, zPos - 0.012 * scale)
                let pMid = SIMD3<Float>(side * ringRadius * 0.75, -standOff * 0.65, zPos - 0.004 * scale)
                let pEnd = ringCenter + SIMD3<Float>(side * ringRadius * 0.85, ringRadius * 0.55, 0.0)
                appendSweptTube(
                    points: [pStart, pMid, pEnd],
                    radii: [0.0009 * scale, 0.0008 * scale, 0.0007 * scale],
                    radialSegments: 6,
                    materialID: 1.0,
                    roughness: 0.24,
                    vertices: &vertices,
                    indices: &indices
                )
            }
        }

        return finalizeMesh(device: device, vertices: vertices, indices: indices, label: "CarbonFishingRod")
    }

    public static func buildSpinningReel(device: MTLDevice) -> SpinningReelAssembly? {
        var bodyVerts: [Vertex] = []
        var bodyIdx: [UInt32] = []

        let bodyCenterOffset = SIMD3<Float>(0.0, -0.058, 0.0)
        appendLatheProfile(
            profile: [
                (-0.042, 0.004), (-0.036, 0.018), (-0.018, 0.025),
                (0.012, 0.022), (0.028, 0.014), (0.034, 0.005)
            ],
            radialSegments: 20,
            offset: bodyCenterOffset,
            materialID: 1.0,
            roughness: 0.26,
            vertices: &bodyVerts,
            indices: &bodyIdx
        )

        appendSweptTube(
            points: [
                SIMD3<Float>(0.0, -0.042, -0.004),
                SIMD3<Float>(0.0, -0.016, 0.004),
                SIMD3<Float>(0.0, -0.002, 0.004)
            ],
            radii: [0.0065, 0.0052, 0.0045],
            radialSegments: 10,
            materialID: 1.0,
            roughness: 0.24,
            vertices: &bodyVerts,
            indices: &bodyIdx
        )

        appendSweptTube(
            points: [
                SIMD3<Float>(0.0, -0.001, -0.028),
                SIMD3<Float>(0.0, -0.001, 0.0),
                SIMD3<Float>(0.0, -0.001, 0.028)
            ],
            radii: [0.0032, 0.0042, 0.0032],
            radialSegments: 8,
            materialID: 1.0,
            roughness: 0.26,
            vertices: &bodyVerts,
            indices: &bodyIdx
        )

        appendLatheProfile(
            profile: [
                (0.034, 0.024), (0.037, 0.0265), (0.041, 0.019),
                (0.068, 0.019), (0.072, 0.0255), (0.077, 0.023),
                (0.080, 0.014), (0.086, 0.011), (0.088, 0.002)
            ],
            radialSegments: 28,
            offset: bodyCenterOffset,
            materialID: 1.0,
            roughness: 0.18,
            vertices: &bodyVerts,
            indices: &bodyIdx
        )

        for side in [-1.0 as Float, 1.0 as Float] {
            appendSweptTube(
                points: [
                    bodyCenterOffset + SIMD3<Float>(side * 0.014, 0.0, 0.030),
                    bodyCenterOffset + SIMD3<Float>(side * 0.034, 0.0, 0.036),
                    bodyCenterOffset + SIMD3<Float>(side * 0.036, 0.0, 0.074)
                ],
                radii: [0.0055, 0.0048, 0.0042],
                radialSegments: 8,
                materialID: 0.0,
                roughness: 0.24,
                vertices: &bodyVerts,
                indices: &bodyIdx
            )
        }

        appendSweptTube(
            points: [
                bodyCenterOffset + SIMD3<Float>(0.018, 0.0, -0.006),
                bodyCenterOffset + SIMD3<Float>(0.038, 0.0, -0.006),
                bodyCenterOffset + SIMD3<Float>(0.044, -0.046, -0.006),
                bodyCenterOffset + SIMD3<Float>(0.056, -0.046, -0.006)
            ],
            radii: [0.0042, 0.0036, 0.0032, 0.0030],
            radialSegments: 8,
            materialID: 1.0,
            roughness: 0.22,
            vertices: &bodyVerts,
            indices: &bodyIdx
        )

        appendSweptTube(
            points: [
                bodyCenterOffset + SIMD3<Float>(0.056, -0.046, -0.006),
                bodyCenterOffset + SIMD3<Float>(0.068, -0.046, -0.006),
                bodyCenterOffset + SIMD3<Float>(0.082, -0.046, -0.006)
            ],
            radii: [0.0065, 0.0105, 0.0082],
            radialSegments: 14,
            materialID: 2.0,
            roughness: 0.80,
            vertices: &bodyVerts,
            indices: &bodyIdx
        )

        let bailPivot = bodyCenterOffset + SIMD3<Float>(0.0, 0.0, 0.074)
        var bailVerts: [Vertex] = []
        var bailIdx: [UInt32] = []
        var bailArc: [SIMD3<Float>] = []
        let arcSteps = 18
        for i in 0...arcSteps {
            let theta = Float(i) / Float(arcSteps) * Float.pi
            let bx = cos(theta) * 0.036
            let by = sin(theta) * 0.034
            let bz = sin(theta) * 0.012
            bailArc.append(SIMD3<Float>(bx, by, bz))
        }
        appendSweptTube(
            points: bailArc,
            radii: [Float](repeating: 0.0015, count: bailArc.count),
            radialSegments: 8,
            materialID: 4.0,
            roughness: 0.10,
            vertices: &bailVerts,
            indices: &bailIdx
        )
        appendTorus(
            center: SIMD3<Float>(0.034, 0.005, 0.002),
            axis: SIMD3<Float>(1.0, 0.0, 0.0),
            majorRadius: 0.0038,
            minorRadius: 0.0018,
            majorSegs: 12,
            minorSegs: 8,
            materialID: 1.0,
            roughness: 0.14,
            vertices: &bailVerts,
            indices: &bailIdx
        )

        guard let bodyMesh = finalizeMesh(device: device, vertices: bodyVerts, indices: bodyIdx, label: "SpinningReelBody"),
              let bailMesh = finalizeMesh(device: device, vertices: bailVerts, indices: bailIdx, label: "SpinningReelBail") else {
            return nil
        }

        return SpinningReelAssembly(
            bodyAndSpoolMesh: bodyMesh,
            bailWireMesh: bailMesh,
            bailPivotLocal: bailPivot,
            lineRollerOffset: SIMD3<Float>(0.034, 0.005, 0.002)
        )
    }

    public static func buildLure(device: MTLDevice, type: LureType) -> ProceduralMesh? {
        var vertices: [Vertex] = []
        var indices: [UInt32] = []

        switch type {
        case .minnowHardbait:
            appendLatheProfile(
                profile: [
                    (0.055, 0.0018), (0.048, 0.0065), (0.032, 0.0098),
                    (0.008, 0.0102), (-0.022, 0.0074), (-0.048, 0.0042), (-0.055, 0.0020)
                ],
                radialSegments: 20,
                scaleXY: SIMD2<Float>(0.68, 1.15),
                materialID: 4.0,
                roughness: 0.12,
                vertices: &vertices,
                indices: &indices
            )
            appendSweptTube(
                points: [
                    SIMD3<Float>(0.0, -0.004, 0.048),
                    SIMD3<Float>(0.0, -0.014, 0.064),
                    SIMD3<Float>(0.0, -0.021, 0.076)
                ],
                radii: [0.0065, 0.0078, 0.0052],
                radialSegments: 10,
                scaleXY: SIMD2<Float>(1.1, 0.18),
                materialID: 3.0,
                roughness: 0.06,
                vertices: &vertices,
                indices: &indices
            )
            appendTrebleHook(origin: SIMD3<Float>(0.0, -0.011, 0.004), scale: 1.0, vertices: &vertices, indices: &indices)
            appendTrebleHook(origin: SIMD3<Float>(0.0, -0.002, -0.057), scale: 0.92, vertices: &vertices, indices: &indices)

        case .jigheadSoftWorm:
            appendLatheProfile(
                profile: [
                    (0.014, 0.001), (0.011, 0.0068), (0.005, 0.0085),
                    (-0.002, 0.0078), (-0.008, 0.0038), (-0.012, 0.0032)
                ],
                radialSegments: 18,
                materialID: 1.0,
                roughness: 0.30,
                vertices: &vertices,
                indices: &indices
            )
            appendSingleHook(origin: SIMD3<Float>(0.0, 0.002, 0.004), directionY: 1.0, scale: 1.15, vertices: &vertices, indices: &indices)

            var wormProfile: [(Float, Float)] = []
            let segs = 34
            for i in 0...segs {
                let t = Float(i) / Float(segs)
                let z = -0.006 - t * 0.092
                let taper = (1.0 - t * 0.68)
                let rib = 1.0 + 0.18 * sin(t * 20.0 * Float.pi * 2.0) * (1.0 - smoothstep(0.78, 0.92, t))
                let paddle = smoothstep(0.84, 0.96, t) * 0.0065
                wormProfile.append((z, max(0.0018, 0.0062 * taper * rib + paddle)))
            }
            appendLatheProfile(
                profile: wormProfile,
                radialSegments: 16,
                scaleXY: SIMD2<Float>(0.85, 1.15),
                materialID: 5.0,
                roughness: 0.32,
                vertices: &vertices,
                indices: &indices
            )

        case .metalSpoon:
            let cols = 10
            let rows = 16
            let base = UInt32(vertices.count)
            for r in 0..<rows {
                let v = Float(r) / Float(rows - 1)
                let z = (0.5 - v) * 0.068
                let width = sin(pow(v, 0.78) * Float.pi) * 0.0135
                let sCurveY = sin(v * Float.pi * 1.45) * 0.0055
                for c in 0..<cols {
                    let u = Float(c) / Float(cols - 1)
                    let xNorm = u * 2.0 - 1.0
                    let x = xNorm * width
                    let cupY = (1.0 - xNorm * xNorm) * 0.0042 * sin(v * Float.pi)
                    let pos = SIMD3<Float>(x, sCurveY - cupY, z)
                    let n = simd_normalize(SIMD3<Float>(xNorm * 0.45, 1.0, cos(v * Float.pi * 1.45) * 0.35))
                    vertices.append(Vertex(
                        position: SIMD4<Float>(pos.x, pos.y, pos.z, 1.0),
                        normal: SIMD4<Float>(n.x, n.y, n.z, 1.0),
                        uvAndMaterial: SIMD4<Float>(u, v, 4.0, 0.08)
                    ))
                }
            }
            for r in 0..<(rows - 1) {
                for c in 0..<(cols - 1) {
                    let i0 = base + UInt32(r * cols + c)
                    let i1 = i0 + 1
                    let i2 = base + UInt32((r + 1) * cols + c)
                    let i3 = i2 + 1
                    indices.append(i0); indices.append(i2); indices.append(i1)
                    indices.append(i1); indices.append(i2); indices.append(i3)
                }
            }
            appendTorus(
                center: SIMD3<Float>(0.0, 0.0, 0.036),
                axis: SIMD3<Float>(0.0, 1.0, 0.0),
                majorRadius: 0.0032,
                minorRadius: 0.0007,
                majorSegs: 12,
                minorSegs: 6,
                materialID: 4.0,
                roughness: 0.10,
                vertices: &vertices,
                indices: &indices
            )
            appendTrebleHook(origin: SIMD3<Float>(0.0, -0.003, -0.036), scale: 1.05, vertices: &vertices, indices: &indices)
        }

        return finalizeMesh(device: device, vertices: vertices, indices: indices, label: "Lure_\(type.rawValue)")
    }

    private static func appendTrebleHook(
        origin: SIMD3<Float>,
        scale: Float,
        vertices: inout [Vertex],
        indices: inout [UInt32]
    ) {
        appendTorus(
            center: origin,
            axis: SIMD3<Float>(1.0, 0.0, 0.0),
            majorRadius: 0.0022 * scale,
            minorRadius: 0.00055 * scale,
            majorSegs: 10,
            minorSegs: 6,
            materialID: 4.0,
            roughness: 0.12,
            vertices: &vertices,
            indices: &indices
        )

        for arm in 0..<3 {
            let angle = Float(arm) * (2.0 * Float.pi / 3.0)
            let radDir = SIMD3<Float>(cos(angle), 0.0, sin(angle))
            let pts: [SIMD3<Float>] = [
                origin + SIMD3<Float>(0.0, -0.0015, 0.0) * scale,
                origin + SIMD3<Float>(0.0, -0.0110, 0.0) * scale,
                origin + (SIMD3<Float>(0.0, -0.0165, 0.0) + radDir * 0.0042) * scale,
                origin + (SIMD3<Float>(0.0, -0.0158, 0.0) + radDir * 0.0084) * scale,
                origin + (SIMD3<Float>(0.0, -0.0102, 0.0) + radDir * 0.0090) * scale,
                origin + (SIMD3<Float>(0.0, -0.0072, 0.0) + radDir * 0.0080) * scale
            ]
            let r = 0.00055 * scale
            appendSweptTube(
                points: pts,
                radii: [r, r, r, r * 0.9, r * 0.65, r * 0.18],
                radialSegments: 6,
                materialID: 4.0,
                roughness: 0.12,
                vertices: &vertices,
                indices: &indices
            )
        }
    }

    private static func appendSingleHook(
        origin: SIMD3<Float>,
        directionY: Float,
        scale: Float,
        vertices: inout [Vertex],
        indices: inout [UInt32]
    ) {
        let pts: [SIMD3<Float>] = [
            origin,
            origin + SIMD3<Float>(0.0, 0.0, -0.022) * scale,
            origin + SIMD3<Float>(0.0, 0.006 * directionY, -0.029) * scale,
            origin + SIMD3<Float>(0.0, 0.013 * directionY, -0.025) * scale,
            origin + SIMD3<Float>(0.0, 0.014 * directionY, -0.017) * scale
        ]
        let r = 0.0007 * scale
        appendSweptTube(
            points: pts,
            radii: [r, r, r, r * 0.75, r * 0.2],
            radialSegments: 6,
            materialID: 4.0,
            roughness: 0.12,
            vertices: &vertices,
            indices: &indices
        )
    }

    private static func appendLatheProfile(
        profile: [(z: Float, r: Float)],
        radialSegments: Int,
        offset: SIMD3<Float> = .zero,
        scaleXY: SIMD2<Float> = SIMD2<Float>(1.0, 1.0),
        materialID: Float,
        roughness: Float,
        vertices: inout [Vertex],
        indices: inout [UInt32]
    ) {
        guard profile.count >= 2 else { return }
        let base = UInt32(vertices.count)
        let rows = profile.count

        for i in 0..<rows {
            let z = profile[i].z
            let rad = profile[i].r
            let vCoord = Float(i) / Float(rows - 1)

            let prev = profile[max(0, i - 1)]
            let next = profile[min(rows - 1, i + 1)]
            let dz = next.z - prev.z
            let dr = next.r - prev.r
            let slopeN = simd_normalize(SIMD2<Float>(dz, -dr))

            for s in 0..<radialSegments {
                let uCoord = Float(s) / Float(radialSegments)
                let phi = uCoord * 2.0 * Float.pi
                let cx = cos(phi)
                let sy = sin(phi)

                let pos = offset + SIMD3<Float>(cx * rad * scaleXY.x, sy * rad * scaleXY.y, z)
                let normal = simd_normalize(SIMD3<Float>(cx * slopeN.x, sy * slopeN.x, slopeN.y))
                vertices.append(Vertex(
                    position: SIMD4<Float>(pos.x, pos.y, pos.z, 1.0),
                    normal: SIMD4<Float>(normal.x, normal.y, normal.z, 1.0),
                    uvAndMaterial: SIMD4<Float>(uCoord, vCoord, materialID, roughness)
                ))
            }
        }

        for i in 0..<(rows - 1) {
            for s in 0..<radialSegments {
                let sNext = (s + 1) % radialSegments
                let i0 = base + UInt32(i * radialSegments + s)
                let i1 = base + UInt32(i * radialSegments + sNext)
                let i2 = base + UInt32((i + 1) * radialSegments + s)
                let i3 = base + UInt32((i + 1) * radialSegments + sNext)
                indices.append(i0); indices.append(i2); indices.append(i1)
                indices.append(i1); indices.append(i2); indices.append(i3)
            }
        }
    }

    private static func appendTorus(
        center: SIMD3<Float>,
        axis: SIMD3<Float>,
        majorRadius: Float,
        minorRadius: Float,
        majorSegs: Int,
        minorSegs: Int,
        materialID: Float,
        roughness: Float,
        vertices: inout [Vertex],
        indices: inout [UInt32]
    ) {
        let up = simd_normalize(axis)
        let ref = abs(up.y) < 0.9 ? SIMD3<Float>(0, 1, 0) : SIMD3<Float>(1, 0, 0)
        let tangentX = simd_normalize(simd_cross(ref, up))
        let tangentY = simd_cross(up, tangentX)

        let base = UInt32(vertices.count)
        for i in 0..<majorSegs {
            let u = Float(i) / Float(majorSegs)
            let theta = u * 2.0 * Float.pi
            let radial = tangentX * cos(theta) + tangentY * sin(theta)
            let ringCenter = center + radial * majorRadius

            for j in 0..<minorSegs {
                let v = Float(j) / Float(minorSegs)
                let phi = v * 2.0 * Float.pi
                let normal = simd_normalize(radial * cos(phi) + up * sin(phi))
                let pos = ringCenter + normal * minorRadius
                vertices.append(Vertex(
                    position: SIMD4<Float>(pos.x, pos.y, pos.z, 1.0),
                    normal: SIMD4<Float>(normal.x, normal.y, normal.z, 1.0),
                    uvAndMaterial: SIMD4<Float>(u, v, materialID, roughness)
                ))
            }
        }

        for i in 0..<majorSegs {
            let iNext = (i + 1) % majorSegs
            for j in 0..<minorSegs {
                let jNext = (j + 1) % minorSegs
                let a = base + UInt32(i * minorSegs + j)
                let b = base + UInt32(iNext * minorSegs + j)
                let c = base + UInt32(i * minorSegs + jNext)
                let d = base + UInt32(iNext * minorSegs + jNext)
                indices.append(a); indices.append(b); indices.append(c)
                indices.append(b); indices.append(d); indices.append(c)
            }
        }
    }

    private static func appendSweptTube(
        points: [SIMD3<Float>],
        radii: [Float],
        radialSegments: Int,
        scaleXY: SIMD2<Float> = SIMD2<Float>(1.0, 1.0),
        materialID: Float,
        roughness: Float,
        vertices: inout [Vertex],
        indices: inout [UInt32]
    ) {
        guard points.count >= 2, points.count == radii.count else { return }
        let base = UInt32(vertices.count)

        for i in 0..<points.count {
            let p = points[i]
            let prev = points[max(0, i - 1)]
            let next = points[min(points.count - 1, i + 1)]
            let dir = simd_normalize(next - prev)
            let ref = abs(dir.y) < 0.9 ? SIMD3<Float>(0, 1, 0) : SIMD3<Float>(1, 0, 0)
            let right = simd_normalize(simd_cross(ref, dir))
            let up = simd_cross(dir, right)
            let vCoord = Float(i) / Float(points.count - 1)
            let r = radii[i]

            for s in 0..<radialSegments {
                let uCoord = Float(s) / Float(radialSegments)
                let phi = uCoord * 2.0 * Float.pi
                let offsetDir = right * (cos(phi) * scaleXY.x) + up * (sin(phi) * scaleXY.y)
                let pos = p + offsetDir * r
                let normal = simd_normalize(offsetDir)
                vertices.append(Vertex(
                    position: SIMD4<Float>(pos.x, pos.y, pos.z, 1.0),
                    normal: SIMD4<Float>(normal.x, normal.y, normal.z, 1.0),
                    uvAndMaterial: SIMD4<Float>(uCoord, vCoord, materialID, roughness)
                ))
            }
        }

        for i in 0..<(points.count - 1) {
            for s in 0..<radialSegments {
                let sNext = (s + 1) % radialSegments
                let i0 = base + UInt32(i * radialSegments + s)
                let i1 = base + UInt32(i * radialSegments + sNext)
                let i2 = base + UInt32((i + 1) * radialSegments + s)
                let i3 = base + UInt32((i + 1) * radialSegments + sNext)
                indices.append(i0); indices.append(i2); indices.append(i1)
                indices.append(i1); indices.append(i2); indices.append(i3)
            }
        }
    }

    private static func smoothstep(_ edge0: Float, _ edge1: Float, _ x: Float) -> Float {
        let t = max(0.0, min(1.0, (x - edge0) / max(edge1 - edge0, 0.0001)))
        return t * t * (3.0 - 2.0 * t)
    }

    private static func finalizeMesh(
        device: MTLDevice,
        vertices: [Vertex],
        indices: [UInt32],
        label: String
    ) -> ProceduralMesh? {
        guard !vertices.isEmpty, !indices.isEmpty,
              let vb = device.makeBuffer(
                bytes: vertices,
                length: MemoryLayout<Vertex>.stride * vertices.count,
                options: .storageModeShared
              ),
              let ib = device.makeBuffer(
                bytes: indices,
                length: MemoryLayout<UInt32>.stride * indices.count,
                options: .storageModeShared
              ) else {
            return nil
        }
        vb.label = "\(label)_VB"
        ib.label = "\(label)_IB"
        return ProceduralMesh(
            vertexBuffer: vb,
            indexBuffer: ib,
            vertexCount: vertices.count,
            indexCount: indices.count,
            label: label
        )
    }
}
