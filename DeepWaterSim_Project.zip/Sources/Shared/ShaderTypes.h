#ifndef ShaderTypes_h
#define ShaderTypes_h

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#else
#import <Foundation/Foundation.h>
#endif

#include <simd/simd.h>

#ifdef __METAL_VERSION__
typedef enum : int32_t {
    BufferIndexVertices = 0,
    BufferIndexUniforms = 1,
    BufferIndexFishInstances = 2,
    BufferIndexBakeParams = 3,
    BufferIndexSplashEvents = 4,
    BufferIndexBoidsIn = 5,
    BufferIndexBoidsOut = 6,
    BufferIndexBoidsParams = 7,
    BufferIndexHashCounts = 8,
    BufferIndexHashIndices = 9,
    BufferIndexPredators = 10,
    BufferIndexTackleUniforms = 11,
    BufferIndexWeedInstances = 12,
    BufferIndexSplashParticles = 13
} BufferIndex;

typedef enum : int32_t {
    TextureIndexHdrColor = 0,
    TextureIndexTerrainHeight = 1,
    TextureIndexAlbedo = 2,
    TextureIndexNormal = 3,
    TextureIndexRoughnessMeta = 4,
    TextureIndexIridescence = 5,
    TextureIndexCarbonAlbedo = 6,
    TextureIndexAluminumAlbedo = 7,
    TextureIndexCorkAlbedo = 8
} TextureIndex;
#else
typedef NS_ENUM(int32_t, BufferIndex) {
    BufferIndexVertices = 0,
    BufferIndexUniforms = 1,
    BufferIndexFishInstances = 2,
    BufferIndexBakeParams = 3,
    BufferIndexSplashEvents = 4,
    BufferIndexBoidsIn = 5,
    BufferIndexBoidsOut = 6,
    BufferIndexBoidsParams = 7,
    BufferIndexHashCounts = 8,
    BufferIndexHashIndices = 9,
    BufferIndexPredators = 10,
    BufferIndexTackleUniforms = 11,
    BufferIndexWeedInstances = 12,
    BufferIndexSplashParticles = 13
};

typedef NS_ENUM(int32_t, TextureIndex) {
    TextureIndexHdrColor = 0,
    TextureIndexTerrainHeight = 1,
    TextureIndexAlbedo = 2,
    TextureIndexNormal = 3,
    TextureIndexRoughnessMeta = 4,
    TextureIndexIridescence = 5,
    TextureIndexCarbonAlbedo = 6,
    TextureIndexAluminumAlbedo = 7,
    TextureIndexCorkAlbedo = 8
};
#endif

// 48 bytes (3 x 16B)
typedef struct {
    simd_float4 position;
    simd_float4 normal;
    simd_float4 uvAndMaterial;
} Vertex;

// 320 bytes (20 x 16B)
typedef struct {
    simd_float4x4 viewMatrix;
    simd_float4x4 projectionMatrix;
    simd_float4x4 viewProjectionMatrix;
    simd_float4x4 invViewProjectionMatrix;
    simd_float4 positionAndFov;
    simd_float4 forwardAndNear;
    simd_float4 rightAndFar;
    simd_float4 upAndUnderwater;
} CameraParams;

// 112 bytes (7 x 16B)
typedef struct {
    simd_float4 sunDirectionAndElevation;
    simd_float4 sunColorAndIntensity;
    simd_float4 skyZenithColorAndTime;
    simd_float4 skyHorizonColorAndFog;
    simd_float4 rayleighCoeffAndScale;
    simd_float4 mieCoeffAndG;
    simd_float4 ambientColorAndExposure;
} AtmosphereParams;

// 224 bytes (14 x 16B)
typedef struct {
    simd_float4 gerstnerWaves[8];
    simd_float4 absorptionAndClarity;
    simd_float4 deepColorAndSurfaceY;
    simd_float4 shallowColorAndFoam;
    simd_float4 causticParams;
    simd_float4 godRayParams;
    simd_float4 gridParams;
} WaterParams;

// 672 bytes (42 x 16B)
typedef struct {
    CameraParams camera;
    AtmosphereParams atmosphere;
    WaterParams water;
    simd_float4 viewportAndTime;
} Uniforms;

// 80 bytes (5 x 16B)
typedef struct {
    simd_float4 position;
    simd_float4 normal;
    simd_float4 tangent;
    simd_float4 uvAndWeights;
    simd_float4 anatomyMask;
} FishVertex;

// 144 bytes (9 x 16B)
typedef struct {
    simd_float4x4 modelMatrix;
    simd_float4 swimParams;
    simd_float4 dorsalColorAndSpecies;
    simd_float4 ventralColorAndIridescence;
    simd_float4 biomechParams;
    simd_float4 breachAndShakeParams;
} FishInstanceData;

// 64 bytes (4 x 16B)
typedef struct {
    simd_float4 primaryColorAndFreq;
    simd_float4 secondaryColorAndRough;
    simd_float4 accentColorAndMode;
    simd_float4 sizeAndSeed;
} TextureBakeParams;

// 32 bytes (2 x 16B)
typedef struct {
    simd_float4 worldPositionAndRadius;
    simd_float4 intensityAndFlags;
} SplashTriggerEvent;

// 64 bytes (4 x 16B)
typedef struct {
    simd_float4 positionAndPhase;
    simd_float4 velocityAndSpeed;
    simd_float4 homeAndFear;
    simd_float4 metaParams;
} BoidAgent;

// 32 bytes (2 x 16B)
typedef struct {
    simd_float4 positionAndRadius;
    simd_float4 velocityAndIntensity;
} PredatorThreat;

// 96 bytes (6 x 16B)
typedef struct {
    simd_float4 timeAndCounts;
    simd_float4 currentAndSurface;
    simd_float4 attractorAndClarity;
    simd_float4 weightsAndCell;
    simd_float4 radiiAndTerrain;
    simd_float4 dorsalAndIridescence;
} BoidsSimParams;

// 80 bytes (5 x 16B)
typedef struct {
    simd_float4x4 modelMatrix;
    simd_float4 tintAndParams;
} TackleUniforms;

// 32 bytes (2 x 16B)
typedef struct {
    simd_float4 positionAndScale;   // xyz: riverbed anchor, w: height scale
    simd_float4 swayPhaseAndTint;   // x: phase, y: yaw rad, z: olive/emerald tint, w: flexibility
} WeedInstanceData;

// 32 bytes (2 x 16B)
typedef struct {
    simd_float4 positionAndSize;    // xyz: world pos, w: billboard radius (m)
    simd_float4 colorAndAlpha;      // xyz: frothy spray RGB, w: alpha [0..1]
} SplashParticleData;

#endif /* ShaderTypes_h */
