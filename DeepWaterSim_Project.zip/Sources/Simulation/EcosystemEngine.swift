import Foundation
import simd

public enum BarometricTrend: Int, CaseIterable, Sendable {
    case rising = 0
    case steady = 1
    case falling = 2
    case stormFront = 3

    public var displayName: String {
        switch self {
        case .rising: return "气压回升"
        case .steady: return "气压平稳"
        case .falling: return "低压前夕"
        case .stormFront: return "锋面低压"
        }
    }
}

public enum MicroHabitatType: Int, CaseIterable, Sendable {
    case shallowWeedbed = 0
    case rockyReef = 1
    case dropOffLedge = 2
    case deepPool = 3
    case openPelagic = 4
}

public struct HabitatSpot: Sendable, Identifiable {
    public let id: Int
    public let name: String
    public let type: MicroHabitatType
    public let center: SIMD3<Float>
    public let radius: Float
    public let minDepth: Float
    public let maxDepth: Float
    public let coverDensity: Float
}

public struct SpeciesEcologyProfile: Sendable {
    public let species: FishSpecies
    public let optimalTempRangeC: ClosedRange<Float>
    public let preferredDepthMin: Float
    public let preferredDepthMax: Float
    public let phototaxis: Float
    public let pressureSensitivity: Float
    public let primaryHabitat: MicroHabitatType
    public let secondaryHabitat: MicroHabitatType
    public let preferredCurrentMin: Float
}

public struct HydrologicalSample: Sendable {
    public let temperatureC: Float
    public let dissolvedOxygenMgL: Float
    public let currentVelocity: SIMD3<Float>
    public let lightIrradiance: Float
}

@MainActor
public final class EcosystemEngine: ObservableObject {
    @Published public var timeOfDayHours: Float = 9.5
    @Published public var cloudCover: Float = 0.25
    @Published public var barometricPressureHPa: Float = 1011.0
    @Published public var barometricTrend: BarometricTrend = .falling
    @Published public var surfaceTemperatureC: Float = 21.5
    @Published public var thermoclineDepthMeters: Float = 7.2
    @Published public var waterClarityMeters: Float = 6.5
    @Published public var baseCurrentSpeed: Float = 0.48

    @Published public private(set) var solarIrradiance: Float = 0.75
    @Published public private(set) var planktonActivity: Float = 0.65
    @Published public private(set) var predatorFeedingIndex: Float = 0.72
    @Published public private(set) var activeBaitfishAttractor: SIMD3<Float> = SIMD3<Float>(0.0, -2.2, 2.0)

    public let habitatSpots: [HabitatSpot]
    private var simClock: Float = 0.0

    public init() {
        self.habitatSpots = [
            HabitatSpot(id: 0, name: "近岸浅滩水草区", type: .shallowWeedbed, center: SIMD3<Float>(-6.0, -1.6, 15.0), radius: 10.0, minDepth: 0.8, maxDepth: 2.8, coverDensity: 0.85),
            HabitatSpot(id: 1, name: "西侧乱石礁盘", type: .rockyReef, center: SIMD3<Float>(-10.5, -3.2, 9.0), radius: 8.5, minDepth: 1.5, maxDepth: 5.2, coverDensity: 0.92),
            HabitatSpot(id: 2, name: "东侧陡坎障碍区", type: .dropOffLedge, center: SIMD3<Float>(12.0, -5.0, 4.5), radius: 10.5, minDepth: 2.5, maxDepth: 8.5, coverDensity: 0.78),
            HabitatSpot(id: 3, name: "中段断层陡坎", type: .dropOffLedge, center: SIMD3<Float>(-3.5, -6.5, -7.5), radius: 11.0, minDepth: 3.5, maxDepth: 9.8, coverDensity: 0.72),
            HabitatSpot(id: 4, name: "北侧深潭洄水区", type: .deepPool, center: SIMD3<Float>(4.0, -11.5, -22.0), radius: 14.0, minDepth: 7.5, maxDepth: 15.0, coverDensity: 0.60),
            HabitatSpot(id: 5, name: "开放中上层巡游带", type: .openPelagic, center: SIMD3<Float>(2.0, -2.8, -6.0), radius: 22.0, minDepth: 1.0, maxDepth: 6.5, coverDensity: 0.15)
        ]
        update(deltaTime: 0.0, timeOfDayHours: timeOfDayHours)
    }

    public func update(deltaTime: Float, timeOfDayHours: Float) {
        self.timeOfDayHours = timeOfDayHours
        self.simClock += deltaTime

        let hourAngle = ((timeOfDayHours - 6.0) / 24.0) * 2.0 * Float.pi
        let rawSun = max(0.0, sin(hourAngle))
        let cloudAtten = 1.0 - cloudCover * 0.62
        solarIrradiance = max(0.03, rawSun * cloudAtten)

        let dawnPeak = exp(-pow((timeOfDayHours - 6.8) / 2.2, 2.0))
        let duskPeak = exp(-pow((timeOfDayHours - 18.4) / 2.4, 2.0))
        let thermalBoost = max(0.4, min(1.2, (surfaceTemperatureC - 8.0) / 16.0))
        let pressureBoost: Float
        switch barometricTrend {
        case .falling: pressureBoost = 1.25
        case .stormFront: pressureBoost = 1.15
        case .steady: pressureBoost = 1.00
        case .rising: pressureBoost = 0.82
        }
        planktonActivity = max(0.15, min(1.0, (0.28 + 0.62 * max(dawnPeak, duskPeak) + cloudCover * 0.15) * thermalBoost * pressureBoost))

        let shallowPreference = max(0.0, min(1.0, planktonActivity * 0.75 + (1.0 - solarIrradiance) * 0.45))
        let targetY = -(1.4 + (1.0 - shallowPreference) * (thermoclineDepthMeters - 2.0))
        let driftX = sin(simClock * 0.075) * 11.5 + cos(simClock * 0.031) * 4.5
        let driftZ = -4.0 + shallowPreference * 14.0 + cos(simClock * 0.055) * 6.5
        activeBaitfishAttractor = SIMD3<Float>(driftX, targetY, driftZ)

        predatorFeedingIndex = max(0.18, min(1.0, planktonActivity * 0.65 + (1.0 - abs(solarIrradiance - 0.35)) * 0.35))
    }

    public func waterTemperature(depthMeters: Float) -> Float {
        let d = max(0.0, depthMeters)
        let epilimnionT = surfaceTemperatureC
        let hypolimnionT = max(6.5, surfaceTemperatureC - 9.5)
        let steepness: Float = 0.85
        let thermoFactor = 1.0 / (1.0 + exp((d - thermoclineDepthMeters) * steepness))
        return hypolimnionT + (epilimnionT - hypolimnionT) * thermoFactor
    }

    public func dissolvedOxygen(depthMeters: Float) -> Float {
        let d = max(0.0, depthMeters)
        let surfaceDO: Float = 9.4 - max(0.0, surfaceTemperatureC - 15.0) * 0.14
        let deepDrop = 1.0 / (1.0 + exp(-(d - (thermoclineDepthMeters + 1.5)) * 0.75))
        let currentAeration = min(1.2, baseCurrentSpeed * 1.1)
        return max(2.2, surfaceDO - deepDrop * 4.6 + currentAeration)
    }

    public func currentVelocity(at worldPos: SIMD3<Float>, seabedY: Float) -> SIMD3<Float> {
        let depth = max(0.0, -worldPos.y)
        let heightAboveBed = max(0.05, worldPos.y - seabedY)
        let boundaryLayer = min(1.0, pow(heightAboveBed / 1.4, 0.35))
        let depthDecay = exp(-depth * 0.055)

        let meander = sin(worldPos.z * 0.06 + simClock * 0.15) * 0.32
        let eddyCurl = cos(worldPos.x * 0.09 - worldPos.z * 0.07) * 0.18
        let speed = baseCurrentSpeed * boundaryLayer * depthDecay
        return SIMD3<Float>(
            (0.82 + meander) * speed,
            sin(worldPos.x * 0.08 + worldPos.z * 0.08) * 0.04 * speed,
            (-0.42 + eddyCurl) * speed
        )
    }

    public func sampleHydrology(at worldPos: SIMD3<Float>, seabedY: Float) -> HydrologicalSample {
        let depth = max(0.0, -worldPos.y)
        let light = solarIrradiance * exp(-depth / max(waterClarityMeters, 1.0))
        return HydrologicalSample(
            temperatureC: waterTemperature(depthMeters: depth),
            dissolvedOxygenMgL: dissolvedOxygen(depthMeters: depth),
            currentVelocity: currentVelocity(at: worldPos, seabedY: seabedY),
            lightIrradiance: light
        )
    }

    public static func ecologyProfile(for species: FishSpecies) -> SpeciesEcologyProfile {
        switch species {
        case .largemouthBass:
            return SpeciesEcologyProfile(species: .largemouthBass, optimalTempRangeC: 18.0...26.0, preferredDepthMin: 1.0, preferredDepthMax: 6.0, phototaxis: -0.35, pressureSensitivity: 0.85, primaryHabitat: .shallowWeedbed, secondaryHabitat: .dropOffLedge, preferredCurrentMin: 0.05)
        case .rainbowTrout:
            return SpeciesEcologyProfile(species: .rainbowTrout, optimalTempRangeC: 11.0...17.5, preferredDepthMin: 2.5, preferredDepthMax: 9.5, phototaxis: -0.15, pressureSensitivity: 0.65, primaryHabitat: .dropOffLedge, secondaryHabitat: .deepPool, preferredCurrentMin: 0.35)
        case .redSnapper:
            return SpeciesEcologyProfile(species: .redSnapper, optimalTempRangeC: 17.0...25.0, preferredDepthMin: 3.0, preferredDepthMax: 11.0, phototaxis: -0.45, pressureSensitivity: 0.72, primaryHabitat: .rockyReef, secondaryHabitat: .dropOffLedge, preferredCurrentMin: 0.20)
        case .topmouthCulter:
            return SpeciesEcologyProfile(species: .topmouthCulter, optimalTempRangeC: 16.0...27.0, preferredDepthMin: 0.6, preferredDepthMax: 4.5, phototaxis: 0.45, pressureSensitivity: 0.90, primaryHabitat: .openPelagic, secondaryHabitat: .dropOffLedge, preferredCurrentMin: 0.15)
        case .grouper:
            return SpeciesEcologyProfile(species: .grouper, optimalTempRangeC: 18.0...26.5, preferredDepthMin: 4.5, preferredDepthMax: 14.0, phototaxis: -0.75, pressureSensitivity: 0.55, primaryHabitat: .rockyReef, secondaryHabitat: .deepPool, preferredCurrentMin: 0.10)
        }
    }

    public func preferredHabitatAnchor(for species: FishSpecies, seed: Int) -> SIMD3<Float> {
        let profile = Self.ecologyProfile(for: species)
        let matching = habitatSpots.filter { $0.type == profile.primaryHabitat || $0.type == profile.secondaryHabitat }
        let chosenSpot = matching.isEmpty ? habitatSpots[seed % habitatSpots.count] : matching[seed % matching.count]

        let midOptTemp = 0.5 * (profile.optimalTempRangeC.lowerBound + profile.optimalTempRangeC.upperBound)
        let tempDiff = surfaceTemperatureC - midOptTemp
        let thermalDepthShift = max(-2.0, min(5.5, tempDiff * 0.45))
        let lightDepthShift = -profile.phototaxis * solarIrradiance * 2.8

        let baseDepth = 0.5 * (profile.preferredDepthMin + profile.preferredDepthMax)
        let targetDepth = max(chosenSpot.minDepth, min(chosenSpot.maxDepth, baseDepth + thermalDepthShift + lightDepthShift))

        let chaseWeight: Float = (species == .topmouthCulter || species == .largemouthBass)
            ? predatorFeedingIndex * 0.38
            : predatorFeedingIndex * 0.20

        let rawAnchor = SIMD3<Float>(chosenSpot.center.x, -targetDepth, chosenSpot.center.z)
        return simd_mix(rawAnchor, activeBaitfishAttractor, SIMD3<Float>(repeating: chaseWeight))
    }

    public func speciesAppetite(for species: FishSpecies, at worldPos: SIMD3<Float>, seabedY: Float) -> Float {
        let profile = Self.ecologyProfile(for: species)
        let hydro = sampleHydrology(at: worldPos, seabedY: seabedY)

        let optMid = 0.5 * (profile.optimalTempRangeC.lowerBound + profile.optimalTempRangeC.upperBound)
        let optHalf = max(2.0, 0.5 * (profile.optimalTempRangeC.upperBound - profile.optimalTempRangeC.lowerBound))
        let tempScore = exp(-pow((hydro.temperatureC - optMid) / (optHalf * 1.35), 2.0))
        let doScore = max(0.3, min(1.0, (hydro.dissolvedOxygenMgL - 2.5) / 5.5))

        let pressureBonus: Float
        switch barometricTrend {
        case .falling: pressureBonus = 1.0 + 0.30 * profile.pressureSensitivity
        case .stormFront: pressureBonus = 1.0 + 0.15 * profile.pressureSensitivity
        case .steady: pressureBonus = 1.0
        case .rising: pressureBonus = 1.0 - 0.22 * profile.pressureSensitivity
        }

        return max(0.22, min(1.40, (0.35 + 0.65 * tempScore) * doScore * pressureBonus * (0.65 + 0.55 * predatorFeedingIndex)))
    }
}
