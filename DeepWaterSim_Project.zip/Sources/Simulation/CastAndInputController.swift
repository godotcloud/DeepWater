import Foundation
import CoreMotion
import QuartzCore
import simd

public enum InputControlMode: Int, CaseIterable, Sendable, Identifiable {
    case motionCasting = 0
    case oneHandTouch = 1

    public var id: Int { rawValue }

    public var displayName: String {
        switch self {
        case .motionCasting: return "体感甩竿"
        case .oneHandTouch: return "单手触控"
        }
    }
}

public struct CastTriggerSignal: Sendable {
    public let powerNormalized: Float
    public let aimYawOffset: Float
    public let elevationRad: Float
}

@MainActor
public final class CastAndInputController: ObservableObject {
    @Published public var controlMode: InputControlMode = .oneHandTouch
    @Published public var isMotionAvailable: Bool = false
    @Published public var reelThrottle: Float = 0.0
    @Published public var dragSetting: Float = 0.55
    @Published public var rodPower: RodPower = .mediumLight
    @Published public var activeLure: LureType = .minnowHardbait
    @Published public var castChargeProgress: Float = 0.0
    @Published public var isChargingCast: Bool = false
    @Published public var simulatedFishFightActive: Bool = false

    @Published public var currentLineTensionN: Float = 0.0
    @Published public var normalizedTension: Float = 0.0
    @Published public var lineOutMeters: Float = 12.0
    @Published public var lureDepthMeters: Float = 0.5
    @Published public var isLineBroken: Bool = false

    public var onCastTriggered: ((CastTriggerSignal) -> Void)?
    public var onTwitchTriggered: ((Float) -> Void)?

    private let motionManager = CMMotionManager()
    private let motionQueue: OperationQueue = {
        let q = OperationQueue()
        q.name = "com.deepwatersim.coremotion"
        q.maxConcurrentOperationCount = 1
        return q
    }()

    private var backswingArmed: Bool = false
    private var backswingTimestamp: CFTimeInterval = 0.0
    private var lastCastTimestamp: CFTimeInterval = 0.0
    private var livePitchRate: Float = 0.0
    private var liveYawOffset: Float = 0.0

    public init() {
        self.isMotionAvailable = motionManager.isDeviceMotionAvailable
        if isMotionAvailable {
            self.controlMode = .motionCasting
        }
    }

    public func setControlMode(_ mode: InputControlMode) {
        if mode == .motionCasting && !isMotionAvailable {
            controlMode = .oneHandTouch
            stopMotionUpdates()
            return
        }
        controlMode = mode
        if mode == .motionCasting {
            startMotionUpdates()
        } else {
            stopMotionUpdates()
        }
    }

    public func startMotionUpdates() {
        guard controlMode == .motionCasting,
              motionManager.isDeviceMotionAvailable,
              !motionManager.isDeviceMotionActive else { return }

        motionManager.deviceMotionUpdateInterval = 1.0 / 60.0
        motionManager.startDeviceMotionUpdates(to: motionQueue) { [weak self] motion, _ in
            guard let motion = motion else { return }
            let pitchRate = Float(motion.rotationRate.x)
            let yawAngle = Float(motion.attitude.yaw)
            let forwardAccel = Float(-motion.userAcceleration.z)
            let upwardAccel = Float(motion.userAcceleration.y)
            let totalWhip = max(0.0, -pitchRate * 0.22 + forwardAccel * 0.45 + upwardAccel * 0.25)

            Task { @MainActor [weak self] in
                self?.processMotionSample(
                    pitchRate: pitchRate,
                    yawAngle: yawAngle,
                    whipMagnitude: totalWhip
                )
            }
        }
    }

    public func stopMotionUpdates() {
        if motionManager.isDeviceMotionActive {
            motionManager.stopDeviceMotionUpdates()
        }
        backswingArmed = false
    }

    private func processMotionSample(pitchRate: Float, yawAngle: Float, whipMagnitude: Float) {
        let now = CACurrentMediaTime()
        livePitchRate = pitchRate
        liveYawOffset = max(-0.55, min(0.55, yawAngle * 0.35))

        if pitchRate > 2.4 {
            backswingArmed = true
            backswingTimestamp = now
        }

        if backswingArmed && (now - backswingTimestamp) > 1.1 {
            backswingArmed = false
        }

        let cooldownElapsed = (now - lastCastTimestamp) > 1.25
        if backswingArmed && cooldownElapsed && whipMagnitude > 1.35 {
            backswingArmed = false
            lastCastTimestamp = now
            let power = max(0.28, min(1.0, (whipMagnitude - 1.0) / 2.2))
            onCastTriggered?(CastTriggerSignal(
                powerNormalized: power,
                aimYawOffset: liveYawOffset,
                elevationRad: 0.42 + power * 0.16
            ))
        } else if !backswingArmed && cooldownElapsed && abs(pitchRate) > 3.6 {
            lastCastTimestamp = now - 0.85
            onTwitchTriggered?(min(1.3, abs(pitchRate) * 0.25))
        }
    }

    public func beginTouchCastCharge() {
        isChargingCast = true
        castChargeProgress = 0.15
    }

    public func updateTouchCharge(deltaTime: Float) {
        guard isChargingCast else { return }
        castChargeProgress = min(1.0, castChargeProgress + deltaTime * 0.85)
    }

    public func releaseTouchCast() {
        guard isChargingCast else { return }
        let power = max(0.25, castChargeProgress)
        isChargingCast = false
        castChargeProgress = 0.0
        onCastTriggered?(CastTriggerSignal(
            powerNormalized: power,
            aimYawOffset: 0.0,
            elevationRad: 0.40 + power * 0.18
        ))
    }

    public var currentRetrieveSpeedMetersPerSec: Float {
        reelThrottle * 2.65
    }
}
