import Foundation
import simd

public enum RodPower: Int, CaseIterable, Sendable, Identifiable {
    case ultraLight = 0
    case mediumLight = 1
    case mediumHeavy = 2

    public var id: Int { rawValue }

    public var shortCode: String {
        switch self {
        case .ultraLight: return "UL"
        case .mediumLight: return "ML"
        case .mediumHeavy: return "MH"
        }
    }

    public var buttFlexuralRigidity: Float {
        switch self {
        case .ultraLight: return 2.8
        case .mediumLight: return 6.2
        case .mediumHeavy: return 13.5
        }
    }

    public var taperExponent: Float {
        switch self {
        case .ultraLight: return 3.45
        case .mediumLight: return 3.15
        case .mediumHeavy: return 2.80
        }
    }
}

public struct LureDynamicsOutput: Sendable {
    public var position: SIMD3<Float>
    public var velocity: SIMD3<Float>
    public var depthBelowSurface: Float
    public var wobbleAngleRad: Float
    public var rollAngleRad: Float
    public var surfaceRippleIntensity: Float
    public var isSubmerged: Bool
}

public struct PhysicsStepEvents: Sendable {
    public var lureJustSplashed: Bool = false
    public var splashImpactSpeed: Float = 0.0
    public var dragSlipSpeedMetersPerSec: Float = 0.0
    public var dragClickRateHz: Float = 0.0
    public var lineJustBroke: Bool = false
    public var lineTensionNewtons: Float = 0.0
    public var normalizedTension: Float = 0.0
}

@MainActor
public final class RodAndLinePhysics {
    public static let rodSegmentCount = 16
    public static let rodNodeCount = 17
    public static let lineNodeCount = 32

    public var rodPower: RodPower = .mediumLight
    public let rodLength: Float = 2.40
    public let guideFractions: [Float] = [0.34, 0.46, 0.57, 0.67, 0.76, 0.84, 0.92, 0.996]

    public var rodButtWorldPosition: SIMD3<Float> = SIMD3<Float>(0.32, 1.42, 24.1)
    public var rodBaseYaw: Float = 0.0
    public var rodBasePitch: Float = 0.34
    public private(set) var rodNodesWorld: [SIMD3<Float>]
    public private(set) var rodTangentsWorld: [SIMD3<Float>]
    public private(set) var guideWorldPositions: [SIMD3<Float>]

    private var segmentBendPitch: [Float]
    private var segmentBendYaw: [Float]
    private var segmentVelPitch: [Float]
    private var segmentVelYaw: [Float]

    public private(set) var linePositions: [SIMD3<Float>]
    private var linePrevPositions: [SIMD3<Float>]
    public private(set) var lineOutLength: Float = 14.0
    public let minLineOutLength: Float = 1.6
    public let maxSpoolCapacity: Float = 110.0

    public var maxLineBreakNewtons: Float = 48.0
    public var dragSettingNormalized: Float = 0.55
    public private(set) var isLineBroken: Bool = false
    public private(set) var isBailOpen: Bool = false

    public var waterSurfaceY: Float = 0.0
    public var windVelocity: SIMD3<Float> = SIMD3<Float>(1.4, 0.0, -0.8)
    public var waterCurrentVelocity: SIMD3<Float> = SIMD3<Float>(0.35, 0.0, -0.18)

    public var activeLureType: LureType = .minnowHardbait
    public private(set) var lureState: LureDynamicsOutput
    private var lureSubmergedLastFrame: Bool = false
    private var wobblePhase: Float = 0.0
    private var twitchImpulseDecay: Float = 0.0

    public init() {
        self.rodNodesWorld = [SIMD3<Float>](repeating: .zero, count: Self.rodNodeCount)
        self.rodTangentsWorld = [SIMD3<Float>](repeating: SIMD3<Float>(0, 0, -1), count: Self.rodNodeCount)
        self.guideWorldPositions = [SIMD3<Float>](repeating: .zero, count: 8)
        self.segmentBendPitch = [Float](repeating: 0.0, count: Self.rodSegmentCount)
        self.segmentBendYaw = [Float](repeating: 0.0, count: Self.rodSegmentCount)
        self.segmentVelPitch = [Float](repeating: 0.0, count: Self.rodSegmentCount)
        self.segmentVelYaw = [Float](repeating: 0.0, count: Self.rodSegmentCount)

        self.linePositions = [SIMD3<Float>](repeating: .zero, count: Self.lineNodeCount)
        self.linePrevPositions = [SIMD3<Float>](repeating: .zero, count: Self.lineNodeCount)
        self.lureState = LureDynamicsOutput(
            position: SIMD3<Float>(0.0, -0.5, 11.0),
            velocity: .zero,
            depthBelowSurface: 0.5,
            wobbleAngleRad: 0.0,
            rollAngleRad: 0.0,
            surfaceRippleIntensity: 0.0,
            isSubmerged: true
        )

        resetRigToReadyPosition()
    }

    public func resetRigToReadyPosition() {
        isLineBroken = false
        isBailOpen = false
        lineOutLength = 12.0
        for i in 0..<Self.rodSegmentCount {
            segmentBendPitch[i] = 0.0
            segmentBendYaw[i] = 0.0
            segmentVelPitch[i] = 0.0
            segmentVelYaw[i] = 0.0
        }
        integrateRodGeometry()
        let tip = rodNodesWorld[Self.rodNodeCount - 1]
        let lurePos = tip + SIMD3<Float>(0.0, -2.2, -10.5)
        for i in 0..<Self.lineNodeCount {
            let t = Float(i) / Float(Self.lineNodeCount - 1)
            let p = simd_mix(tip, lurePos, SIMD3<Float>(repeating: t))
            linePositions[i] = p
            linePrevPositions[i] = p
        }
        lureState.position = lurePos
        lureState.velocity = .zero
        lureSubmergedLastFrame = lurePos.y < waterSurfaceY
    }

    public func launchCast(powerNormalized: Float, aimYawOffset: Float, elevationRad: Float) {
        isLineBroken = false
        isBailOpen = true
        let clampedPower = max(0.20, min(1.0, powerNormalized))
        let launchSpeed = 10.0 + clampedPower * 24.0

        let tip = rodNodesWorld[Self.rodNodeCount - 1]
        let yaw = rodBaseYaw + aimYawOffset
        let elev = max(0.22, min(0.88, elevationRad))
        let dir = simd_normalize(SIMD3<Float>(
            sin(yaw) * cos(elev),
            sin(elev),
            -cos(yaw) * cos(elev)
        ))

        lineOutLength = 2.2
        for i in 0..<Self.lineNodeCount {
            let t = Float(i) / Float(Self.lineNodeCount - 1)
            let p = tip + dir * (t * 0.45)
            linePositions[i] = p
            linePrevPositions[i] = p - dir * (launchSpeed * t * (1.0 / 60.0))
        }
        lureState.position = linePositions[Self.lineNodeCount - 1]
        lureState.velocity = dir * launchSpeed
        lureSubmergedLastFrame = false
    }

    public func triggerRodTwitch(strength: Float = 1.0) {
        let s = max(0.2, min(1.5, strength))
        twitchImpulseDecay = min(1.5, twitchImpulseDecay + s)
        for i in 6..<Self.rodSegmentCount {
            segmentVelPitch[i] += 2.6 * s * (Float(i) / Float(Self.rodSegmentCount))
        }
    }

    public func step(
        deltaTime rawDt: Float,
        reelSpeedMetersPerSec: Float,
        externalFishPullForce: SIMD3<Float>,
        terrainHeightAt: (Float, Float) -> Float
    ) -> PhysicsStepEvents {
        let dt = min(max(rawDt, 1.0 / 240.0), 1.0 / 30.0)
        var events = PhysicsStepEvents()
        twitchImpulseDecay = max(0.0, twitchImpulseDecay - dt * 2.8)

        if reelSpeedMetersPerSec > 0.05 && isBailOpen {
            isBailOpen = false
        }

        if !isLineBroken {
            if isBailOpen {
                let tip = rodNodesWorld[Self.rodNodeCount - 1]
                let distToLure = simd_distance(tip, linePositions[Self.lineNodeCount - 1])
                lineOutLength = min(maxSpoolCapacity, max(lineOutLength, distToLure + 0.15))
            } else if reelSpeedMetersPerSec > 0.001 {
                lineOutLength = max(minLineOutLength, lineOutLength - reelSpeedMetersPerSec * dt)
            }
        }

        let (tipTensionVec, tensionMag) = stepFishingLineXPBD(
            dt: dt,
            reelSpeed: reelSpeedMetersPerSec,
            externalFishPull: externalFishPullForce,
            terrainHeightAt: terrainHeightAt,
            events: &events
        )

        let dragLimit = max(2.5, maxLineBreakNewtons * 0.88 * max(0.05, min(1.0, dragSettingNormalized)))
        if !isLineBroken && !isBailOpen {
            if tensionMag > maxLineBreakNewtons {
                isLineBroken = true
                events.lineJustBroke = true
            } else if tensionMag > dragLimit {
                let excessForce = tensionMag - dragLimit
                let slipSpeed = min(14.0, 0.45 + excessForce * 0.32)
                lineOutLength = min(maxSpoolCapacity, lineOutLength + slipSpeed * dt)
                events.dragSlipSpeedMetersPerSec = slipSpeed
                events.dragClickRateHz = min(62.0, 8.0 + slipSpeed * 7.5)
            }
        }

        events.lineTensionNewtons = isLineBroken ? 0.0 : tensionMag
        events.normalizedTension = isLineBroken ? 0.0 : min(1.0, tensionMag / max(maxLineBreakNewtons, 1.0))

        let effectiveTipForce = isLineBroken ? .zero : tipTensionVec
        stepRodCantilever(dt: dt, tipForceWorld: effectiveTipForce)

        return events
    }

    private func stepRodCantilever(dt: Float, tipForceWorld: SIMD3<Float>) {
        let baseFrame = rodBaseBasis()
        let invRot = simd_transpose(baseFrame)
        let tipForceLocal = invRot * tipForceWorld

        let segLen = rodLength / Float(Self.rodSegmentCount)
        let eiButt = rodPower.buttFlexuralRigidity
        let taperExp = rodPower.taperExponent

        var localTip = SIMD3<Float>(0, 0, 0)
        var cumPitch: Float = 0.0
        var cumYaw: Float = 0.0
        var localNodePos = [SIMD3<Float>](repeating: .zero, count: Self.rodNodeCount)
        for i in 0..<Self.rodSegmentCount {
            cumPitch += segmentBendPitch[i]
            cumYaw += segmentBendYaw[i]
            let dir = SIMD3<Float>(
                sin(cumYaw) * cos(cumPitch),
                sin(cumPitch),
                -cos(cumYaw) * cos(cumPitch)
            )
            localTip += dir * segLen
            localNodePos[i + 1] = localTip
        }

        let springStiffness: Float = 68.0
        let springDamping: Float = 11.5

        for i in 0..<Self.rodSegmentCount {
            let s = (Float(i) + 0.5) / Float(Self.rodSegmentCount)
            let leverArm = localTip - localNodePos[i]
            let moment = simd_cross(leverArm, tipForceLocal)

            let eiLocal = max(0.018, eiButt * pow(max(0.08, 1.0 - 0.88 * s), taperExp))

            let targetPitch = max(-0.145, min(0.145, (moment.x / eiLocal) * segLen))
            let targetYaw = max(-0.145, min(0.145, (-moment.y / eiLocal) * segLen))

            let accPitch = (targetPitch - segmentBendPitch[i]) * springStiffness - segmentVelPitch[i] * springDamping
            let accYaw = (targetYaw - segmentBendYaw[i]) * springStiffness - segmentVelYaw[i] * springDamping

            segmentVelPitch[i] += accPitch * dt
            segmentVelYaw[i] += accYaw * dt
            segmentBendPitch[i] = max(-0.16, min(0.16, segmentBendPitch[i] + segmentVelPitch[i] * dt))
            segmentBendYaw[i] = max(-0.16, min(0.16, segmentBendYaw[i] + segmentVelYaw[i] * dt))
        }

        integrateRodGeometry()
    }

    private func integrateRodGeometry() {
        let baseFrame = rodBaseBasis()
        let segLen = rodLength / Float(Self.rodSegmentCount)

        var pos = rodButtWorldPosition
        var cumPitch: Float = 0.0
        var cumYaw: Float = 0.0

        rodNodesWorld[0] = pos
        rodTangentsWorld[0] = baseFrame * SIMD3<Float>(0, 0, -1)

        for i in 0..<Self.rodSegmentCount {
            cumPitch += segmentBendPitch[i]
            cumYaw += segmentBendYaw[i]
            let localDir = SIMD3<Float>(
                sin(cumYaw) * cos(cumPitch),
                sin(cumPitch),
                -cos(cumYaw) * cos(cumPitch)
            )
            let worldDir = simd_normalize(baseFrame * localDir)
            pos += worldDir * segLen
            rodNodesWorld[i + 1] = pos
            rodTangentsWorld[i + 1] = worldDir
        }

        for (idx, frac) in guideFractions.enumerated() {
            let fIndex = frac * Float(Self.rodSegmentCount)
            let i0 = max(0, min(Self.rodSegmentCount - 1, Int(floor(fIndex))))
            let i1 = min(Self.rodSegmentCount, i0 + 1)
            let alpha = fIndex - Float(i0)
            let p = simd_mix(rodNodesWorld[i0], rodNodesWorld[i1], SIMD3<Float>(repeating: alpha))
            let t = simd_normalize(simd_mix(rodTangentsWorld[i0], rodTangentsWorld[i1], SIMD3<Float>(repeating: alpha)))
            let downOffset = simd_normalize(simd_cross(t, SIMD3<Float>(1, 0, 0))) * -0.012
            guideWorldPositions[idx] = p + downOffset
        }
    }

    public func deformRodVertex(localPosition: SIMD3<Float>) -> SIMD3<Float> {
        let frac = max(0.0, min(1.0, localPosition.z / rodLength))
        let fIndex = frac * Float(Self.rodSegmentCount)
        let i0 = max(0, min(Self.rodSegmentCount - 1, Int(floor(fIndex))))
        let i1 = min(Self.rodSegmentCount, i0 + 1)
        let alpha = fIndex - Float(i0)

        let center = simd_mix(rodNodesWorld[i0], rodNodesWorld[i1], SIMD3<Float>(repeating: alpha))
        let forward = simd_normalize(simd_mix(rodTangentsWorld[i0], rodTangentsWorld[i1], SIMD3<Float>(repeating: alpha)))
        let right = simd_normalize(simd_cross(forward, SIMD3<Float>(0, 1, 0)))
        let up = simd_cross(right, forward)
        return center + right * localPosition.x + up * localPosition.y
    }

    private func rodBaseBasis() -> simd_float3x3 {
        let cy = cos(rodBaseYaw), sy = sin(rodBaseYaw)
        let cp = cos(rodBasePitch), sp = sin(rodBasePitch)
        let forward = SIMD3<Float>(sy * cp, sp, -cy * cp)
        let right = simd_normalize(simd_cross(forward, SIMD3<Float>(0, 1, 0)))
        let up = simd_cross(right, forward)
        return simd_float3x3(columns: (right, up, -forward))
    }

    private func stepFishingLineXPBD(
        dt: Float,
        reelSpeed: Float,
        externalFishPull: SIMD3<Float>,
        terrainHeightAt: (Float, Float) -> Float,
        events: inout PhysicsStepEvents
    ) -> (tipForce: SIMD3<Float>, tensionNewtons: Float) {
        let n = Self.lineNodeCount
        let rodTip = rodNodesWorld[Self.rodNodeCount - 1]
        let gravity = SIMD3<Float>(0.0, -9.81, 0.0)

        linePositions[0] = rodTip
        linePrevPositions[0] = rodTip

        for i in 1..<n {
            let pos = linePositions[i]
            let prev = linePrevPositions[i]
            var vel = (pos - prev) / dt
            let isSubmerged = pos.y < waterSurfaceY
            let isLure = (i == n - 1)

            var accel = gravity
            if isSubmerged {
                let buoyancyFactor: Float = isLure ? lureBuoyancyFactor(activeLureType) : 0.92
                accel.y += 9.81 * buoyancyFactor
                let relVel = vel - waterCurrentVelocity
                let relSpeed = simd_length(relVel)
                let dragCoeff: Float = isLure ? 2.4 : 4.2
                accel -= relVel * (dragCoeff * (0.4 + relSpeed))

                if isLure {
                    let horizSpeed = simd_length(SIMD2<Float>(relVel.x, relVel.z))
                    switch activeLureType {
                    case .minnowHardbait:
                        accel.y -= min(11.5, horizSpeed * 3.8)
                    case .jigheadSoftWorm:
                        accel.y += twitchImpulseDecay * 5.2 - 1.4
                    case .metalSpoon:
                        accel.y -= min(6.0, horizSpeed * 1.6) - sin(wobblePhase * 2.0) * 1.2
                    }
                    accel += externalFishPull / 0.085
                }
            } else {
                let relAir = vel - windVelocity
                let airDrag: Float = isLure ? 0.12 : 0.85
                accel -= relAir * airDrag
            }

            vel += accel * dt
            let damping: Float = isSubmerged ? 0.985 : 0.996
            vel *= damping

            linePrevPositions[i] = pos
            linePositions[i] = pos + vel * dt

            let bedY = terrainHeightAt(linePositions[i].x, linePositions[i].z)
            if linePositions[i].y < bedY + 0.06 {
                linePositions[i].y = bedY + 0.06
            }
        }

        let segmentRestLen = lineOutLength / Float(n - 1)
        let compliance: Float = 1.0e-5 / max(dt * dt, 1.0e-6)
        var maxStretch: Float = 0.0

        if !isLineBroken {
            for _ in 0..<6 {
                linePositions[0] = rodTip
                for i in 0..<(n - 1) {
                    let p0 = linePositions[i]
                    let p1 = linePositions[i + 1]
                    let delta = p1 - p0
                    let dist = simd_length(delta)
                    guard dist > 1e-6 else { continue }

                    let diff = dist - segmentRestLen
                    if diff > 0.0 {
                        if i == 0 {
                            maxStretch = max(maxStretch, diff)
                        }
                        let w0: Float = (i == 0) ? 0.0 : 1.0
                        let w1: Float = (i + 1 == n - 1) ? 0.35 : 1.0
                        let wSum = w0 + w1 + compliance
                        let corr = (delta / dist) * (diff / wSum)
                        linePositions[i] += corr * w0
                        linePositions[i + 1] -= corr * w1
                    }
                }
            }
        }

        let lurePos = linePositions[n - 1]
        let lureVel = (lurePos - linePrevPositions[n - 1]) / dt
        let nowSubmerged = lurePos.y < waterSurfaceY

        if nowSubmerged && !lureSubmergedLastFrame {
            let impactSpeed = abs(lureVel.y)
            if impactSpeed > 1.2 {
                events.lureJustSplashed = true
                events.splashImpactSpeed = impactSpeed
                isBailOpen = false
            }
        }
        lureSubmergedLastFrame = nowSubmerged

        let speedMag = simd_length(lureVel)
        let effectiveRetrieve = max(speedMag, reelSpeed)
        wobblePhase += dt * (4.5 + effectiveRetrieve * 7.8 + twitchImpulseDecay * 6.0)

        let (wobbleAmp, rollAmp): (Float, Float)
        switch activeLureType {
        case .minnowHardbait:
            wobbleAmp = min(0.42, 0.08 + effectiveRetrieve * 0.14)
            rollAmp = min(0.55, 0.10 + effectiveRetrieve * 0.18)
        case .jigheadSoftWorm:
            wobbleAmp = min(0.28, 0.04 + twitchImpulseDecay * 0.16)
            rollAmp = min(0.20, 0.03 + effectiveRetrieve * 0.06)
        case .metalSpoon:
            wobbleAmp = min(0.62, 0.14 + effectiveRetrieve * 0.22)
            rollAmp = min(0.85, 0.20 + effectiveRetrieve * 0.28)
        }

        let depth = max(0.0, waterSurfaceY - lurePos.y)
        let surfaceProximity = max(0.0, 1.0 - depth / 0.65)
        lureState = LureDynamicsOutput(
            position: lurePos,
            velocity: lureVel,
            depthBelowSurface: depth,
            wobbleAngleRad: sin(wobblePhase) * wobbleAmp,
            rollAngleRad: cos(wobblePhase * 1.15) * rollAmp,
            surfaceRippleIntensity: nowSubmerged ? min(1.0, surfaceProximity * effectiveRetrieve * 0.45) : 0.0,
            isSubmerged: nowSubmerged
        )

        let tipToNext = linePositions[1] - rodTip
        let tipDir = simd_length_squared(tipToNext) > 1e-8 ? simd_normalize(tipToNext) : SIMD3<Float>(0, -1, 0)
        let stretchTension = maxStretch * 195.0
        let fishMag = simd_length(externalFishPull)
        let retrieveDragTension = nowSubmerged ? (effectiveRetrieve * 2.4 + twitchImpulseDecay * 3.5) : 0.4
        let totalTension = max(0.0, stretchTension + fishMag + retrieveDragTension)

        return (tipDir * totalTension, totalTension)
    }

    private func lureBuoyancyFactor(_ type: LureType) -> Float {
        switch type {
        case .minnowHardbait: return 0.96
        case .jigheadSoftWorm: return 0.45
        case .metalSpoon: return 0.30
        }
    }
}
