import Foundation
import simd

public enum RodPower: Int, CaseIterable, Sendable, Identifiable {
    case ultraLight = 0
    case mediumLight = 1
    case mediumHeavy = 2

    public var id: Int { rawValue }

    public var shortCode: String {
        switch self {
        case .ultraLight: return "UL"
        case .mediumLight: return "ML"
        case .mediumHeavy: return "MH"
        }
    }

    public var maxBendRadians: Float {
        switch self {
        case .ultraLight: return 1.18  // ~68 deg graceful parabolic bend
        case .mediumLight: return 0.96 // ~55 deg medium-fast arc
        case .mediumHeavy: return 0.76 // ~44 deg stiff heavy backbone
        }
    }

    public var taperExponent: Float {
        switch self {
        case .ultraLight: return 2.15
        case .mediumLight: return 2.65
        case .mediumHeavy: return 3.20
        }
    }
}

public struct LureDynamicsOutput: Sendable {
    public var position: SIMD3<Float>
    public var velocity: SIMD3<Float>
    public var depthBelowSurface: Float
    public var wobbleAngleRad: Float
    public var rollAngleRad: Float
    public var surfaceRippleIntensity: Float
    public var isSubmerged: Bool
}

public struct PhysicsStepEvents: Sendable {
    public var lureJustSplashed: Bool = false
    public var splashImpactSpeed: Float = 0.0
    public var dragSlipSpeedMetersPerSec: Float = 0.0
    public var dragClickRateHz: Float = 0.0
    public var lineJustBroke: Bool = false
    public var lineTensionNewtons: Float = 0.0
    public var normalizedTension: Float = 0.0
}

@MainActor
public final class RodAndLinePhysics {
    public static let rodSegmentCount = 16
    public static let rodNodeCount = 17
    public static let lineNodeCount = 32

    public var rodPower: RodPower = .mediumLight
    public let rodLength: Float = 2.40
    public let guideFractions: [Float] = [0.34, 0.46, 0.57, 0.67, 0.76, 0.84, 0.92, 0.996]

    public var rodButtWorldPosition: SIMD3<Float> = SIMD3<Float>(0.22, 1.48, 24.3)
    public var rodBaseYaw: Float = 0.0
    public var rodBasePitch: Float = 0.52
    public private(set) var rodNodesWorld: [SIMD3<Float>]
    public private(set) var rodTangentsWorld: [SIMD3<Float>]
    public private(set) var guideWorldPositions: [SIMD3<Float>]

    // Smooth global & modal elastic rod animation state (prevents noodle over-bending)
    public var isPumpingRod: Bool = false
    public var castChargeAmount: Float = 0.0
    public var landingLiftAmount: Float = 0.0 // 0..1 during 3D landing sequence

    private var castWhipTimer: Float = 0.0
    private var castWhipPower: Float = 0.0
    private var currentPitchOffset: Float = 0.0
    private var currentBendPitch: Float = 0.0
    private var currentBendYaw: Float = 0.0
    private var bendPitchVel: Float = 0.0
    private var bendYawVel: Float = 0.0
    private var tipVibrationPhase: Float = 0.0
    private var tipVibrationAmp: Float = 0.0

    // 32-node XPBD / Verlet Fishing Line
    public private(set) var linePositions: [SIMD3<Float>]
    private var linePrevPositions: [SIMD3<Float>]
    public private(set) var lineOutLength: Float = 14.0
    public let minLineOutLength: Float = 1.6
    public let maxSpoolCapacity: Float = 110.0

    public var maxLineBreakNewtons: Float = 52.0
    public var dragSettingNormalized: Float = 0.55
    public private(set) var isLineBroken: Bool = false
    public private(set) var isBailOpen: Bool = false
    private var smoothedTensionN: Float = 0.0
    private var lineOverloadSeconds: Float = 0.0

    public var waterSurfaceY: Float = 0.0
    public var windVelocity: SIMD3<Float> = SIMD3<Float>(1.1, 0.0, -0.6)
    public var waterCurrentVelocity: SIMD3<Float> = SIMD3<Float>(0.32, 0.0, -0.16)

    public var activeLureType: LureType = .minnowHardbait
    public private(set) var lureState: LureDynamicsOutput
    private var lureSubmergedLastFrame: Bool = false
    private var wobblePhase: Float = 0.0
    private var twitchImpulseDecay: Float = 0.0

    public init() {
        self.rodNodesWorld = [SIMD3<Float>](repeating: .zero, count: Self.rodNodeCount)
        self.rodTangentsWorld = [SIMD3<Float>](repeating: SIMD3<Float>(0, 0, -1), count: Self.rodNodeCount)
        self.guideWorldPositions = [SIMD3<Float>](repeating: .zero, count: 8)
        self.linePositions = [SIMD3<Float>](repeating: .zero, count: Self.lineNodeCount)
        self.linePrevPositions = [SIMD3<Float>](repeating: .zero, count: Self.lineNodeCount)
        self.lureState = LureDynamicsOutput(
            position: SIMD3<Float>(0.0, -0.8, 12.0),
            velocity: .zero,
            depthBelowSurface: 0.8,
            wobbleAngleRad: 0.0,
            rollAngleRad: 0.0,
            surfaceRippleIntensity: 0.0,
            isSubmerged: true
        )

        resetRigToReadyPosition()
    }

    public func resetRigToReadyPosition() {
        isLineBroken = false
        isBailOpen = false
        smoothedTensionN = 0.0
        lineOverloadSeconds = 0.0
        isPumpingRod = false
        castChargeAmount = 0.0
        landingLiftAmount = 0.0
        castWhipTimer = 0.0
        currentPitchOffset = 0.0
        currentBendPitch = 0.0
        currentBendYaw = 0.0
        bendPitchVel = 0.0
        bendYawVel = 0.0
        tipVibrationAmp = 0.0
        lineOutLength = 12.0

        integrateRodGeometry()
        let tip = rodNodesWorld[Self.rodNodeCount - 1]
        let lurePos = tip + SIMD3<Float>(0.0, -2.6, -9.8)
        for i in 0..<Self.lineNodeCount {
            let t = Float(i) / Float(Self.lineNodeCount - 1)
            let p = simd_mix(tip, lurePos, SIMD3<Float>(repeating: t))
            linePositions[i] = p
            linePrevPositions[i] = p
        }
        lureState.position = lurePos
        lureState.velocity = .zero
        lureSubmergedLastFrame = lurePos.y < waterSurfaceY
    }

    public func launchCast(powerNormalized: Float, aimYawOffset: Float, elevationRad: Float) {
        isLineBroken = false
        isBailOpen = true
        let clampedPower = max(0.20, min(1.0, powerNormalized))
        let launchSpeed = 11.0 + clampedPower * 22.0

        // Trigger crisp forward cast whip animation on the rod
        castChargeAmount = 0.0
        castWhipTimer = 0.42
        castWhipPower = clampedPower
        tipVibrationAmp = 0.08 * clampedPower

        let tip = rodNodesWorld[Self.rodNodeCount - 1]
        let yaw = rodBaseYaw + aimYawOffset
        let elev = max(0.24, min(0.84, elevationRad))
        let dir = simd_normalize(SIMD3<Float>(
            sin(yaw) * cos(elev),
            sin(elev),
            -cos(yaw) * cos(elev)
        ))

        lineOutLength = 2.2
        for i in 0..<Self.lineNodeCount {
            let t = Float(i) / Float(Self.lineNodeCount - 1)
            let p = tip + dir * (t * 0.45)
            linePositions[i] = p
            linePrevPositions[i] = p - dir * (launchSpeed * t * (1.0 / 60.0))
        }
        lureState.position = linePositions[Self.lineNodeCount - 1]
        lureState.velocity = dir * launchSpeed
        lureSubmergedLastFrame = false
    }

    public func triggerRodTwitch(strength: Float = 1.0) {
        let s = max(0.2, min(1.5, strength))
        twitchImpulseDecay = min(1.5, twitchImpulseDecay + s)
        bendPitchVel += 4.2 * s
        tipVibrationAmp = min(0.12, tipVibrationAmp + 0.045 * s)
    }

    /// Overrides lure & line end position cleanly during the 3D landing-to-net animation
    public func pinLureForLandingAnimation(fishWorldPos: SIMD3<Float>) {
        let n = Self.lineNodeCount
        let tip = rodNodesWorld[Self.rodNodeCount - 1]
        for i in 0..<n {
            let t = Float(i) / Float(n - 1)
            let sag = sin(t * Float.pi) * 0.06
            var p = simd_mix(tip, fishWorldPos, SIMD3<Float>(repeating: t))
            p.y -= sag
            linePositions[i] = p
            linePrevPositions[i] = p
        }
        lureState.position = fishWorldPos
        lureState.velocity = .zero
        lureState.depthBelowSurface = max(0.0, waterSurfaceY - fishWorldPos.y)
        lureState.isSubmerged = fishWorldPos.y < waterSurfaceY
    }

    public func step(
        deltaTime rawDt: Float,
        reelSpeedMetersPerSec: Float,
        externalFishPullForce: SIMD3<Float>,
        terrainHeightAt: (Float, Float) -> Float
    ) -> PhysicsStepEvents {
        let dt = min(max(rawDt, 1.0 / 240.0), 1.0 / 30.0)
        var events = PhysicsStepEvents()
        twitchImpulseDecay = max(0.0, twitchImpulseDecay - dt * 2.8)

        if reelSpeedMetersPerSec > 0.05 && isBailOpen {
            isBailOpen = false
        }

        if !isLineBroken {
            if isBailOpen {
                let tip = rodNodesWorld[Self.rodNodeCount - 1]
                let distToLure = simd_distance(tip, linePositions[Self.lineNodeCount - 1])
                lineOutLength = min(maxSpoolCapacity, max(lineOutLength, distToLure + 0.15))
            } else if reelSpeedMetersPerSec > 0.001 {
                lineOutLength = max(minLineOutLength, lineOutLength - reelSpeedMetersPerSec * dt)
            }
        }

        let (tipTensionVec, tensionMag) = stepFishingLineXPBD(
            dt: dt,
            reelSpeed: reelSpeedMetersPerSec,
            externalFishPull: externalFishPullForce,
            terrainHeightAt: terrainHeightAt,
            events: &events
        )

        // Smooth low-pass tension filter prevents 1-frame XPBD jitter from ever snapping the line
        let dragLimit = max(3.5, maxLineBreakNewtons * 0.90 * max(0.05, min(1.0, dragSettingNormalized)))
        var effectiveTension = tensionMag
        if !isLineBroken && !isBailOpen {
            if effectiveTension > dragLimit {
                let excessForce = effectiveTension - dragLimit
                let slipSpeed = min(12.0, 0.40 + excessForce * 0.28)
                lineOutLength = min(maxSpoolCapacity, lineOutLength + slipSpeed * dt)
                events.dragSlipSpeedMetersPerSec = slipSpeed
                events.dragClickRateHz = min(58.0, 10.0 + slipSpeed * 7.0)
                // Working drag clutch relieves excess load so line only approaches break if drag is nearly locked (>85%)
                effectiveTension = dragLimit + excessForce * (0.18 + 0.65 * max(0.0, dragSettingNormalized - 0.72))
            }
            smoothedTensionN += (effectiveTension - smoothedTensionN) * min(1.0, dt * 10.0)
            // Require sustained critical overload (>1.25s) to break line, giving angler fair warning to lower drag
            if smoothedTensionN > maxLineBreakNewtons * 0.94 && dragSettingNormalized > 0.82 {
                lineOverloadSeconds += dt
                if lineOverloadSeconds >= 1.25 {
                    isLineBroken = true
                    events.lineJustBroke = true
                }
            } else {
                lineOverloadSeconds = max(0.0, lineOverloadSeconds - dt * 1.6)
            }
        } else {
            smoothedTensionN += (0.0 - smoothedTensionN) * min(1.0, dt * 10.0)
            lineOverloadSeconds = 0.0
        }

        events.lineTensionNewtons = isLineBroken ? 0.0 : smoothedTensionN
        events.normalizedTension = isLineBroken ? 0.0 : min(1.0, smoothedTensionN / max(maxLineBreakNewtons, 1.0))

        let tipDirNorm = simd_length_squared(tipTensionVec) > 1e-8 ? simd_normalize(tipTensionVec) : SIMD3<Float>(0, -1, 0)
        let effectiveTipForce = isLineBroken ? .zero : (tipDirNorm * smoothedTensionN)
        stepRodCantilever(dt: dt, tipForceWorld: effectiveTipForce, normalizedTension: events.normalizedTension)

        return events
    }

    // MARK: - Physically Bounded Parabolic / Fast-Action 16-Segment Rod Dynamics

    private func stepRodCantilever(dt: Float, tipForceWorld: SIMD3<Float>, normalizedTension: Float) {
        // 1. Base handle pitch animation: Cast Cocking -> Forward Whip -> Pump Lift -> Landing Lift
        var desiredPitchOffset: Float = 0.0
        if landingLiftAmount > 0.001 {
            // High upward lift to hoist fish cleanly out of water
            desiredPitchOffset = 0.56 * landingLiftAmount
        } else if castChargeAmount > 0.01 {
            // Cock rod back smoothly while charging cast
            desiredPitchOffset = 0.52 * castChargeAmount
        } else if castWhipTimer > 0.0 {
            castWhipTimer = max(0.0, castWhipTimer - dt)
            let p = 1.0 - (castWhipTimer / 0.42)
            // Forward snap downward then elastic settle
            desiredPitchOffset = -0.34 * castWhipPower * sin(p * Float.pi)
        } else if isPumpingRod {
            desiredPitchOffset = 0.34
        } else if twitchImpulseDecay > 0.01 {
            desiredPitchOffset = 0.22 * min(1.0, twitchImpulseDecay)
        }

        currentPitchOffset += (desiredPitchOffset - currentPitchOffset) * min(1.0, dt * 11.0)

        // 2. Transform tip pull into rod local frame to compute natural bend direction & magnitude
        let baseFrame = rodBaseBasis(extraPitch: currentPitchOffset)
        let invRot = simd_transpose(baseFrame)
        let forceLocal = invRot * tipForceWorld
        let forceLen = simd_length(forceLocal)
        let forceDir = forceLen > 0.001 ? (forceLocal / forceLen) : SIMD3<Float>(0, -1, 0)

        // Realistic bounded elastic arc: never folds straight down like a limp noodle!
        let maxArc = rodPower.maxBendRadians
        let loadFactor = max(normalizedTension, landingLiftAmount * 0.62)
        var targetBendPitch = forceDir.y * maxArc * pow(loadFactor, 0.72)
        var targetBendYaw = forceDir.x * maxArc * 0.58 * pow(loadFactor, 0.72)

        // Backward elastic flex during cast charge & forward whip flex during release
        if castChargeAmount > 0.01 {
            targetBendPitch = 0.26 * castChargeAmount
            targetBendYaw = 0.0
        } else if castWhipTimer > 0.0 {
            let p = 1.0 - (castWhipTimer / 0.42)
            targetBendPitch = -0.32 * castWhipPower * sin(p * Float.pi)
        }

        targetBendPitch = max(-maxArc, min(maxArc * 0.45, targetBendPitch))
        targetBendYaw = max(-maxArc * 0.65, min(maxArc * 0.65, targetBendYaw))

        // Critically damped spring for crisp carbon-fiber feel
        let stiffness: Float = 54.0
        let damping: Float = 11.2
        let accP = (targetBendPitch - currentBendPitch) * stiffness - bendPitchVel * damping
        let accY = (targetBendYaw - currentBendYaw) * stiffness - bendYawVel * damping

        bendPitchVel += accP * dt
        bendYawVel += accY * dt
        currentBendPitch = max(-maxArc * 1.08, min(maxArc * 0.5, currentBendPitch + bendPitchVel * dt))
        currentBendYaw = max(-maxArc * 0.7, min(maxArc * 0.7, currentBendYaw + bendYawVel * dt))

        // Subtle high-frequency tip tremor when fighting a hooked fish
        tipVibrationPhase += dt * (22.0 + normalizedTension * 18.0)
        tipVibrationAmp = max(normalizedTension * 0.035, tipVibrationAmp * exp(-dt * 4.5))

        integrateRodGeometry()
    }

    private func integrateRodGeometry() {
        let baseFrame = rodBaseBasis(extraPitch: currentPitchOffset)
        let segLen = rodLength / Float(Self.rodSegmentCount)
        let taperExp = rodPower.taperExponent

        // Distribute total bend across the 16 segments weighted by taper (stiff butt -> flexible tip)
        var weights = [Float](repeating: 0.0, count: Self.rodSegmentCount)
        var weightSum: Float = 0.0
        for i in 0..<Self.rodSegmentCount {
            let s = (Float(i) + 0.5) / Float(Self.rodSegmentCount)
            // First 22% (handle & reel seat) stays completely rigid
            let w: Float = s < 0.22 ? 0.0 : pow((s - 0.22) / 0.78, taperExp * 0.55)
            weights[i] = w
            weightSum += w
        }
        let invSum = 1.0 / max(weightSum, 0.0001)

        var pos = rodButtWorldPosition
        var cumPitch: Float = 0.0
        var cumYaw: Float = 0.0

        rodNodesWorld[0] = pos
        rodTangentsWorld[0] = baseFrame * SIMD3<Float>(0, 0, -1)

        for i in 0..<Self.rodSegmentCount {
            let wNorm = weights[i] * invSum
            let s = Float(i + 1) / Float(Self.rodSegmentCount)
            let vib = sin(tipVibrationPhase) * tipVibrationAmp * (s * s) * wNorm

            cumPitch += currentBendPitch * wNorm + vib
            cumYaw += currentBendYaw * wNorm + vib * 0.45

            let localDir = SIMD3<Float>(
                sin(cumYaw) * cos(cumPitch),
                sin(cumPitch),
                -cos(cumYaw) * cos(cumPitch)
            )
            let worldDir = simd_normalize(baseFrame * localDir)
            pos += worldDir * segLen
            rodNodesWorld[i + 1] = pos
            rodTangentsWorld[i + 1] = worldDir
        }

        for (idx, frac) in guideFractions.enumerated() {
            let fIndex = frac * Float(Self.rodSegmentCount)
            let i0 = max(0, min(Self.rodSegmentCount - 1, Int(floor(fIndex))))
            let i1 = min(Self.rodSegmentCount, i0 + 1)
            let alpha = fIndex - Float(i0)
            let p = simd_mix(rodNodesWorld[i0], rodNodesWorld[i1], SIMD3<Float>(repeating: alpha))
            let t = simd_normalize(simd_mix(rodTangentsWorld[i0], rodTangentsWorld[i1], SIMD3<Float>(repeating: alpha)))
            let downOffset = simd_normalize(simd_cross(t, SIMD3<Float>(1, 0, 0))) * -0.012
            guideWorldPositions[idx] = p + downOffset
        }
    }

    public func deformRodVertex(localPosition: SIMD3<Float>) -> SIMD3<Float> {
        let frac = max(0.0, min(1.0, localPosition.z / rodLength))
        let fIndex = frac * Float(Self.rodSegmentCount)
        let i0 = max(0, min(Self.rodSegmentCount - 1, Int(floor(fIndex))))
        let i1 = min(Self.rodSegmentCount, i0 + 1)
        let alpha = fIndex - Float(i0)

        let center = simd_mix(rodNodesWorld[i0], rodNodesWorld[i1], SIMD3<Float>(repeating: alpha))
        let forward = simd_normalize(simd_mix(rodTangentsWorld[i0], rodTangentsWorld[i1], SIMD3<Float>(repeating: alpha)))
        let right = simd_normalize(simd_cross(forward, SIMD3<Float>(0, 1, 0)))
        let up = simd_cross(right, forward)
        return center + right * localPosition.x + up * localPosition.y
    }

    private func rodBaseBasis(extraPitch: Float) -> simd_float3x3 {
        let pitch = max(-0.2, min(1.38, rodBasePitch + extraPitch))
        let cy = cos(rodBaseYaw), sy = sin(rodBaseYaw)
        let cp = cos(pitch), sp = sin(pitch)
        let forward = SIMD3<Float>(sy * cp, sp, -cy * cp)
        let right = simd_normalize(simd_cross(forward, SIMD3<Float>(0, 1, 0)))
        let up = simd_cross(right, forward)
        return simd_float3x3(columns: (right, up, -forward))
    }

    // MARK: - 32-Node XPBD / Verlet Fishing Line & Lure Hydrodynamics

    private func stepFishingLineXPBD(
        dt: Float,
        reelSpeed: Float,
        externalFishPull: SIMD3<Float>,
        terrainHeightAt: (Float, Float) -> Float,
        events: inout PhysicsStepEvents
    ) -> (tipForce: SIMD3<Float>, tensionNewtons: Float) {
        let n = Self.lineNodeCount
        let rodTip = rodNodesWorld[Self.rodNodeCount - 1]
        let gravity = SIMD3<Float>(0.0, -9.81, 0.0)

        linePositions[0] = rodTip
        linePrevPositions[0] = rodTip

        for i in 1..<n {
            let pos = linePositions[i]
            let prev = linePrevPositions[i]
            var vel = (pos - prev) / dt
            let isSubmerged = pos.y < waterSurfaceY
            let isLure = (i == n - 1)

            var accel = gravity
            if isSubmerged {
                let buoyancyFactor: Float = isLure ? lureBuoyancyFactor(activeLureType) : 0.92
                accel.y += 9.81 * buoyancyFactor
                let relVel = vel - waterCurrentVelocity
                let relSpeed = simd_length(relVel)
                let dragCoeff: Float = isLure ? 2.4 : 4.2
                accel -= relVel * (dragCoeff * (0.4 + relSpeed))

                if isLure {
                    let horizSpeed = simd_length(SIMD2<Float>(relVel.x, relVel.z))
                    switch activeLureType {
                    case .minnowHardbait:
                        accel.y -= min(11.5, horizSpeed * 3.8)
                    case .jigheadSoftWorm:
                        accel.y += twitchImpulseDecay * 5.2 - 1.4
                    case .metalSpoon:
                        accel.y -= min(6.0, horizSpeed * 1.6) - sin(wobblePhase * 2.0) * 1.2
                    }
                    accel += externalFishPull / 0.085
                }
            } else {
                let relAir = vel - windVelocity
                let airDrag: Float = isLure ? 0.12 : 0.85
                accel -= relAir * airDrag
            }

            vel += accel * dt
            let damping: Float = isSubmerged ? 0.985 : 0.996
            vel *= damping

            linePrevPositions[i] = pos
            linePositions[i] = pos + vel * dt

            let bedY = terrainHeightAt(linePositions[i].x, linePositions[i].z)
            if linePositions[i].y < bedY + 0.06 {
                linePositions[i].y = bedY + 0.06
            }
        }

        let segmentRestLen = lineOutLength / Float(n - 1)
        let compliance: Float = 1.0e-5 / max(dt * dt, 1.0e-6)
        var maxStretch: Float = 0.0

        if !isLineBroken {
            for _ in 0..<6 {
                linePositions[0] = rodTip
                for i in 0..<(n - 1) {
                    let p0 = linePositions[i]
                    let p1 = linePositions[i + 1]
                    let delta = p1 - p0
                    let dist = simd_length(delta)
                    guard dist > 1e-6 else { continue }

                    let diff = dist - segmentRestLen
                    if diff > 0.0 {
                        if i == 0 {
                            maxStretch = max(maxStretch, diff)
                        }
                        let w0: Float = (i == 0) ? 0.0 : 1.0
                        let w1: Float = (i + 1 == n - 1) ? 0.35 : 1.0
                        let wSum = w0 + w1 + compliance
                        let corr = (delta / dist) * (diff / wSum)
                        linePositions[i] += corr * w0
                        linePositions[i + 1] -= corr * w1
                    }
                }
            }
        }

        let lurePos = linePositions[n - 1]
        let lureVel = (lurePos - linePrevPositions[n - 1]) / dt
        let nowSubmerged = lurePos.y < waterSurfaceY

        if nowSubmerged && !lureSubmergedLastFrame {
            let impactSpeed = abs(lureVel.y)
            if impactSpeed > 1.2 {
                events.lureJustSplashed = true
                events.splashImpactSpeed = impactSpeed
                isBailOpen = false
            }
        }
        lureSubmergedLastFrame = nowSubmerged

        let speedMag = simd_length(lureVel)
        let effectiveRetrieve = max(speedMag, reelSpeed)
        wobblePhase += dt * (4.5 + effectiveRetrieve * 7.8 + twitchImpulseDecay * 6.0)

        let (wobbleAmp, rollAmp): (Float, Float)
        switch activeLureType {
        case .minnowHardbait:
            wobbleAmp = min(0.42, 0.08 + effectiveRetrieve * 0.14)
            rollAmp = min(0.55, 0.10 + effectiveRetrieve * 0.18)
        case .jigheadSoftWorm:
            wobbleAmp = min(0.28, 0.04 + twitchImpulseDecay * 0.16)
            rollAmp = min(0.20, 0.03 + effectiveRetrieve * 0.06)
        case .metalSpoon:
            wobbleAmp = min(0.62, 0.14 + effectiveRetrieve * 0.22)
            rollAmp = min(0.85, 0.20 + effectiveRetrieve * 0.28)
        }

        let depth = max(0.0, waterSurfaceY - lurePos.y)
        let surfaceProximity = max(0.0, 1.0 - depth / 0.65)
        lureState = LureDynamicsOutput(
            position: lurePos,
            velocity: lureVel,
            depthBelowSurface: depth,
            wobbleAngleRad: sin(wobblePhase) * wobbleAmp,
            rollAngleRad: cos(wobblePhase * 1.15) * rollAmp,
            surfaceRippleIntensity: nowSubmerged ? min(1.0, surfaceProximity * effectiveRetrieve * 0.45) : 0.0,
            isSubmerged: nowSubmerged
        )

        let tipToNext = linePositions[1] - rodTip
        let tipDir = simd_length_squared(tipToNext) > 1e-8 ? simd_normalize(tipToNext) : SIMD3<Float>(0, -1, 0)
        let stretchTension = min(22.0, maxStretch * 42.0)
        let fishMag = simd_length(externalFishPull)
        let pumpBonus: Float = isPumpingRod ? 5.5 : 0.0
        let retrieveDragTension = nowSubmerged ? (effectiveRetrieve * 2.4 + twitchImpulseDecay * 3.5 + pumpBonus) : 0.4
        let totalTension = max(0.0, stretchTension + fishMag + retrieveDragTension)

        return (tipDir * totalTension, totalTension)
    }

    private func lureBuoyancyFactor(_ type: LureType) -> Float {
        switch type {
        case .minnowHardbait: return 0.96
        case .jigheadSoftWorm: return 0.45
        case .metalSpoon: return 0.30
        }
    }
}
