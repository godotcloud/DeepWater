import Foundation
import Metal
import simd

@MainActor
public final class SchoolingManager {
    public let baitfishCount: Int
    public let targetFishCount: Int
    public let maxPredatorThreats: Int = 64

    public static let spatialHashTableSize: Int = 4096
    public static let spatialHashMaxPerCell: Int = 16

    public let ecosystem: EcosystemEngine
    public let aiManager: FishAIManager

    private var clearHashPSO: MTLComputePipelineState?
    private var buildHashPSO: MTLComputePipelineState?
    private var stepBoidsPSO: MTLComputePipelineState?

    private var boidBuffers: [MTLBuffer] = []
    private var readBufferIndex: Int = 0

    private var hashCountsBuffer: MTLBuffer?
    private var hashIndicesBuffer: MTLBuffer?

    private var predatorBuffer: MTLBuffer?
    public private(set) var baitfishInstanceBuffer: MTLBuffer?
    public private(set) var targetFishInstanceBuffer: MTLBuffer?
    public private(set) var splashEventBuffer: MTLBuffer?

    private var elapsedTime: Float = 0.0

    public init?(
        device: MTLDevice,
        baitfishCount: Int = 320,
        targetFishCount: Int = 40,
        ecosystem: EcosystemEngine,
        terrainHeightAt: (Float, Float) -> Float
    ) {
        self.baitfishCount = baitfishCount
        self.targetFishCount = targetFishCount
        self.ecosystem = ecosystem
        self.aiManager = FishAIManager(count: targetFishCount, ecosystem: ecosystem, terrainHeightAt: terrainHeightAt)

        guard buildPipelines(device: device),
              allocateBuffers(device: device, terrainHeightAt: terrainHeightAt) else {
            return nil
        }
    }

    private func buildPipelines(device: MTLDevice) -> Bool {
        guard let library = device.makeDefaultLibrary(),
              let clearFn = library.makeFunction(name: "clearSpatialHashKernel"),
              let buildFn = library.makeFunction(name: "buildSpatialHashKernel"),
              let stepFn = library.makeFunction(name: "stepBoidsKernel") else {
            return false
        }
        do {
            clearHashPSO = try device.makeComputePipelineState(function: clearFn)
            buildHashPSO = try device.makeComputePipelineState(function: buildFn)
            stepBoidsPSO = try device.makeComputePipelineState(function: stepFn)
            return true
        } catch {
            return false
        }
    }

    private func allocateBuffers(device: MTLDevice, terrainHeightAt: (Float, Float) -> Float) -> Bool {
        var initialBoids: [BoidAgent] = []
        initialBoids.reserveCapacity(baitfishCount)
        let attractor = ecosystem.activeBaitfishAttractor

        var seed: UInt64 = 0xB01D_5C40_0123
        func rand01() -> Float {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Float((seed >> 33) & 0x7FFF_FFFF) / Float(0x7FFF_FFFF)
        }

        for i in 0..<baitfishCount {
            let schoolCluster = Float(i % 4)
            let clusterOffset = SIMD3<Float>(
                cos(schoolCluster * 1.57) * 7.5,
                -0.6 - schoolCluster * 0.55,
                sin(schoolCluster * 1.57) * 7.5
            )
            let home = attractor + clusterOffset
            let jitter = SIMD3<Float>(
                (rand01() - 0.5) * 6.0,
                (rand01() - 0.5) * 1.6,
                (rand01() - 0.5) * 6.0
            )
            var pos = home + jitter
            let bedY = terrainHeightAt(pos.x, pos.z)
            pos.y = max(bedY + 0.5, min(-0.35, pos.y))

            let yaw = rand01() * 2.0 * Float.pi
            let speed: Float = 0.72 + rand01() * 0.38
            let vel = SIMD3<Float>(cos(yaw) * speed, 0.0, sin(yaw) * speed)

            initialBoids.append(BoidAgent(
                positionAndPhase: SIMD4<Float>(pos.x, pos.y, pos.z, rand01() * 6.2831853),
                velocityAndSpeed: SIMD4<Float>(vel.x, vel.y, vel.z, speed),
                homeAndFear: SIMD4<Float>(home.x, home.y, home.z, 0.0),
                metaParams: SIMD4<Float>(0.24 + rand01() * 0.10, Float(FishSpecies.topmouthCulter.rawValue), 0.0, 1.0)
            ))
        }

        let boidByteSize = MemoryLayout<BoidAgent>.stride * baitfishCount
        guard let b0 = device.makeBuffer(bytes: initialBoids, length: boidByteSize, options: .storageModeShared),
              let b1 = device.makeBuffer(bytes: initialBoids, length: boidByteSize, options: .storageModeShared),
              let counts = device.makeBuffer(length: MemoryLayout<UInt32>.stride * Self.spatialHashTableSize, options: .storageModePrivate),
              let indices = device.makeBuffer(length: MemoryLayout<UInt32>.stride * Self.spatialHashTableSize * Self.spatialHashMaxPerCell, options: .storageModePrivate),
              let predBuf = device.makeBuffer(length: MemoryLayout<PredatorThreat>.stride * maxPredatorThreats, options: .storageModeShared),
              let baitInst = device.makeBuffer(length: MemoryLayout<FishInstanceData>.stride * baitfishCount, options: .storageModePrivate),
              let targetInst = device.makeBuffer(length: MemoryLayout<FishInstanceData>.stride * targetFishCount, options: .storageModeShared),
              let splashBuf = device.makeBuffer(length: MemoryLayout<SplashTriggerEvent>.stride * targetFishCount, options: .storageModeShared) else {
            return false
        }

        b0.label = "BaitfishBoids_A"
        b1.label = "BaitfishBoids_B"
        counts.label = "SpatialHashCounts"
        indices.label = "SpatialHashIndices"
        predBuf.label = "PredatorThreats"
        baitInst.label = "BaitfishInstanceData"
        targetInst.label = "TargetFishInstanceData"
        splashBuf.label = "FishSplashEvents"

        self.boidBuffers = [b0, b1]
        self.hashCountsBuffer = counts
        self.hashIndicesBuffer = indices
        self.predatorBuffer = predBuf
        self.baitfishInstanceBuffer = baitInst
        self.targetFishInstanceBuffer = targetInst
        self.splashEventBuffer = splashBuf
        return true
    }

    public func encodeSimulationPass(
        commandBuffer: MTLCommandBuffer,
        deltaTime rawDt: Float,
        timeOfDayHours: Float,
        lure: LurePerceptionInput,
        anglerPosition: SIMD3<Float>,
        terrainHeightTexture: MTLTexture,
        terrainHalfExtent: Float,
        terrainHeightAt: (Float, Float) -> Float
    ) -> TargetFishTickResult {
        let dt = min(max(rawDt, 0.001), 0.05)
        elapsedTime += dt

        ecosystem.update(deltaTime: dt, timeOfDayHours: timeOfDayHours)

        let (aiResult, targetInstances) = aiManager.step(
            deltaTime: dt,
            ecosystem: ecosystem,
            lure: lure,
            anglerPosition: anglerPosition,
            terrainHeightAt: terrainHeightAt
        )

        if let targetInstBuf = targetFishInstanceBuffer, !targetInstances.isEmpty {
            let byteCount = MemoryLayout<FishInstanceData>.stride * min(targetInstances.count, targetFishCount)
            targetInstances.withUnsafeBytes { raw in
                if let base = raw.baseAddress {
                    memcpy(targetInstBuf.contents(), base, byteCount)
                }
            }
        }

        let threatCount = min(aiResult.predatorThreats.count, maxPredatorThreats)
        if let predBuf = predatorBuffer, threatCount > 0 {
            let byteCount = MemoryLayout<PredatorThreat>.stride * threatCount
            aiResult.predatorThreats.withUnsafeBytes { raw in
                if let base = raw.baseAddress {
                    memcpy(predBuf.contents(), base, byteCount)
                }
            }
        }

        guard let clearPSO = clearHashPSO,
              let buildPSO = buildHashPSO,
              let stepPSO = stepBoidsPSO,
              let countsBuf = hashCountsBuffer,
              let indicesBuf = hashIndicesBuffer,
              let predBuf = predatorBuffer,
              let baitInstBuf = baitfishInstanceBuffer,
              boidBuffers.count == 2,
              let encoder = commandBuffer.makeComputeCommandEncoder() else {
            return aiResult
        }

        encoder.label = "GPUBoidsSpatialHashEncoder"
        let inBuf = boidBuffers[readBufferIndex]
        let outBuf = boidBuffers[1 - readBufferIndex]
        readBufferIndex = 1 - readBufferIndex

        let baseCurrent = ecosystem.currentVelocity(at: ecosystem.activeBaitfishAttractor, seabedY: -8.0)
        var params = BoidsSimParams(
            timeAndCounts: SIMD4<Float>(dt, elapsedTime, Float(baitfishCount), Float(threatCount)),
            currentAndSurface: SIMD4<Float>(baseCurrent.x, baseCurrent.y, baseCurrent.z, 0.0),
            attractorAndClarity: SIMD4<Float>(
                ecosystem.activeBaitfishAttractor.x,
                ecosystem.activeBaitfishAttractor.y,
                ecosystem.activeBaitfishAttractor.z,
                ecosystem.waterClarityMeters
            ),
            weightsAndCell: SIMD4<Float>(2.4, 1.45, 0.95, 2.2),
            radiiAndTerrain: SIMD4<Float>(3.2, 0.95, terrainHalfExtent, 44.0),
            dorsalAndIridescence: SIMD4<Float>(0.22, 0.30, 0.36, 0.95)
        )

        encoder.setComputePipelineState(clearPSO)
        encoder.setBuffer(countsBuf, offset: 0, index: Int(BufferIndex.hashCounts.rawValue))
        dispatch1D(encoder: encoder, pipeline: clearPSO, count: Self.spatialHashTableSize)

        encoder.setComputePipelineState(buildPSO)
        encoder.setBuffer(inBuf, offset: 0, index: Int(BufferIndex.boidsIn.rawValue))
        encoder.setBytes(&params, length: MemoryLayout<BoidsSimParams>.stride, index: Int(BufferIndex.boidsParams.rawValue))
        encoder.setBuffer(countsBuf, offset: 0, index: Int(BufferIndex.hashCounts.rawValue))
        encoder.setBuffer(indicesBuf, offset: 0, index: Int(BufferIndex.hashIndices.rawValue))
        dispatch1D(encoder: encoder, pipeline: buildPSO, count: baitfishCount)

        encoder.setComputePipelineState(stepPSO)
        encoder.setBuffer(inBuf, offset: 0, index: Int(BufferIndex.boidsIn.rawValue))
        encoder.setBuffer(outBuf, offset: 0, index: Int(BufferIndex.boidsOut.rawValue))
        encoder.setBuffer(baitInstBuf, offset: 0, index: Int(BufferIndex.fishInstances.rawValue))
        encoder.setBytes(&params, length: MemoryLayout<BoidsSimParams>.stride, index: Int(BufferIndex.boidsParams.rawValue))
        encoder.setBuffer(countsBuf, offset: 0, index: Int(BufferIndex.hashCounts.rawValue))
        encoder.setBuffer(indicesBuf, offset: 0, index: Int(BufferIndex.hashIndices.rawValue))
        encoder.setBuffer(predBuf, offset: 0, index: Int(BufferIndex.predators.rawValue))
        encoder.setTexture(terrainHeightTexture, index: Int(TextureIndex.terrainHeight.rawValue))
        dispatch1D(encoder: encoder, pipeline: stepPSO, count: baitfishCount)

        encoder.endEncoding()
        return aiResult
    }

    private func dispatch1D(encoder: MTLComputeCommandEncoder, pipeline: MTLComputePipelineState, count: Int) {
        let groupWidth = min(pipeline.maxTotalThreadsPerThreadgroup, max(pipeline.threadExecutionWidth, 64))
        let threadsPerGroup = MTLSize(width: groupWidth, height: 1, depth: 1)
        let gridSize = MTLSize(width: count, height: 1, depth: 1)
        encoder.dispatchThreads(gridSize, threadsPerThreadgroup: threadsPerGroup)
    }
}
