import Foundation
import simd

public enum FishAIState: Int, Sendable {
    case patrol = 0
    case alert = 1
    case investigate = 2
    case follow = 3
    case strike = 4
    case fight = 5
    case exhausted = 6

    public var chineseName: String {
        switch self {
        case .patrol: return "巡游"
        case .alert: return "警觉"
        case .investigate: return "好奇"
        case .follow: return "尾随"
        case .strike: return "攻击"
        case .fight: return "溜鱼挣扎"
        case .exhausted: return "力竭可抄网"
        }
    }
}

public struct TargetFishAgent: Sendable, Identifiable {
    public let id: Int
    public let species: FishSpecies
    public let genome: FishGenome
    public var weightKg: Float
    public var bodyScale: Float

    public var position: SIMD3<Float>
    public var velocity: SIMD3<Float>
    public var forward: SIMD3<Float>
    public var homeAnchor: SIMD3<Float>

    public var state: FishAIState = .patrol
    public var stateTimer: Float = 0.0
    public var suspicion: Float = 0.0
    public var interest: Float = 0.0
    public var stamina: Float = 1.0

    public var swimPhase: Float = 0.0
    public var gillPhase: Float = 0.0
    public var turnCurvature: Float = 0.0
    public var headShakePhase: Float = 0.0
    public var headShakeIntensity: Float = 0.0
    public var isBreaching: Bool = false
    public var breachProgress: Float = 0.0
    public var breachApexHeight: Float = 0.0
    public var isHooked: Bool = false
}

public struct LurePerceptionInput: Sendable {
    public let position: SIMD3<Float>
    public let velocity: SIMD3<Float>
    public let lureType: LureType
    public let wobbleAmplitude: Float
    public let lureColorRGB: SIMD3<Float>
    public let justSplashed: Bool
    public let splashEnergy: Float
    public let isSubmerged: Bool
    public let rodLineTensionN: Float
}

public struct TargetFishTickResult: Sendable {
    public var nibbleTriggered: Bool = false
    public var strikeTriggered: Bool = false
    public var hookedFishID: Int? = nil
    public var hookedFishSpecies: FishSpecies? = nil
    public var hookedFishState: FishAIState? = nil
    public var hookedFishStamina: Float = 1.0
    public var hookedHeadShake: Float = 0.0
    public var externalPullForce: SIMD3<Float> = .zero
    public var predatorThreats: [PredatorThreat] = []
}

@MainActor
public final class FishAIManager {
    public private(set) var targetFish: [TargetFishAgent] = []
    public private(set) var hookedFishIndex: Int? = nil
    private var rngState: UInt64 = 0x5EED_CAFE_1337

    public init(count: Int = 40, ecosystem: EcosystemEngine, terrainHeightAt: (Float, Float) -> Float) {
        spawnPopulation(count: count, ecosystem: ecosystem, terrainHeightAt: terrainHeightAt)
    }

    private func spawnPopulation(count: Int, ecosystem: EcosystemEngine, terrainHeightAt: (Float, Float) -> Float) {
        targetFish.removeAll(keepingCapacity: true)
        let allSpecies = FishSpecies.allCases

        for idx in 0..<count {
            let species = allSpecies[idx % allSpecies.count]
            let genome = FishGenome.genome(for: species)
            let anchor = ecosystem.preferredHabitatAnchor(for: species, seed: idx)

            let angle = nextRandomFloat() * 2.0 * Float.pi
            let r = 2.0 + nextRandomFloat() * 9.0
            let x = max(-42.0, min(42.0, anchor.x + cos(angle) * r))
            let z = max(-42.0, min(14.0, anchor.z + sin(angle) * r))
            let bedY = terrainHeightAt(x, z)
            let y = max(bedY + 0.6, min(-0.5, anchor.y))

            let scale = 0.82 + nextRandomFloat() * 0.56
            let weight = 0.85 * pow(scale, 3.0) * (species == .grouper ? 2.6 : 1.4)

            let heading = nextRandomFloat() * 2.0 * Float.pi
            let fwd = SIMD3<Float>(cos(heading), 0.0, sin(heading))

            let agent = TargetFishAgent(
                id: idx,
                species: species,
                genome: genome,
                weightKg: weight,
                bodyScale: scale,
                position: SIMD3<Float>(x, y, z),
                velocity: fwd * 0.65,
                forward: fwd,
                homeAnchor: anchor,
                swimPhase: nextRandomFloat() * 6.2831853,
                gillPhase: nextRandomFloat() * 6.2831853
            )
            targetFish.append(agent)
        }
    }

    public func releaseHookedFish() {
        if let idx = hookedFishIndex, idx < targetFish.count {
            targetFish[idx].isHooked = false
            targetFish[idx].state = .alert
            targetFish[idx].stateTimer = 0.0
            targetFish[idx].stamina = max(0.35, targetFish[idx].stamina)
        }
        hookedFishIndex = nil
    }

    public func step(
        deltaTime rawDt: Float,
        ecosystem: EcosystemEngine,
        lure: LurePerceptionInput,
        anglerPosition: SIMD3<Float>,
        terrainHeightAt: (Float, Float) -> Float
    ) -> (result: TargetFishTickResult, instanceData: [FishInstanceData]) {
        let dt = min(max(rawDt, 0.001), 0.05)
        var result = TargetFishTickResult()
        var instances: [FishInstanceData] = []
        instances.reserveCapacity(targetFish.count)

        if lure.justSplashed {
            result.predatorThreats.append(PredatorThreat(
                positionAndRadius: SIMD4<Float>(lure.position.x, 0.0, lure.position.z, 6.5 + lure.splashEnergy * 5.0),
                velocityAndIntensity: SIMD4<Float>(0.0, -3.0, 0.0, min(1.0, lure.splashEnergy))
            ))
        }

        let lureSpeed = simd_length(lure.velocity)
        let lateralLineSignalRadius = lure.isSubmerged
            ? (2.2 + lureSpeed * 2.1 + lure.wobbleAmplitude * 4.5 + (lure.justSplashed ? 5.5 : 0.0))
            : (lure.justSplashed ? 7.0 : 0.0)

        for i in 0..<targetFish.count {
            var fish = targetFish[i]
            fish.stateTimer += dt
            fish.gillPhase += dt * (fish.isHooked ? 6.5 : 2.8)

            let bedY = terrainHeightAt(fish.position.x, fish.position.z)
            let hydro = ecosystem.sampleHydrology(at: fish.position, seabedY: bedY)
            let appetite = ecosystem.speciesAppetite(for: fish.species, at: fish.position, seabedY: bedY)

            if Int(fish.stateTimer * 10.0) % 25 == 0 {
                fish.homeAnchor = ecosystem.preferredHabitatAnchor(for: fish.species, seed: fish.id)
            }

            let toLure = lure.position - fish.position
            let distToLure = simd_length(toLure)
            let dirToLure = distToLure > 0.001 ? (toLure / distToLure) : fish.forward

            let visionRange = max(1.8, ecosystem.waterClarityMeters * (0.45 + 0.75 * hydro.lightIrradiance))
            let cosAngle = simd_dot(fish.forward, dirToLure)
            let inVisionCone = (distToLure < visionRange) && (cosAngle > 0.18)
            let inLateralLine = (distToLure < lateralLineSignalRadius)
            let canDetectLure = lure.isSubmerged && (inVisionCone || inLateralLine)

            let lureMatchScore = evaluateLureMatchScore(
                species: fish.species,
                lure: lure,
                lureSpeed: lureSpeed,
                lightIrradiance: hydro.lightIrradiance,
                waterClarity: ecosystem.waterClarityMeters
            )

            var desiredVelocity = fish.velocity
            var behaviorStateCode: Float = 0.0

            switch fish.state {
            case .patrol:
                fish.headShakeIntensity = max(0.0, fish.headShakeIntensity - dt * 3.0)
                fish.stamina = min(1.0, fish.stamina + dt * 0.08)

                let orbitAngle = fish.swimPhase * 0.08 + Float(fish.id) * 1.13
                let patrolPoint = fish.homeAnchor + SIMD3<Float>(cos(orbitAngle) * 4.5, sin(orbitAngle * 0.6) * 0.6, sin(orbitAngle) * 4.5)
                let toPatrol = patrolPoint - fish.position
                let dir = simd_length(toPatrol) > 0.1 ? simd_normalize(toPatrol) : fish.forward
                desiredVelocity = dir * (0.55 + 0.25 * appetite) - hydro.currentVelocity * 0.25

                if lure.justSplashed && distToLure < 4.2 {
                    fish.state = .alert
                    fish.stateTimer = 0.0
                    fish.suspicion = 0.9
                } else if canDetectLure && hookedFishIndex == nil {
                    let curiosity = lureMatchScore * appetite * (inVisionCone ? 1.0 : 0.75)
                    if curiosity > 0.36 {
                        fish.state = .investigate
                        fish.stateTimer = 0.0
                        fish.interest = curiosity
                    }
                }

            case .alert:
                let fleeDir = simd_length(toLure) > 0.01 ? simd_normalize(-toLure + SIMD3<Float>(0, -0.35, 0)) : SIMD3<Float>(0, -0.3, -1)
                desiredVelocity = fleeDir * (2.6 + fish.bodyScale * 0.9)
                fish.suspicion = max(0.0, fish.suspicion - dt * 0.35)
                if fish.stateTimer > 2.4 && fish.suspicion < 0.2 {
                    fish.state = .patrol
                    fish.stateTimer = 0.0
                }

            case .investigate:
                desiredVelocity = dirToLure * (1.05 + 0.45 * fish.interest)
                if !lure.isSubmerged || hookedFishIndex != nil || distToLure > visionRange * 1.45 {
                    fish.state = .patrol
                    fish.stateTimer = 0.0
                } else if distToLure < 2.6 {
                    if lureMatchScore * appetite > 0.48 {
                        fish.state = .follow
                        fish.stateTimer = 0.0
                    } else if fish.stateTimer > 3.2 {
                        fish.state = .alert
                        fish.stateTimer = 0.0
                    }
                }

            case .follow:
                let trailTarget = lure.position - (lureSpeed > 0.1 ? simd_normalize(lure.velocity) * 0.55 : fish.forward * 0.55)
                let toTrail = trailTarget - fish.position
                desiredVelocity = (simd_length(toTrail) > 0.05 ? simd_normalize(toTrail) : dirToLure) * max(1.15, lureSpeed * 1.18)

                if distToLure < 0.95 && fish.stateTimer > 0.6 && fish.stateTimer < 0.65 {
                    result.nibbleTriggered = true
                }

                let strikeProbPerSec = lureMatchScore * appetite * (0.45 + min(1.0, lure.wobbleAmplitude * 1.6)) * 1.35
                if !lure.isSubmerged || hookedFishIndex != nil || distToLure > 5.5 || fish.stateTimer > 5.2 {
                    fish.state = .patrol
                    fish.stateTimer = 0.0
                } else if distToLure < 1.35 && nextRandomFloat() < strikeProbPerSec * dt {
                    fish.state = .strike
                    fish.stateTimer = 0.0
                }

            case .strike:
                desiredVelocity = dirToLure * (3.8 + fish.bodyScale * 1.4)
                behaviorStateCode = 1.0

                if distToLure < 0.45 && hookedFishIndex == nil {
                    fish.isHooked = true
                    fish.state = .fight
                    fish.stateTimer = 0.0
                    fish.stamina = 1.0
                    hookedFishIndex = i
                    result.strikeTriggered = true
                } else if fish.stateTimer > 1.2 || !lure.isSubmerged {
                    fish.state = .patrol
                    fish.stateTimer = 0.0
                }

            case .fight:
                behaviorStateCode = 1.0
                let staminaDrain = (0.045 + min(0.18, lure.rodLineTensionN * 0.0038)) / max(0.65, fish.weightKg * 0.45)
                fish.stamina = max(0.0, fish.stamina - staminaDrain * dt)

                fish.position = simd_mix(fish.position, lure.position, SIMD3<Float>(repeating: min(1.0, dt * 10.0)))

                let awayFromAngler = simd_normalize(SIMD3<Float>(
                    fish.position.x - anglerPosition.x,
                    0.0,
                    fish.position.z - anglerPosition.z
                ))
                let sideSurge = SIMD3<Float>(-awayFromAngler.z, 0.0, awayFromAngler.x) * sin(fish.stateTimer * 1.9)

                if fish.isBreaching {
                    behaviorStateCode = 3.0
                    fish.breachProgress += dt * 1.18
                    fish.headShakePhase += dt * 24.0
                    fish.headShakeIntensity = 0.95
                    if fish.breachProgress >= 1.0 {
                        fish.isBreaching = false
                        fish.breachProgress = 0.0
                        fish.breachApexHeight = 0.0
                    }
                } else {
                    let shakeBurst = max(0.0, sin(fish.stateTimer * 2.6))
                    if shakeBurst > 0.65 {
                        behaviorStateCode = 2.0
                        fish.headShakePhase += dt * 26.0
                        fish.headShakeIntensity = shakeBurst
                    } else {
                        fish.headShakeIntensity = max(0.0, fish.headShakeIntensity - dt * 2.5)
                    }

                    if fish.position.y > -1.35 && fish.stamina > 0.35 && (fish.species == .largemouthBass || fish.species == .rainbowTrout || fish.species == .topmouthCulter) {
                        if nextRandomFloat() < dt * 0.45 {
                            fish.isBreaching = true
                            fish.breachProgress = 0.02
                            fish.breachApexHeight = 0.65 + fish.stamina * 0.75
                        }
                    }
                }

                let diveY: Float = (fish.species == .grouper || fish.species == .redSnapper) ? -0.65 : -0.25
                let runDir = simd_normalize(awayFromAngler * 0.75 + sideSurge * 0.55 + SIMD3<Float>(0, diveY, 0))
                let burstForceMag = (10.0 + fish.weightKg * 11.5) * (0.38 + 0.62 * fish.stamina) * (1.0 + fish.headShakeIntensity * 0.45)

                desiredVelocity = runDir * (2.2 + fish.stamina * 2.4)
                result.externalPullForce = runDir * burstForceMag
                result.hookedFishID = fish.id
                result.hookedFishSpecies = fish.species
                result.hookedFishState = fish.state
                result.hookedFishStamina = fish.stamina
                result.hookedHeadShake = fish.headShakeIntensity

                if fish.stamina <= 0.08 {
                    fish.state = .exhausted
                    fish.stateTimer = 0.0
                    fish.isBreaching = false
                    fish.headShakeIntensity = 0.0
                }

            case .exhausted:
                behaviorStateCode = 0.0
                fish.position = simd_mix(fish.position, lure.position, SIMD3<Float>(repeating: min(1.0, dt * 8.0)))
                let toAngler = simd_normalize(anglerPosition - fish.position)
                desiredVelocity = toAngler * 0.35
                result.externalPullForce = SIMD3<Float>(0.0, -1.8 * fish.weightKg, 0.0)
                result.hookedFishID = fish.id
                result.hookedFishSpecies = fish.species
                result.hookedFishState = .exhausted
                result.hookedFishStamina = fish.stamina
                result.hookedHeadShake = 0.0
            }

            let prevFwd = fish.forward
            let steerRate: Float = (fish.state == .strike || fish.state == .fight) ? 8.5 : 3.2
            fish.velocity = simd_mix(fish.velocity, desiredVelocity, SIMD3<Float>(repeating: min(1.0, dt * steerRate)))
            let speed = simd_length(fish.velocity)
            if speed > 0.02 {
                fish.forward = fish.velocity / speed
            }

            if !fish.isHooked {
                fish.position += fish.velocity * dt
                fish.position.y = max(bedY + 0.45, min(-0.35, fish.position.y))
                fish.position.x = max(-48.0, min(48.0, fish.position.x))
                fish.position.z = max(-48.0, min(16.0, fish.position.z))
            }

            let crossY = prevFwd.x * fish.forward.z - prevFwd.z * fish.forward.x
            let targetCurv = max(-1.0, min(1.0, crossY * 12.0))
            fish.turnCurvature = fish.turnCurvature + (targetCurv - fish.turnCurvature) * min(1.0, dt * 8.0)

            let tailFreq = 4.2 + speed * 4.8 + (fish.isHooked ? 5.5 : 0.0)
            fish.swimPhase = fmod(fish.swimPhase + dt * tailFreq, 628.31853)

            if speed > 1.35 || fish.state == .strike || fish.state == .fight {
                result.predatorThreats.append(PredatorThreat(
                    positionAndRadius: SIMD4<Float>(fish.position.x, fish.position.y, fish.position.z, 4.2 + fish.bodyScale * 2.2),
                    velocityAndIntensity: SIMD4<Float>(fish.velocity.x, fish.velocity.y, fish.velocity.z, min(1.0, speed * 0.42))
                ))
            }

            targetFish[i] = fish

            let modelMat = makeModelMatrix(pos: fish.position, forward: fish.forward, scale: fish.bodyScale, bankRoll: fish.turnCurvature * 0.28)
            let inst = FishInstanceData(
                modelMatrix: modelMat,
                swimParams: SIMD4<Float>(fish.swimPhase, tailFreq, 0.10 + min(0.10, speed * 0.025), fish.genome.bodyLength * fish.bodyScale),
                dorsalColorAndSpecies: SIMD4<Float>(fish.genome.dorsalColor.x, fish.genome.dorsalColor.y, fish.genome.dorsalColor.z, Float(fish.species.rawValue)),
                ventralColorAndIridescence: SIMD4<Float>(fish.genome.ventralColor.x, fish.genome.ventralColor.y, fish.genome.ventralColor.z, fish.genome.iridescenceStrength),
                biomechParams: SIMD4<Float>(speed, fish.turnCurvature, fish.gillPhase, behaviorStateCode),
                breachAndShakeParams: SIMD4<Float>(fish.headShakePhase, fish.headShakeIntensity, fish.breachProgress, fish.breachApexHeight)
            )
            instances.append(inst)
        }

        return (result, instances)
    }

    private func evaluateLureMatchScore(
        species: FishSpecies,
        lure: LurePerceptionInput,
        lureSpeed: Float,
        lightIrradiance: Float,
        waterClarity: Float
    ) -> Float {
        let typeAffinity: Float
        switch (species, lure.lureType) {
        case (.largemouthBass, .minnowHardbait), (.largemouthBass, .jigheadSoftWorm): typeAffinity = 0.92
        case (.rainbowTrout, .metalSpoon), (.rainbowTrout, .minnowHardbait): typeAffinity = 0.90
        case (.topmouthCulter, .minnowHardbait), (.topmouthCulter, .metalSpoon): typeAffinity = 0.95
        case (.redSnapper, .jigheadSoftWorm), (.redSnapper, .metalSpoon): typeAffinity = 0.88
        case (.grouper, .jigheadSoftWorm): typeAffinity = 0.94
        default: typeAffinity = 0.58
        }

        let idealSpeed: Float = (species == .topmouthCulter) ? 1.85 : ((species == .grouper) ? 0.65 : 1.15)
        let speedScore = exp(-pow((lureSpeed - idealSpeed) / 1.15, 2.0))

        let lureLuminance = simd_dot(lure.lureColorRGB, SIMD3<Float>(0.299, 0.587, 0.114))
        let optimalLuminance: Float = (lightIrradiance * (waterClarity / 8.0) > 0.45) ? 0.48 : 0.82
        let colorScore = max(0.35, 1.0 - abs(lureLuminance - optimalLuminance))

        let wobbleBonus = min(0.25, lure.wobbleAmplitude * 0.45)
        return max(0.05, min(1.0, typeAffinity * (0.42 + 0.38 * speedScore + 0.20 * colorScore) + wobbleBonus))
    }

    private func makeModelMatrix(pos: SIMD3<Float>, forward: SIMD3<Float>, scale: Float, bankRoll: Float) -> simd_float4x4 {
        let f = simd_normalize(forward)
        let worldUp = SIMD3<Float>(0, 1, 0)
        var r = simd_cross(worldUp, f)
        r = simd_length_squared(r) < 1e-6 ? SIMD3<Float>(1, 0, 0) : simd_normalize(r)
        let u = simd_cross(f, r)

        let cr = cos(bankRoll), sr = sin(bankRoll)
        let rBank = r * cr + u * sr
        let uBank = -r * sr + u * cr

        return simd_float4x4(columns: (
            SIMD4<Float>(rBank * scale, 0.0),
            SIMD4<Float>(uBank * scale, 0.0),
            SIMD4<Float>(f * scale, 0.0),
            SIMD4<Float>(pos, 1.0)
        ))
    }

    private func nextRandomFloat() -> Float {
        rngState = rngState &* 6364136223846793005 &+ 1442695040888963407
        return Float((rngState >> 33) & 0x7FFF_FFFF) / Float(0x7FFF_FFFF)
    }
}
