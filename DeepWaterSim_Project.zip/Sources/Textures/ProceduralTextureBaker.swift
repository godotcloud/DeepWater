import Foundation
import Metal
import simd

public struct PBRTextureSet: @unchecked Sendable {
    public let albedo: MTLTexture
    public let normal: MTLTexture
    public let roughnessMeta: MTLTexture
    public let iridescence: MTLTexture?

    public init(
        albedo: MTLTexture,
        normal: MTLTexture,
        roughnessMeta: MTLTexture,
        iridescence: MTLTexture? = nil
    ) {
        self.albedo = albedo
        self.normal = normal
        self.roughnessMeta = roughnessMeta
        self.iridescence = iridescence
    }
}

public struct ProceduralTextureAtlas: @unchecked Sendable {
    public let fishBase: PBRTextureSet
    public let carbonFiber: PBRTextureSet
    public let brushedAluminum: PBRTextureSet
    public let naturalCork: PBRTextureSet
    public let seabed: PBRTextureSet
}

public enum ProceduralTextureBakerError: Error, Sendable {
    case defaultLibraryUnavailable
    case missingComputeFunction(String)
    case textureAllocationFailed(String)
    case commandBufferCreationFailed
    case computeEncodingFailed
}

public enum ProceduralTextureBaker {
    public static func bakeAllAsync(
        device: MTLDevice,
        commandQueue: MTLCommandQueue
    ) async throws -> ProceduralTextureAtlas {
        guard let library = device.makeDefaultLibrary() else {
            throw ProceduralTextureBakerError.defaultLibraryUnavailable
        }

        guard let fishFunc = library.makeFunction(name: "bakeFishTexturesKernel") else {
            throw ProceduralTextureBakerError.missingComputeFunction("bakeFishTexturesKernel")
        }
        guard let tackleFunc = library.makeFunction(name: "bakeTackleTexturesKernel") else {
            throw ProceduralTextureBakerError.missingComputeFunction("bakeTackleTexturesKernel")
        }
        guard let seabedFunc = library.makeFunction(name: "bakeSeabedTexturesKernel") else {
            throw ProceduralTextureBakerError.missingComputeFunction("bakeSeabedTexturesKernel")
        }

        let fishPSO = try device.makeComputePipelineState(function: fishFunc)
        let tacklePSO = try device.makeComputePipelineState(function: tackleFunc)
        let seabedPSO = try device.makeComputePipelineState(function: seabedFunc)

        let fishSet = try makeTextureSet(device: device, size: 1024, includeIridescence: true, prefix: "FishPBR")
        let carbonSet = try makeTextureSet(device: device, size: 512, includeIridescence: false, prefix: "CarbonFiber")
        let aluminumSet = try makeTextureSet(device: device, size: 512, includeIridescence: false, prefix: "BrushedAluminum")
        let corkSet = try makeTextureSet(device: device, size: 512, includeIridescence: false, prefix: "NaturalCork")
        let seabedSet = try makeTextureSet(device: device, size: 1024, includeIridescence: false, prefix: "SeabedPBR")

        let atlas = ProceduralTextureAtlas(
            fishBase: fishSet,
            carbonFiber: carbonSet,
            brushedAluminum: aluminumSet,
            naturalCork: corkSet,
            seabed: seabedSet
        )

        guard let commandBuffer = commandQueue.makeCommandBuffer() else {
            throw ProceduralTextureBakerError.commandBufferCreationFailed
        }
        commandBuffer.label = "ProceduralTextureBakeCommandBuffer"

        guard let computeEncoder = commandBuffer.makeComputeCommandEncoder() else {
            throw ProceduralTextureBakerError.computeEncodingFailed
        }
        computeEncoder.label = "ProceduralTextureBakeEncoder"

        var fishParams = TextureBakeParams(
            primaryColorAndFreq: SIMD4<Float>(0.15, 0.24, 0.14, 52.0),
            secondaryColorAndRough: SIMD4<Float>(0.76, 0.80, 0.84, 0.22),
            accentColorAndMode: SIMD4<Float>(0.34, 0.44, 0.36, 0.0),
            sizeAndSeed: SIMD4<Float>(1024.0, 1024.0, 1.37, 1.15)
        )
        computeEncoder.setComputePipelineState(fishPSO)
        computeEncoder.setTexture(fishSet.albedo, index: 0)
        computeEncoder.setTexture(fishSet.normal, index: 1)
        computeEncoder.setTexture(fishSet.roughnessMeta, index: 2)
        computeEncoder.setTexture(fishSet.iridescence, index: 3)
        computeEncoder.setBytes(&fishParams, length: MemoryLayout<TextureBakeParams>.stride, index: Int(BufferIndex.bakeParams.rawValue))
        dispatch2D(encoder: computeEncoder, pipeline: fishPSO, width: 1024, height: 1024)

        var carbonParams = TextureBakeParams(
            primaryColorAndFreq: SIMD4<Float>(0.045, 0.048, 0.055, 28.0),
            secondaryColorAndRough: SIMD4<Float>(0.16, 0.17, 0.19, 0.24),
            accentColorAndMode: SIMD4<Float>(0.0, 0.0, 0.0, 0.0),
            sizeAndSeed: SIMD4<Float>(512.0, 512.0, 2.1, 1.0)
        )
        computeEncoder.setComputePipelineState(tacklePSO)
        computeEncoder.setTexture(carbonSet.albedo, index: 0)
        computeEncoder.setTexture(carbonSet.normal, index: 1)
        computeEncoder.setTexture(carbonSet.roughnessMeta, index: 2)
        computeEncoder.setBytes(&carbonParams, length: MemoryLayout<TextureBakeParams>.stride, index: Int(BufferIndex.bakeParams.rawValue))
        dispatch2D(encoder: computeEncoder, pipeline: tacklePSO, width: 512, height: 512)

        var aluminumParams = TextureBakeParams(
            primaryColorAndFreq: SIMD4<Float>(0.56, 0.59, 0.64, 1.0),
            secondaryColorAndRough: SIMD4<Float>(0.78, 0.81, 0.86, 0.24),
            accentColorAndMode: SIMD4<Float>(0.0, 0.0, 0.0, 1.0),
            sizeAndSeed: SIMD4<Float>(512.0, 512.0, 3.4, 1.0)
        )
        computeEncoder.setTexture(aluminumSet.albedo, index: 0)
        computeEncoder.setTexture(aluminumSet.normal, index: 1)
        computeEncoder.setTexture(aluminumSet.roughnessMeta, index: 2)
        computeEncoder.setBytes(&aluminumParams, length: MemoryLayout<TextureBakeParams>.stride, index: Int(BufferIndex.bakeParams.rawValue))
        dispatch2D(encoder: computeEncoder, pipeline: tacklePSO, width: 512, height: 512)

        var corkParams = TextureBakeParams(
            primaryColorAndFreq: SIMD4<Float>(0.68, 0.52, 0.34, 1.0),
            secondaryColorAndRough: SIMD4<Float>(0.24, 0.16, 0.10, 0.82),
            accentColorAndMode: SIMD4<Float>(0.0, 0.0, 0.0, 2.0),
            sizeAndSeed: SIMD4<Float>(512.0, 512.0, 4.9, 1.0)
        )
        computeEncoder.setTexture(corkSet.albedo, index: 0)
        computeEncoder.setTexture(corkSet.normal, index: 1)
        computeEncoder.setTexture(corkSet.roughnessMeta, index: 2)
        computeEncoder.setBytes(&corkParams, length: MemoryLayout<TextureBakeParams>.stride, index: Int(BufferIndex.bakeParams.rawValue))
        dispatch2D(encoder: computeEncoder, pipeline: tacklePSO, width: 512, height: 512)

        var seabedParams = TextureBakeParams(
            primaryColorAndFreq: SIMD4<Float>(0.42, 0.37, 0.28, 1.0),
            secondaryColorAndRough: SIMD4<Float>(0.18, 0.19, 0.18, 0.72),
            accentColorAndMode: SIMD4<Float>(0.11, 0.23, 0.10, 0.0),
            sizeAndSeed: SIMD4<Float>(1024.0, 1024.0, 7.7, 1.2)
        )
        computeEncoder.setComputePipelineState(seabedPSO)
        computeEncoder.setTexture(seabedSet.albedo, index: 0)
        computeEncoder.setTexture(seabedSet.normal, index: 1)
        computeEncoder.setTexture(seabedSet.roughnessMeta, index: 2)
        computeEncoder.setBytes(&seabedParams, length: MemoryLayout<TextureBakeParams>.stride, index: Int(BufferIndex.bakeParams.rawValue))
        dispatch2D(encoder: computeEncoder, pipeline: seabedPSO, width: 1024, height: 1024)

        computeEncoder.endEncoding()

        if let blitEncoder = commandBuffer.makeBlitCommandEncoder() {
            blitEncoder.label = "ProceduralTextureMipmapEncoder"
            let allTextures: [MTLTexture] = [
                fishSet.albedo, fishSet.normal, fishSet.roughnessMeta,
                carbonSet.albedo, carbonSet.normal, carbonSet.roughnessMeta,
                aluminumSet.albedo, aluminumSet.normal, aluminumSet.roughnessMeta,
                corkSet.albedo, corkSet.normal, corkSet.roughnessMeta,
                seabedSet.albedo, seabedSet.normal, seabedSet.roughnessMeta
            ] + (fishSet.iridescence.map { [$0] } ?? [])

            for tex in allTextures where tex.mipmapLevelCount > 1 {
                blitEncoder.generateMipmaps(for: tex)
            }
            blitEncoder.endEncoding()
        }

        return try await withCheckedThrowingContinuation { continuation in
            commandBuffer.addCompletedHandler { cb in
                if let err = cb.error {
                    continuation.resume(throwing: err)
                } else {
                    continuation.resume(returning: atlas)
                }
            }
            commandBuffer.commit()
        }
    }

    private static func makeTextureSet(
        device: MTLDevice,
        size: Int,
        includeIridescence: Bool,
        prefix: String
    ) throws -> PBRTextureSet {
        func alloc(_ suffix: String) throws -> MTLTexture {
            let desc = MTLTextureDescriptor.texture2DDescriptor(
                pixelFormat: .rgba8Unorm,
                width: size,
                height: size,
                mipmapped: true
            )
            desc.storageMode = .private
            desc.usage = [.shaderRead, .shaderWrite]
            guard let tex = device.makeTexture(descriptor: desc) else {
                throw ProceduralTextureBakerError.textureAllocationFailed("\(prefix)_\(suffix)")
            }
            tex.label = "\(prefix)_\(suffix)"
            return tex
        }

        let albedo = try alloc("Albedo")
        let normal = try alloc("Normal")
        let roughMeta = try alloc("RoughnessMeta")
        let irid = includeIridescence ? try alloc("Iridescence") : nil
        return PBRTextureSet(albedo: albedo, normal: normal, roughnessMeta: roughMeta, iridescence: irid)
    }

    private static func dispatch2D(
        encoder: MTLComputeCommandEncoder,
        pipeline: MTLComputePipelineState,
        width: Int,
        height: Int
    ) {
        let w = pipeline.threadExecutionWidth
        let h = max(1, pipeline.maxTotalThreadsPerThreadgroup / w)
        let threadsPerGroup = MTLSize(width: min(w, 16), height: min(h, 16), depth: 1)
        let gridSize = MTLSize(width: width, height: height, depth: 1)
        encoder.dispatchThreads(gridSize, threadsPerThreadgroup: threadsPerGroup)
    }
}
